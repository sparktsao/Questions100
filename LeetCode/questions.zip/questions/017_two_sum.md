# 017. Two Sum

**Difficulty:** EASY
**Frequency:** 76.4%
**Acceptance Rate:** 55.8%
**LeetCode Link:** [Two Sum](https://leetcode.com/problems/two-sum)

---

## Problem Description

Given an array of integers `nums` and an integer `target`, return indices of the two numbers such that they add up to `target`.

You may assume that each input would have exactly one solution, and you may not use the same element twice. You can return the answer in any order.

**Constraints:**
- 2 <= nums.length <= 10^4
- -10^9 <= nums[i] <= 10^9
- -10^9 <= target <= 10^9
- Only one valid answer exists.

---

## Examples

### Example 1
**Input:** `nums = [2,7,11,15], target = 9`
**Output:** `[0,1]`
**Explanation:** nums[0] + nums[1] == 9, so we return [0, 1]

### Example 2
**Input:** `nums = [3,2,4], target = 6`
**Output:** `[1,2]`
**Explanation:** nums[1] + nums[2] == 6

### Example 3
**Input:** `nums = [3,3], target = 6`
**Output:** `[0,1]`
**Explanation:** Both elements are 3, at different indices

### Example 4
**Input:** `nums = [-1,-2,-3,-4,-5], target = -8`
**Output:** `[2,4]`
**Explanation:** -3 + (-5) = -8, works with negative numbers

---

## Optimal Solution

### Implementation

```python
def twoSum(nums: List[int], target: int) -> List[int]:
    """
    Find two numbers that add up to target using hash map.

    Time: O(n), Space: O(n)
    """
    seen = {}
    for i, num in enumerate(nums):
        complement = target - num
        if complement in seen:
            return [seen[complement], i]
        seen[num] = i
    return []
```

### Complexity Analysis

**Time: O(n) - single pass. Space: O(n) - hash map storage**

**Why This is Optimal:**
- Achieves best possible asymptotic complexity for this problem class
- Minimal space overhead while maintaining code clarity
- Scales efficiently with large inputs
- Handles all edge cases correctly

---

## Categories & Tags

**Primary Topics:** Array, Hash Table

**Difficulty Level:** EASY

---

## Real-World Applications

Understanding this algorithmic pattern has direct real-world applications:

1. **E-Commerce Price Matching:** Finding product pairs that fit a budget on Amazon/eBay
2. **Financial Trading:** Pairing buy/sell orders that match target prices on exchanges like NASDAQ
3. **Recommendation Systems:** Netflix/Spotify finding content pairs with combined ratings matching preferences
4. **Inventory Management:** Walmart/Target finding product combinations for bundle deals
5. **Database Indexing:** PostgreSQL/MySQL using hash indexes for fast lookups in join operations

**Industry Impact:**
This algorithmic pattern appears in production systems at companies like Google, Amazon, Microsoft, Meta, and Netflix. Engineers working on large-scale distributed systems, data processing pipelines, and user-facing applications regularly implement these concepts.

---

## Cybersecurity Applications

This problem demonstrates algorithmic concepts crucial for security engineering:

1. **Port Scanning Detection:** Identifying pairs of network events that indicate coordinated port scans (Snort, Suricata)
2. **Credential Stuffing Detection:** Finding username/password pairs in breached databases (HaveIBeenPwned API)
3. **Attack Signature Matching:** Pairing network packets that together form attack patterns in IDS (Zeek, Bro)
4. **Malware Behavior Analysis:** Identifying API call pairs characteristic of malware (Cuckoo Sandbox)
5. **Fraud Detection:** Finding transaction pairs that sum to suspicious amounts (Splunk Security)
6. **DDoS Mitigation:** Pairing source IPs with attack signatures for rate limiting (Cloudflare, Akamai)

**Security Engineering Value:**
Security professionals use these algorithms in threat detection systems, security information and event management (SIEM) platforms, intrusion detection/prevention systems (IDS/IPS), and security automation tools. Understanding these patterns is essential for developing robust security solutions.

**Common Security Contexts:**
- **Threat Detection:** Pattern matching and anomaly detection in security logs
- **Performance Security:** Preventing algorithmic complexity attacks (e.g., hash collision DoS)
- **Secure Code Review:** Identifying potential vulnerabilities in algorithm implementations
- **Security Tooling:** Building efficient security scanners and analysis tools
- **Incident Response:** Fast data processing during security investigations

---

## Learning Resources

**Recommended Study Path:**
1. Master the fundamental data structure concepts
2. Practice similar problems with the same pattern
3. Implement the solution from scratch without reference
4. Analyze time/space complexity of alternative approaches
5. Consider edge cases and error handling

**Interview Preparation:**
- This problem has 76.4% frequency in technical interviews
- Expected to solve in 20-45 minutes during coding interviews
- Be prepared to discuss trade-offs and alternative approaches
- Practice explaining your thought process clearly

**Common Pitfalls:**
- Off-by-one errors in array/string indexing
- Not handling edge cases (empty input, single element, etc.)
- Incorrect complexity analysis
- Over-complicating the solution

**Optimization Tips:**
- Consider early termination conditions
- Minimize unnecessary data structure operations
- Use built-in language features efficiently
- Profile for performance on large inputs

---

*Generated for educational purposes. Problem source: [LeetCode](https://leetcode.com/problems/two-sum)*
