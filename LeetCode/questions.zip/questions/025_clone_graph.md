# 025. Clone Graph

**Difficulty:** MEDIUM
**Frequency:** 71.4%
**Acceptance Rate:** 62.4%
**LeetCode Link:** [Clone Graph](https://leetcode.com/problems/clone-graph)

---

## Problem Description

Given a reference of a node in a connected undirected graph, return a deep copy (clone) of the graph.

Each node in the graph contains a value (`int`) and a list (`List[Node]`) of its neighbors.

```
class Node {
    public int val;
    public List<Node> neighbors;
}
```

**Test case format:**
The input is a serialized graph using adjacency list representation.

**Constraints:**
- The number of nodes in the graph is in the range [0, 100]
- 1 <= Node.val <= 100
- Node.val is unique for each node
- There are no repeated edges and no self-loops
- The Graph is connected and all nodes can be visited starting from the given node

---

## Examples

### Example 1
**Input:** `adjList = [[2,4],[1,3],[2,4],[1,3]]`
**Output:** `[[2,4],[1,3],[2,4],[1,3]]`
**Explanation:** 4 nodes forming a square graph

### Example 2
**Input:** `adjList = [[]]`
**Output:** `[[]]`
**Explanation:** Single node with no neighbors

### Example 3
**Input:** `adjList = []`
**Output:** `[]`
**Explanation:** Empty graph

### Example 4
**Input:** `adjList = [[2],[1,3],[2]]`
**Output:** `[[2],[1,3],[2]]`
**Explanation:** 3-node path graph

---

## Optimal Solution

### Implementation

```python
def cloneGraph(node: 'Node') -> 'Node':
    """
    DFS with hash map to track cloned nodes.

    Time: O(N + E), Space: O(N)
    """
    if not node:
        return None

    cloned = {}

    def dfs(node):
        if node in cloned:
            return cloned[node]

        # Create clone
        clone = Node(node.val)
        cloned[node] = clone

        # Clone neighbors
        for neighbor in node.neighbors:
            clone.neighbors.append(dfs(neighbor))

        return clone

    return dfs(node)
```

### Complexity Analysis

**Time: O(N + E) - visit all nodes and edges. Space: O(N) - hash map + recursion**

**Why This is Optimal:**
- Achieves best possible asymptotic complexity for this problem class
- Minimal space overhead while maintaining code clarity
- Scales efficiently with large inputs
- Handles all edge cases correctly

---

## Categories & Tags

**Primary Topics:** Hash Table, Depth-First Search, Breadth-First Search, Graph

**Difficulty Level:** MEDIUM

---

## Real-World Applications

Understanding this algorithmic pattern has direct real-world applications:

1. **Version Control:** Git creating branch copies with all references
2. **Virtual Machines:** VMware/VirtualBox cloning VM images with network configs
3. **Social Networks:** Facebook graph replication for distributed storage
4. **Distributed Systems:** Cassandra/DynamoDB replicating data graphs across nodes
5. **Game Development:** Unity cloning game objects with all component references
6. **CAD Software:** AutoCAD copying complex object hierarchies

**Industry Impact:**
This algorithmic pattern appears in production systems at companies like Google, Amazon, Microsoft, Meta, and Netflix. Engineers working on large-scale distributed systems, data processing pipelines, and user-facing applications regularly implement these concepts.

---

## Cybersecurity Applications

This problem demonstrates algorithmic concepts crucial for security engineering:

1. **Sandbox Analysis:** Cuckoo/ANY.RUN cloning malware execution environments
2. **Network Topology:** Cloning network graphs for penetration testing scenarios
3. **Threat Modeling:** Duplicating attack graphs for scenario analysis
4. **Container Security:** Docker creating container copies with security contexts
5. **Access Control:** Cloning RBAC permission graphs for testing
6. **Forensics:** Creating forensic copies of system state graphs
7. **Red Team:** Replicating target network topology for attack planning

**Security Engineering Value:**
Security professionals use these algorithms in threat detection systems, security information and event management (SIEM) platforms, intrusion detection/prevention systems (IDS/IPS), and security automation tools. Understanding these patterns is essential for developing robust security solutions.

**Common Security Contexts:**
- **Threat Detection:** Pattern matching and anomaly detection in security logs
- **Performance Security:** Preventing algorithmic complexity attacks (e.g., hash collision DoS)
- **Secure Code Review:** Identifying potential vulnerabilities in algorithm implementations
- **Security Tooling:** Building efficient security scanners and analysis tools
- **Incident Response:** Fast data processing during security investigations

---

## Learning Resources

**Recommended Study Path:**
1. Master the fundamental data structure concepts
2. Practice similar problems with the same pattern
3. Implement the solution from scratch without reference
4. Analyze time/space complexity of alternative approaches
5. Consider edge cases and error handling

**Interview Preparation:**
- This problem has 71.4% frequency in technical interviews
- Expected to solve in 20-45 minutes during coding interviews
- Be prepared to discuss trade-offs and alternative approaches
- Practice explaining your thought process clearly

**Common Pitfalls:**
- Off-by-one errors in array/string indexing
- Not handling edge cases (empty input, single element, etc.)
- Incorrect complexity analysis
- Over-complicating the solution

**Optimization Tips:**
- Consider early termination conditions
- Minimize unnecessary data structure operations
- Use built-in language features efficiently
- Profile for performance on large inputs

---

*Generated for educational purposes. Problem source: [LeetCode](https://leetcode.com/problems/clone-graph)*
