# 092. Kth Smallest Element in a BST

**Difficulty:** MEDIUM
**Frequency:** 32.0%
**Acceptance Rate:** 75.3%
**LeetCode Link:** [Kth Smallest Element in a BST](https://leetcode.com/problems/kth-smallest-element-in-a-bst)

---

## Problem Description

Given the `root` of a binary search tree, and an integer `k`, return the `kth` smallest value (1-indexed) of all the values of the nodes in the tree.

**Constraints:**
- The number of nodes in the tree is n
- 1 <= k <= n <= 10^4
- 0 <= Node.val <= 10^4

**Follow up:** If the BST is modified often (i.e., we can do insert and delete operations) and you need to find the kth smallest frequently, how would you optimize?

---

## Examples

### Example 1
**Input:** `root = [3,1,4,null,2], k = 1`
**Output:** `1`
**Explanation:** Inorder traversal gives [1,2,3,4], 1st smallest is 1

### Example 2
**Input:** `root = [5,3,6,2,4,null,null,1], k = 3`
**Output:** `3`
**Explanation:** Inorder traversal gives [1,2,3,4,5,6], 3rd smallest is 3

### Example 3
**Input:** `root = [2,1,3], k = 2`
**Output:** `2`
**Explanation:** Middle element in sorted order

### Example 4
**Input:** `root = [1], k = 1`
**Output:** `1`
**Explanation:** Single node tree

---

## Optimal Solution

### Implementation (Iterative Inorder)

```python
def kthSmallest(root: Optional[TreeNode], k: int) -> int:
    """
    Find kth smallest using iterative inorder traversal.

    Time: O(H + k) where H is tree height, Space: O(H) for stack
    """
    stack = []
    current = root
    count = 0

    while current or stack:
        # Go to leftmost node
        while current:
            stack.append(current)
            current = current.left

        # Process node
        current = stack.pop()
        count += 1

        # Found kth smallest
        if count == k:
            return current.val

        # Move to right subtree
        current = current.right

    return -1  # Should never reach here with valid input
```

### Alternative Implementation (Recursive)

```python
def kthSmallest(root: Optional[TreeNode], k: int) -> int:
    """
    Recursive inorder traversal approach.

    Time: O(n), Space: O(H) for recursion stack
    """
    def inorder(node):
        if not node:
            return []

        # Inorder: left, root, right
        return inorder(node.left) + [node.val] + inorder(node.right)

    # Get sorted values and return kth element (1-indexed)
    sorted_vals = inorder(root)
    return sorted_vals[k - 1]
```

### Optimized Recursive with Early Stopping

```python
def kthSmallest(root: Optional[TreeNode], k: int) -> int:
    """
    Optimized recursive with early stopping.

    Time: O(H + k), Space: O(H)
    """
    def inorder(node):
        nonlocal k, result

        if not node or k == 0:
            return

        # Traverse left
        inorder(node.left)

        # Process current node
        k -= 1
        if k == 0:
            result = node.val
            return

        # Traverse right
        inorder(node.right)

    result = -1
    inorder(root)
    return result
```

### Follow-up: Augmented BST

```python
class TreeNode:
    def __init__(self, val=0, left=None, right=None):
        self.val = val
        self.left = left
        self.right = right
        self.size = 1  # Number of nodes in subtree (including self)

def kthSmallest(root: Optional[TreeNode], k: int) -> int:
    """
    Using augmented BST with subtree sizes.

    Each node stores count of nodes in its subtree.
    Time: O(H), Space: O(1)
    """
    # Size of left subtree
    left_size = root.left.size if root.left else 0

    if k <= left_size:
        # kth smallest is in left subtree
        return kthSmallest(root.left, k)
    elif k == left_size + 1:
        # Current node is the kth smallest
        return root.val
    else:
        # kth smallest is in right subtree
        return kthSmallest(root.right, k - left_size - 1)
```

### Complexity Analysis

**Iterative Inorder:**
**Time: O(H + k) - traverse to kth element. Space: O(H) - stack for tree height**

**Augmented BST (Follow-up):**
**Time: O(H) - direct path to kth element. Space: O(1) - no extra space**

**Why This is Optimal:**
- Inorder traversal naturally gives sorted order for BST
- Early stopping at kth element avoids processing entire tree
- Iterative version saves space compared to storing all values
- Augmented BST enables O(H) queries, optimal for frequent operations
- Handles all edge cases correctly

---

## Categories & Tags

**Primary Topics:** Tree, Depth-First Search, Binary Search Tree, Binary Tree

**Difficulty Level:** MEDIUM

---

## Real-World Applications

Understanding this algorithmic pattern has direct real-world applications:

1. **Database Indexing:** PostgreSQL and MySQL B-tree indexes finding median values or percentiles efficiently
2. **Priority Systems:** Operating system schedulers finding kth priority process in priority queues
3. **E-commerce:** Amazon and eBay product recommendation finding kth most relevant item in sorted catalogs
4. **Game Leaderboards:** Steam and Xbox Live finding player rank in sorted score trees
5. **File Systems:** NTFS and ext4 finding kth file by timestamp in directory trees

**Industry Impact:**
This algorithmic pattern appears in production systems at database companies (Oracle, MongoDB), gaming platforms (Unity, Steam), and cloud providers (AWS DynamoDB). Engineers working on search systems, ranking algorithms, and data indexing regularly implement these concepts.

---

## Cybersecurity Applications

This problem demonstrates algorithmic concepts crucial for security engineering:

1. **Threat Ranking:** SIEM platforms (Splunk, QRadar) finding kth highest severity alert in priority trees
2. **Vulnerability Scoring:** Nessus and Qualys ranking kth most critical vulnerability from sorted CVE trees
3. **Log Analysis:** Finding kth most frequent attack pattern in frequency-sorted event trees
4. **Access Control:** Determining kth most privileged user in hierarchical permission structures
5. **Network Forensics:** Identifying kth largest packet in sorted traffic captures for deep inspection
6. **Malware Analysis:** Finding kth most suspicious behavior in scored action trees

**Security Engineering Value:**
Security professionals use tree-based selection algorithms in real-time threat prioritization systems, in compliance reporting to find threshold violations, and in incident response to identify top-k security events requiring investigation.

**Common Security Contexts:**
- **Threat Detection:** Efficiently finding top-k threats without sorting entire dataset
- **Performance Security:** Optimizing queries to prevent DoS through expensive operations
- **Secure Code Review:** Understanding tree traversal for secure data structure design
- **Security Tooling:** Building efficient ranking systems for alert prioritization
- **Incident Response:** Quickly identifying critical events in large log hierarchies

---

## Learning Resources

**Recommended Study Path:**
1. Master inorder, preorder, and postorder BST traversals
2. Understand BST properties and sorted order
3. Practice similar problems: Validate BST (98), BST Iterator (173)
4. Learn augmented data structures for follow-up
5. Study balanced BST variants (AVL, Red-Black)

**Interview Preparation:**
- This problem has 32.0% frequency in technical interviews
- Expected to solve in 20-30 minutes during coding interviews
- Be prepared to discuss both iterative and recursive approaches
- Practice explaining the follow-up augmented BST optimization

**Common Pitfalls:**
- Forgetting BST inorder gives sorted sequence
- Processing entire tree instead of stopping at k
- Stack overflow with deep recursion on unbalanced trees
- Off-by-one errors with 1-indexed k
- Not handling edge cases (k = 1, k = n, single node)

**Optimization Tips:**
- Use iterative inorder to save stack space
- Stop early when kth element found
- For frequent queries, augment BST with subtree sizes
- Consider maintaining sorted array for small, static BSTs
- Balance tree (AVL/Red-Black) to ensure O(log n) height

---

*Generated for educational purposes. Problem source: [LeetCode](https://leetcode.com/problems/kth-smallest-element-in-a-bst)*
