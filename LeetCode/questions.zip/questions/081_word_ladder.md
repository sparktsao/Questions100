# 081. Word Ladder

**Difficulty:** HARD
**Frequency:** 40.7%
**Acceptance Rate:** 42.8%
**LeetCode Link:** [Word Ladder](https://leetcode.com/problems/word-ladder)

---

## Problem Description

A transformation sequence from word `beginWord` to word `endWord` using a dictionary `wordList` is a sequence of words `beginWord -> s1 -> s2 -> ... -> sk` such that:

- Every adjacent pair of words differs by a single letter
- Every `si` for `1 <= i <= k` is in `wordList`. Note that `beginWord` does not need to be in `wordList`
- `sk == endWord`

Given two words, `beginWord` and `endWord`, and a dictionary `wordList`, return the number of words in the shortest transformation sequence from `beginWord` to `endWord`, or `0` if no such sequence exists.

**Constraints:**
- 1 <= beginWord.length <= 10
- endWord.length == beginWord.length
- 1 <= wordList.length <= 5000
- wordList[i].length == beginWord.length
- All words consist of lowercase English letters
- beginWord != endWord
- All words in wordList are unique

---

## Examples

### Example 1
**Input:** `beginWord = "hit", endWord = "cog", wordList = ["hot","dot","dog","lot","log","cog"]`
**Output:** `5`
**Explanation:** Shortest: "hit" -> "hot" -> "dot" -> "dog" -> "cog"

### Example 2
**Input:** `beginWord = "hit", endWord = "cog", wordList = ["hot","dot","dog","lot","log"]`
**Output:** `0`
**Explanation:** endWord not in wordList

### Example 3
**Input:** `beginWord = "a", endWord = "c", wordList = ["a","b","c"]`
**Output:** `2`
**Explanation:** a -> c (differ by one letter)

### Example 4
**Input:** `beginWord = "hot", endWord = "dog", wordList = ["hot","dog"]`
**Output:** `0`
**Explanation:** hot and dog differ by 2 letters

---

## Optimal Solution

### Implementation

```python
def ladderLength(beginWord: str, endWord: str, wordList: List[str]) -> int:
    """
    BFS to find shortest transformation path.

    Time: O(M² × N), Space: O(M² × N)
    where M is word length, N is wordList size
    """
    from collections import deque

    word_set = set(wordList)
    if endWord not in word_set:
        return 0

    queue = deque([(beginWord, 1)])
    visited = {beginWord}

    while queue:
        word, length = queue.popleft()

        if word == endWord:
            return length

        # Try all possible one-letter changes
        for i in range(len(word)):
            for c in 'abcdefghijklmnopqrstuvwxyz':
                next_word = word[:i] + c + word[i+1:]

                if next_word in word_set and next_word not in visited:
                    visited.add(next_word)
                    queue.append((next_word, length + 1))

    return 0
```

### Complexity Analysis

**Time: O(M² × N) - for each word try M positions × 26 letters. Space: O(M × N) - queue + visited**

**Why This is Optimal:**
- Achieves best possible asymptotic complexity for this problem class
- Minimal space overhead while maintaining code clarity
- Scales efficiently with large inputs
- Handles all edge cases correctly

---

## Categories & Tags

**Primary Topics:** Hash Table, String, Breadth-First Search

**Difficulty Level:** HARD

---

## Real-World Applications

Understanding this algorithmic pattern has direct real-world applications:

1. **Spell Checkers:** Grammarly finding word suggestions with minimal edits
2. **DNA Analysis:** Finding mutation paths in genetic sequences
3. **NLP:** Word2Vec finding semantic transformation paths
4. **Game AI:** Finding optimal word game moves (Wordle solver)
5. **Machine Translation:** Finding translation paths through intermediate languages
6. **Compiler:** Symbol table lookups with typo correction

**Industry Impact:**
This algorithmic pattern appears in production systems at companies like Google, Amazon, Microsoft, Meta, and Netflix. Engineers working on large-scale distributed systems, data processing pipelines, and user-facing applications regularly implement these concepts.

---

## Cybersecurity Applications

This problem demonstrates algorithmic concepts crucial for security engineering:

1. **Password Cracking:** Finding transformation from known to target password
2. **Obfuscation Detection:** Detecting malware variants with single-byte changes
3. **Domain Generation:** Tracking DGA variations in malware C2
4. **Fuzzing:** Generating input mutations for testing
5. **Signature Evasion:** Finding minimal payload changes to bypass IDS
6. **Threat Intelligence:** Tracking malware family evolution
7. **Phishing Detection:** Finding domain name variations (typosquatting)

**Security Engineering Value:**
Security professionals use these algorithms in threat detection systems, security information and event management (SIEM) platforms, intrusion detection/prevention systems (IDS/IPS), and security automation tools. Understanding these patterns is essential for developing robust security solutions.

**Common Security Contexts:**
- **Threat Detection:** Pattern matching and anomaly detection in security logs
- **Performance Security:** Preventing algorithmic complexity attacks (e.g., hash collision DoS)
- **Secure Code Review:** Identifying potential vulnerabilities in algorithm implementations
- **Security Tooling:** Building efficient security scanners and analysis tools
- **Incident Response:** Fast data processing during security investigations

---

## Learning Resources

**Recommended Study Path:**
1. Master the fundamental data structure concepts
2. Practice similar problems with the same pattern
3. Implement the solution from scratch without reference
4. Analyze time/space complexity of alternative approaches
5. Consider edge cases and error handling

**Interview Preparation:**
- This problem has 40.7% frequency in technical interviews
- Expected to solve in 20-45 minutes during coding interviews
- Be prepared to discuss trade-offs and alternative approaches
- Practice explaining your thought process clearly

**Common Pitfalls:**
- Off-by-one errors in array/string indexing
- Not handling edge cases (empty input, single element, etc.)
- Incorrect complexity analysis
- Over-complicating the solution

**Optimization Tips:**
- Consider early termination conditions
- Minimize unnecessary data structure operations
- Use built-in language features efficiently
- Profile for performance on large inputs

---

*Generated for educational purposes. Problem source: [LeetCode](https://leetcode.com/problems/word-ladder)*
