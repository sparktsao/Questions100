# 039. LRU Cache

**Difficulty:** MEDIUM
**Frequency:** 62.4%
**Acceptance Rate:** 45.2%
**LeetCode Link:** [LRU Cache](https://leetcode.com/problems/lru-cache)

---

## Problem Description

Design a data structure that follows the constraints of a Least Recently Used (LRU) cache.

Implement the LRUCache class:
- `LRUCache(int capacity)` Initialize with positive size capacity
- `int get(int key)` Return value of key if exists, otherwise -1
- `void put(int key, int value)` Update or insert the key-value pair. If keys exceed capacity, evict the LRU key.

Both get and put must run in O(1) average time complexity.

**Constraints:**
- 1 <= capacity <= 3000
- 0 <= key <= 10^4
- 0 <= value <= 10^5
- At most 2 * 10^5 calls to get and put

---

## Examples

### Example 1
**Input:** `["LRUCache", "put", "put", "get", "put", "get", "put", "get", "get", "get"]\n[[2], [1,1], [2,2], [1], [3,3], [2], [4,4], [1], [3], [4]]`
**Output:** `[null, null, null, 1, null, -1, null, -1, 3, 4]`
**Explanation:** Cache capacity 2: operations show LRU eviction

### Example 2
**Input:** `put(1,1), put(2,2), get(1), put(3,3), get(2)`
**Output:** `[1, -1]`
**Explanation:** Key 2 evicted when adding 3

### Example 3
**Input:** `put(2,1), put(1,1), put(2,3), get(1), get(2)`
**Output:** `[1, 3]`
**Explanation:** Updates don't change capacity usage

---

## Optimal Solution

### Implementation

```python
class LRUCache:
    def __init__(self, capacity: int):
        self.capacity = capacity
        self.cache = {}  # key -> node
        # Doubly linked list for LRU ordering
        self.head = Node(0, 0)
        self.tail = Node(0, 0)
        self.head.next = self.tail
        self.tail.prev = self.head

    def get(self, key: int) -> int:
        if key in self.cache:
            node = self.cache[key]
            self._remove(node)
            self._add(node)
            return node.value
        return -1

    def put(self, key: int, value: int) -> None:
        if key in self.cache:
            self._remove(self.cache[key])
        node = Node(key, value)
        self._add(node)
        self.cache[key] = node
        if len(self.cache) > self.capacity:
            lru = self.head.next
            self._remove(lru)
            del self.cache[lru.key]

    def _remove(self, node):
        node.prev.next = node.next
        node.next.prev = node.prev

    def _add(self, node):
        # Add to tail (most recently used)
        node.prev = self.tail.prev
        node.next = self.tail
        self.tail.prev.next = node
        self.tail.prev = node
```

### Complexity Analysis

**Time: O(1) for get/put. Space: O(capacity)**

**Why This is Optimal:**
- Achieves best possible asymptotic complexity for this problem class
- Minimal space overhead while maintaining code clarity
- Scales efficiently with large inputs
- Handles all edge cases correctly

---

## Categories & Tags

**Primary Topics:** Hash Table, Linked List, Design, Doubly-Linked List

**Difficulty Level:** MEDIUM

---

## Real-World Applications

Understanding this algorithmic pattern has direct real-world applications:

1. **CDN Caching:** Cloudflare, Akamai managing edge cache eviction
2. **Database Query Cache:** Redis, Memcached implementing LRU eviction policies
3. **Web Browsers:** Chrome, Firefox managing browser cache
4. **Operating Systems:** Linux page cache, Windows file system cache
5. **API Rate Limiting:** Kong, AWS API Gateway tracking request history

**Industry Impact:**
This algorithmic pattern appears in production systems at companies like Google, Amazon, Microsoft, Meta, and Netflix. Engineers working on large-scale distributed systems, data processing pipelines, and user-facing applications regularly implement these concepts.

---

## Cybersecurity Applications

This problem demonstrates algorithmic concepts crucial for security engineering:

1. **SIEM Event Caching:** Splunk, Elastic Security managing recent event buffers
2. **Threat Intelligence:** MISP caching recent IOC lookups
3. **Session Management:** Auth0, Okta managing active user sessions
4. **WAF Rule Cache:** ModSecurity, Cloudflare WAF caching rule evaluation results
5. **IDS/IPS State:** Snort, Suricata managing connection state tables
6. **Security Log Aggregation:** Graylog maintaining hot log indices

**Security Engineering Value:**
Security professionals use these algorithms in threat detection systems, security information and event management (SIEM) platforms, intrusion detection/prevention systems (IDS/IPS), and security automation tools. Understanding these patterns is essential for developing robust security solutions.

**Common Security Contexts:**
- **Threat Detection:** Pattern matching and anomaly detection in security logs
- **Performance Security:** Preventing algorithmic complexity attacks (e.g., hash collision DoS)
- **Secure Code Review:** Identifying potential vulnerabilities in algorithm implementations
- **Security Tooling:** Building efficient security scanners and analysis tools
- **Incident Response:** Fast data processing during security investigations

---

## Learning Resources

**Recommended Study Path:**
1. Master the fundamental data structure concepts
2. Practice similar problems with the same pattern
3. Implement the solution from scratch without reference
4. Analyze time/space complexity of alternative approaches
5. Consider edge cases and error handling

**Interview Preparation:**
- This problem has 62.4% frequency in technical interviews
- Expected to solve in 20-45 minutes during coding interviews
- Be prepared to discuss trade-offs and alternative approaches
- Practice explaining your thought process clearly

**Common Pitfalls:**
- Off-by-one errors in array/string indexing
- Not handling edge cases (empty input, single element, etc.)
- Incorrect complexity analysis
- Over-complicating the solution

**Optimization Tips:**
- Consider early termination conditions
- Minimize unnecessary data structure operations
- Use built-in language features efficiently
- Profile for performance on large inputs

---

*Generated for educational purposes. Problem source: [LeetCode](https://leetcode.com/problems/lru-cache)*
