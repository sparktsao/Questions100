# 052. Minimum Add to Make Parentheses Valid

**Difficulty:** MEDIUM
**Frequency:** 51.9%
**Acceptance Rate:** 74.7%
**LeetCode Link:** [Minimum Add to Make Parentheses Valid](https://leetcode.com/problems/minimum-add-to-make-parentheses-valid)

---

## Problem Description

A parentheses string is valid if and only if:
- It is the empty string,
- It can be written as AB (A concatenated with B), where A and B are valid strings, or
- It can be written as (A), where A is a valid string.

You are given a parentheses string `s`. In one move, you can insert a parenthesis at any position of the string.

Return the minimum number of moves required to make `s` valid.

**Constraints:**
- 1 <= s.length <= 1000
- s[i] is either '(' or ')'

---

## Examples

### Example 1
**Input:** `s = "())"`
**Output:** `1`
**Explanation:** We can insert one opening parenthesis to make it "(())", or one closing parenthesis to make it "(()))".

### Example 2
**Input:** `s = "((("`
**Output:** `3`
**Explanation:** We need to add 3 closing parentheses to make it valid: "((()))"

### Example 3
**Input:** `s = "()"`
**Output:** `0`
**Explanation:** The string is already valid

### Example 4
**Input:** `s = "()))(("`
**Output:** `4`
**Explanation:** We need 2 opening parentheses at the start and 2 closing at the end

---

## Optimal Solution

### Implementation

```python
def minAddToMakeValid(s: str) -> int:
    """
    Count unmatched parentheses using counters.

    Time: O(n), Space: O(1)
    """
    open_needed = 0    # Count of unmatched ')'
    close_needed = 0   # Count of unmatched '('

    for char in s:
        if char == '(':
            close_needed += 1
        elif char == ')':
            if close_needed > 0:
                close_needed -= 1  # Match with previous '('
            else:
                open_needed += 1   # Need an '(' before this

    return open_needed + close_needed
```

### Alternative Implementation (Stack-Based)

```python
def minAddToMakeValid(s: str) -> int:
    """
    Stack-based solution for tracking unmatched parentheses.

    Time: O(n), Space: O(n) in worst case
    """
    stack = []
    unmatched = 0

    for char in s:
        if char == '(':
            stack.append(char)
        elif char == ')':
            if stack:
                stack.pop()
            else:
                unmatched += 1

    return unmatched + len(stack)
```

### Complexity Analysis

**Optimal Counter Approach:**
- **Time:** O(n) - single pass through string
- **Space:** O(1) - only two counter variables

**Stack Approach:**
- **Time:** O(n) - single pass through string
- **Space:** O(n) - stack can grow up to n in worst case

**Why Counter Approach is Optimal:**
- Achieves same result with O(1) space instead of O(n)
- No need to store actual parentheses, just count them
- More cache-friendly due to no dynamic allocations
- Simpler and more intuitive logic

---

## Categories & Tags

**Primary Topics:** String, Stack, Greedy

**Difficulty Level:** MEDIUM

---

## Real-World Applications

Understanding this algorithmic pattern has direct real-world applications:

1. **Code Editors:** VS Code, IntelliJ auto-fixing unmatched brackets and parentheses
2. **Compilers:** GCC, Clang error recovery counting missing delimiters in source code
3. **JSON/XML Validators:** Detecting and reporting missing braces/tags in configuration files
4. **Formula Editors:** Excel, Google Sheets calculating minimum fixes for formula syntax errors
5. **LaTeX Editors:** Overleaf, TeXworks auto-completing mathematical expression delimiters
6. **Template Engines:** Jinja2, Handlebars validating template syntax with paired delimiters

**Industry Impact:**
This pattern is used in static analysis tools, linters (ESLint, Pylint), and IDE plugins that provide real-time syntax error detection and auto-fix suggestions. Companies like JetBrains, Microsoft, and Google implement similar algorithms in their development tools.

---

## Cybersecurity Applications

This problem demonstrates algorithmic concepts crucial for security engineering:

1. **Input Validation:** WAF (ModSecurity, Cloudflare) detecting malformed input in SQL injection attempts
2. **XSS Prevention:** Sanitizing unbalanced HTML tags in user input to prevent cross-site scripting
3. **Protocol Analysis:** IDS/IPS (Snort, Suricata) validating protocol message structure
4. **Log Parsing:** SIEM tools (Splunk, ELK) handling malformed log entries with unmatched delimiters
5. **Security Scanners:** Static analysis tools detecting potential buffer overflow from unbalanced brackets
6. **Deobfuscation Tools:** Analyzing malware with intentionally broken syntax to evade detection

**Security Engineering Value:**
Understanding parentheses matching helps security engineers build robust input validators, detect evasion techniques in security logs, and develop parsers that handle malicious input gracefully without crashing or exposing vulnerabilities.

**Common Security Contexts:**
- **Threat Detection:** Identifying anomalous patterns in structured data
- **Performance Security:** Preventing ReDoS (Regular Expression Denial of Service) with balanced delimiters
- **Secure Code Review:** Finding potential parsing vulnerabilities in bracket handling
- **Security Tooling:** Building resilient parsers for security analysis tools
- **Incident Response:** Analyzing malformed logs during security investigations

---

## Learning Resources

**Recommended Study Path:**
1. Master basic parentheses matching with stack
2. Understand the greedy approach with counters
3. Practice similar problems: Valid Parentheses, Minimum Remove to Make Valid Parentheses
4. Compare stack vs counter approaches in different scenarios
5. Study applications in parser design and error recovery

**Interview Preparation:**
- This problem has 51.9% frequency in technical interviews
- Expected to solve in 15-25 minutes during coding interviews
- Be prepared to optimize from stack to counter approach
- Practice explaining why greedy approach works
- Common follow-up: handle multiple types of brackets

**Common Pitfalls:**
- Using stack when counters suffice (space inefficiency)
- Not handling edge cases: empty string, all open, all close
- Confusing "minimum additions" with "minimum removals"
- Off-by-one errors in counter logic

**Optimization Tips:**
- Prefer counter approach over stack for better space complexity
- Single pass is sufficient - no need for multiple iterations
- Early termination not beneficial here - must check entire string
- Consider the relationship to "Minimum Remove" problem

---

*Generated for educational purposes. Problem source: [LeetCode](https://leetcode.com/problems/minimum-add-to-make-parentheses-valid)*
