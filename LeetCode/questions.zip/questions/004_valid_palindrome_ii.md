# 004. Valid Palindrome II

**Difficulty:** EASY
**Frequency:** 92.7%
**Acceptance Rate:** 43.0%
**LeetCode Link:** [Valid Palindrome II](https://leetcode.com/problems/valid-palindrome-ii)

---

## Problem Description

Given a string `s`, return `true` if the `s` can be palindrome after deleting at most one character from it.

**Constraints:**
- 1 <= s.length <= 10^5
- s consists of lowercase English letters

---

## Examples

### Example 1
**Input:** `s = "aba"`
**Output:** `true`
**Explanation:** Already a palindrome, no deletion needed

### Example 2
**Input:** `s = "abca"`
**Output:** `true`
**Explanation:** Delete 'c' or 'b' to make palindrome

### Example 3
**Input:** `s = "abc"`
**Output:** `false`
**Explanation:** Cannot form palindrome with at most 1 deletion

### Example 4
**Input:** `s = "racecar"`
**Output:** `true`
**Explanation:** Already palindrome

---

## Optimal Solution

### Implementation

```python
def validPalindrome(s: str) -> bool:
    """
    Two pointers with one skip allowed.

    Time: O(n), Space: O(1)
    """
    def is_palindrome(left, right):
        while left < right:
            if s[left] != s[right]:
                return False
            left += 1
            right -= 1
        return True

    left, right = 0, len(s) - 1

    while left < right:
        if s[left] != s[right]:
            # Try skipping either left or right
            return is_palindrome(left + 1, right) or is_palindrome(left, right - 1)
        left += 1
        right -= 1

    return True
```

### Complexity Analysis

**Time: O(n) - at most one extra scan. Space: O(1) - constant**

**Why This is Optimal:**
- Achieves best possible asymptotic complexity for this problem class
- Minimal space overhead while maintaining code clarity
- Scales efficiently with large inputs
- Handles all edge cases correctly

---

## Categories & Tags

**Primary Topics:** Two Pointers, String, Greedy

**Difficulty Level:** EASY

---

## Real-World Applications

Understanding this algorithmic pattern has direct real-world applications:

1. **DNA Analysis:** BLAST detecting near-palindromic sequences with mutations
2. **Text Validation:** Spell checkers allowing one character error
3. **Data Deduplication:** Finding near-duplicate records with single difference
4. **String Matching:** Search engines fuzzy matching with one edit
5. **Data Quality:** ETL pipelines validating data with tolerance

**Industry Impact:**
This algorithmic pattern appears in production systems at companies like Google, Amazon, Microsoft, Meta, and Netflix. Engineers working on large-scale distributed systems, data processing pipelines, and user-facing applications regularly implement these concepts.

---

## Cybersecurity Applications

This problem demonstrates algorithmic concepts crucial for security engineering:

1. **Malware Variants:** Detecting polymorphic malware with single byte change
2. **Password Fuzzing:** Testing password policies with single character variations
3. **Signature Evasion:** IDS detecting obfuscated patterns with one alteration
4. **Domain Squatting:** Finding typosquatting domains with one character off
5. **Log Anomaly:** SIEM detecting log tampering with single character edit
6. **Hash Collision:** Finding near-collision attacks in cryptographic hashes

**Security Engineering Value:**
Security professionals use these algorithms in threat detection systems, security information and event management (SIEM) platforms, intrusion detection/prevention systems (IDS/IPS), and security automation tools. Understanding these patterns is essential for developing robust security solutions.

**Common Security Contexts:**
- **Threat Detection:** Pattern matching and anomaly detection in security logs
- **Performance Security:** Preventing algorithmic complexity attacks (e.g., hash collision DoS)
- **Secure Code Review:** Identifying potential vulnerabilities in algorithm implementations
- **Security Tooling:** Building efficient security scanners and analysis tools
- **Incident Response:** Fast data processing during security investigations

---

## Learning Resources

**Recommended Study Path:**
1. Master the fundamental data structure concepts
2. Practice similar problems with the same pattern
3. Implement the solution from scratch without reference
4. Analyze time/space complexity of alternative approaches
5. Consider edge cases and error handling

**Interview Preparation:**
- This problem has 92.7% frequency in technical interviews
- Expected to solve in 20-45 minutes during coding interviews
- Be prepared to discuss trade-offs and alternative approaches
- Practice explaining your thought process clearly

**Common Pitfalls:**
- Off-by-one errors in array/string indexing
- Not handling edge cases (empty input, single element, etc.)
- Incorrect complexity analysis
- Over-complicating the solution

**Optimization Tips:**
- Consider early termination conditions
- Minimize unnecessary data structure operations
- Use built-in language features efficiently
- Profile for performance on large inputs

---

*Generated for educational purposes. Problem source: [LeetCode](https://leetcode.com/problems/valid-palindrome-ii)*
