# 089. Range Sum Query - Immutable

**Difficulty:** EASY
**Frequency:** 32.0%
**Acceptance Rate:** 68.5%
**LeetCode Link:** [Range Sum Query - Immutable](https://leetcode.com/problems/range-sum-query-immutable)

---

## Problem Description

Given an integer array `nums`, handle multiple queries of the following type:

Calculate the sum of the elements of `nums` between indices `left` and `right` inclusive where `left <= right`.

Implement the `NumArray` class:
- `NumArray(int[] nums)` Initializes the object with the integer array `nums`.
- `int sumRange(int left, int right)` Returns the sum of the elements of `nums` between indices `left` and `right` inclusive (i.e., `nums[left] + nums[left + 1] + ... + nums[right]`).

**Constraints:**
- 1 <= nums.length <= 10^4
- -10^5 <= nums[i] <= 10^5
- 0 <= left <= right < nums.length
- At most 10^4 calls will be made to sumRange

---

## Examples

### Example 1
**Input:**
```
["NumArray", "sumRange", "sumRange", "sumRange"]
[[[-2, 0, 3, -5, 2, -1]], [0, 2], [2, 5], [0, 5]]
```
**Output:** `[null, 1, -1, -3]`
**Explanation:**
```
NumArray numArray = new NumArray([-2, 0, 3, -5, 2, -1]);
numArray.sumRange(0, 2); // return (-2) + 0 + 3 = 1
numArray.sumRange(2, 5); // return 3 + (-5) + 2 + (-1) = -1
numArray.sumRange(0, 5); // return (-2) + 0 + 3 + (-5) + 2 + (-1) = -3
```

### Example 2
**Input:**
```
["NumArray", "sumRange", "sumRange"]
[[[1]], [0, 0], [0, 0]]
```
**Output:** `[null, 1, 1]`
**Explanation:** Single element array

### Example 3
**Input:**
```
["NumArray", "sumRange"]
[[[5, -3, 4]], [1, 2]]
```
**Output:** `[null, 1]`
**Explanation:** sumRange(1, 2) = -3 + 4 = 1

### Example 4
**Input:**
```
["NumArray", "sumRange", "sumRange"]
[[[1, 2, 3, 4, 5]], [0, 4], [2, 3]]
```
**Output:** `[null, 15, 7]`
**Explanation:** Multiple range queries

---

## Optimal Solution

### Implementation

```python
class NumArray:
    """
    Range Sum Query using Prefix Sum.

    Time: O(n) initialization, O(1) per query
    Space: O(n) for prefix sum array
    """

    def __init__(self, nums: List[int]):
        """
        Initialize with prefix sum array.
        prefix_sum[i] = sum of nums[0..i-1]
        """
        self.prefix_sum = [0]

        # Build prefix sum array
        for num in nums:
            self.prefix_sum.append(self.prefix_sum[-1] + num)

    def sumRange(self, left: int, right: int) -> int:
        """
        Return sum of elements from left to right inclusive.

        Sum[left, right] = prefix_sum[right+1] - prefix_sum[left]
        """
        return self.prefix_sum[right + 1] - self.prefix_sum[left]
```

### Alternative Implementation

```python
class NumArray:
    """
    Alternative prefix sum implementation.
    """

    def __init__(self, nums: List[int]):
        self.nums = nums
        self.n = len(nums)

        # Build prefix sum: prefix[i] = sum(nums[0:i+1])
        self.prefix = [0] * self.n

        self.prefix[0] = nums[0]
        for i in range(1, self.n):
            self.prefix[i] = self.prefix[i - 1] + nums[i]

    def sumRange(self, left: int, right: int) -> int:
        """O(1) query time"""
        if left == 0:
            return self.prefix[right]

        return self.prefix[right] - self.prefix[left - 1]
```

### Complexity Analysis

**Initialization: O(n) - build prefix sum array. Query: O(1) - simple subtraction**
**Space: O(n) - store prefix sum array**

**Why This is Optimal:**
- Preprocessing with prefix sums enables O(1) queries
- Trade initialization time for fast repeated queries
- Optimal for scenarios with many sumRange calls
- Handles negative numbers correctly
- No complex data structures needed

---

## Categories & Tags

**Primary Topics:** Array, Design, Prefix Sum

**Difficulty Level:** EASY

---

## Real-World Applications

Understanding this algorithmic pattern has direct real-world applications:

1. **Database Query Optimization:** PostgreSQL and MySQL using materialized views for aggregate queries on time-series data
2. **Financial Analytics:** Bloomberg Terminal calculating cumulative returns and moving averages in real-time trading
3. **Data Warehousing:** Snowflake and BigQuery using pre-aggregated tables for fast OLAP queries
4. **Time Series Analysis:** Prometheus and Grafana computing range-based metrics for monitoring dashboards
5. **Game Development:** Unity and Unreal Engine calculating damage totals over time ranges in combat systems

**Industry Impact:**
This algorithmic pattern appears in production systems at financial institutions (Goldman Sachs trading platforms), cloud analytics (AWS QuickSight, Tableau), and monitoring tools (Datadog, New Relic). Engineers working on analytics, reporting, and time-series systems regularly implement these concepts.

---

## Cybersecurity Applications

This problem demonstrates algorithmic concepts crucial for security engineering:

1. **Security Metrics Dashboards:** Splunk and ELK Stack calculating event counts over time windows for SOC dashboards
2. **Network Traffic Analysis:** Wireshark computing bandwidth usage over time ranges for anomaly detection
3. **Log Aggregation:** Graylog and Fluentd calculating error rates and alert frequencies in time windows
4. **Threat Intelligence:** MISP calculating IOC occurrence frequencies across date ranges
5. **Compliance Reporting:** Security frameworks generating audit statistics over reporting periods
6. **Rate Limiting:** API gateways tracking request counts in sliding time windows for DDoS prevention

**Security Engineering Value:**
Security professionals use prefix sum techniques in SIEM platforms to efficiently query event counts over arbitrary time ranges, in threat intelligence platforms to analyze trend data, and in compliance systems to generate period-based metrics without scanning raw data repeatedly.

**Common Security Contexts:**
- **Threat Detection:** Efficiently querying security event frequencies in time windows
- **Performance Security:** Monitoring resource usage patterns to detect abuse
- **Secure Code Review:** Understanding efficient data structure design for auditing systems
- **Security Tooling:** Building fast analytics for security dashboards
- **Incident Response:** Quickly analyzing event volumes during investigations

---

## Learning Resources

**Recommended Study Path:**
1. Understand prefix sum concept and its applications
2. Practice cumulative sum problems
3. Study similar problems: Range Sum Query 2D (304), Subarray Sum Equals K (560)
4. Learn about segment trees for mutable arrays
5. Explore difference arrays for range update queries

**Interview Preparation:**
- This problem has 32.0% frequency in technical interviews
- Expected to solve in 10-15 minutes during coding interviews
- Be prepared to discuss trade-offs between preprocessing and query time
- Practice explaining why prefix sum enables O(1) queries

**Common Pitfalls:**
- Off-by-one errors in prefix sum indexing
- Not handling left = 0 edge case correctly
- Confusing prefix[i] definition (inclusive vs exclusive)
- Inefficient O(n) per query without preprocessing
- Integer overflow for very large sums (language-dependent)

**Optimization Tips:**
- Use extra element at start to simplify edge cases
- Consider lazy evaluation if queries are infrequent
- For mutable arrays, use Segment Tree or Fenwick Tree instead
- Cache frequently requested ranges if applicable
- Handle overflow with appropriate data types

---

*Generated for educational purposes. Problem source: [LeetCode](https://leetcode.com/problems/range-sum-query-immutable)*
