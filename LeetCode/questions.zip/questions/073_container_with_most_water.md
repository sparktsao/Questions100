# 073. Container With Most Water

**Difficulty:** MEDIUM
**Frequency:** 40.7%
**Acceptance Rate:** 57.8%
**LeetCode Link:** [Container With Most Water](https://leetcode.com/problems/container-with-most-water)

---

## Problem Description

You are given an integer array `height` of length `n`. There are `n` vertical lines drawn such that the two endpoints of the `i-th` line are `(i, 0)` and `(i, height[i])`.

Find two lines that together with the x-axis form a container, such that the container contains the most water.

Return the maximum amount of water a container can store.

**Note:** You may not slant the container.

**Constraints:**
- `n == height.length`
- `2 <= n <= 10^5`
- `0 <= height[i] <= 10^4`

---

## Examples

### Example 1
**Input:** `height = [1,8,6,2,5,4,8,3,7]`
**Output:** `49`
**Explanation:** The vertical lines are represented by array [1,8,6,2,5,4,8,3,7]. The max area of water the container can contain is 49, formed between indices 1 and 8: Area = min(8, 7) × (8 - 1) = 7 × 7 = 49

### Example 2
**Input:** `height = [1,1]`
**Output:** `1`
**Explanation:** Two lines of height 1 at distance 1 apart: Area = 1 × 1 = 1

### Example 3
**Input:** `height = [4,3,2,1,4]`
**Output:** `16`
**Explanation:** The maximum area is between indices 0 and 4: Area = min(4, 4) × (4 - 0) = 4 × 4 = 16

### Example 4
**Input:** `height = [1,2,1]`
**Output:** `2`
**Explanation:** Maximum area between indices 0 and 2: Area = min(1, 1) × (2 - 0) = 1 × 2 = 2

---

## Optimal Solution

### Implementation

```python
def maxArea(height: List[int]) -> int:
    """
    Two-pointer approach to find maximum water container area.

    Time: O(n), Space: O(1)
    """
    left = 0
    right = len(height) - 1
    max_area = 0

    while left < right:
        # Calculate current area
        width = right - left
        current_height = min(height[left], height[right])
        current_area = width * current_height
        max_area = max(max_area, current_area)

        # Move the pointer pointing to the shorter line
        # Moving the taller line won't improve the result
        if height[left] < height[right]:
            left += 1
        else:
            right -= 1

    return max_area
```

### Complexity Analysis

**Time: O(n) - single pass with two pointers. Space: O(1) - constant extra space**

**Why This is Optimal:**
- Achieves best possible asymptotic complexity for this problem class
- Greedy approach guarantees finding the maximum by eliminating suboptimal configurations
- Area is limited by the shorter line, so we move that pointer inward
- Each iteration reduces search space without missing the optimal solution
- Minimal space overhead while maintaining code clarity

---

## Categories & Tags

**Primary Topics:** Array, Two Pointers, Greedy

**Difficulty Level:** MEDIUM

---

## Real-World Applications

Understanding this algorithmic pattern has direct real-world applications:

1. **Resource Allocation:** AWS EC2 capacity planning for paired availability zones maximizing service availability
2. **Network Optimization:** Load balancer traffic distribution between server pairs in data centers (F5 Networks, HAProxy)
3. **Financial Trading:** Stock pair trading strategies maximizing profit window between buy/sell points
4. **Storage Management:** RAID array optimization pairing disks to maximize redundancy capacity (NetApp, EMC)
5. **Supply Chain:** Warehouse pairing for optimal inventory distribution in logistics networks (Amazon fulfillment centers)

**Industry Impact:**
This two-pointer greedy optimization pattern appears in production systems at companies like Google (network routing), Amazon (warehouse optimization), Microsoft Azure (resource pairing), Meta (data center load balancing), and Netflix (content delivery node selection). Engineers working on resource optimization, capacity planning, and pairing algorithms regularly implement these concepts.

---

## Cybersecurity Applications

This problem demonstrates algorithmic concepts crucial for security engineering:

1. **DDoS Mitigation:** Cloudflare/Akamai optimizing request routing between edge servers to maximize legitimate traffic throughput
2. **Firewall Rule Optimization:** Palo Alto Networks pairing rule sets to maximize protection coverage with minimal performance impact
3. **Intrusion Detection:** Snort/Suricata optimizing packet inspection windows between network tap points
4. **Rate Limiting:** API gateway throttling (Kong, Tyk) pairing time windows for optimal protection vs. user experience
5. **Security Scanning:** Nessus/OpenVAS optimizing scan intensity between time windows to maximize coverage
6. **Log Analysis:** Splunk/ELK Stack optimizing correlation windows between security events

**Security Engineering Value:**
Security professionals use these optimization algorithms in capacity planning for security infrastructure, optimizing detection windows in SIEM platforms, configuring rate limiting in web application firewalls, and balancing security controls vs. performance overhead. Understanding greedy optimization is essential for developing efficient security solutions that don't degrade system performance.

**Common Security Contexts:**
- **Threat Detection:** Optimizing detection windows and resource allocation in security monitoring
- **Performance Security:** Balancing security controls with system performance requirements
- **Secure Code Review:** Identifying efficient algorithms that prevent resource exhaustion attacks
- **Security Tooling:** Building optimized security scanners with minimal performance impact
- **Incident Response:** Optimizing log analysis time windows during security investigations

---

## Learning Resources

**Recommended Study Path:**
1. Master the fundamental two-pointer technique concepts
2. Practice similar problems: Trapping Rain Water, 3Sum, Container problems
3. Implement the solution from scratch without reference
4. Analyze why moving the shorter line is always optimal
5. Consider edge cases: all same heights, monotonic sequences

**Interview Preparation:**
- This problem has 40.7% frequency in technical interviews
- Expected to solve in 20-45 minutes during coding interviews
- Be prepared to explain the greedy choice and why it's optimal
- Practice explaining the two-pointer movement strategy clearly

**Common Pitfalls:**
- Moving both pointers simultaneously (loses optimal solution)
- Not understanding why we move the shorter line
- Attempting brute force O(n²) solution checking all pairs
- Off-by-one errors in width calculation

**Optimization Tips:**
- Recognize this as a greedy two-pointer problem
- Understand the invariant: area is limited by min(height)
- Early termination if remaining width can't beat current max
- Use straightforward min() for readability

---

*Generated for educational purposes. Problem source: [LeetCode](https://leetcode.com/problems/container-with-most-water)*
