# 006. Kth Largest Element in an Array

**Difficulty:** MEDIUM
**Frequency:** 86.9%
**Acceptance Rate:** 68.0%
**LeetCode Link:** [Kth Largest Element in an Array](https://leetcode.com/problems/kth-largest-element-in-an-array)

---

## Problem Description

Given an integer array `nums` and an integer `k`, return the `kth` largest element in the array.

Note that it is the `kth` largest element in the sorted order, not the `kth` distinct element.

Can you solve it without sorting?

**Constraints:**
- 1 <= k <= nums.length <= 10^5
- -10^4 <= nums[i] <= 10^4

---

## Examples

### Example 1
**Input:** `nums = [3,2,1,5,6,4], k = 2`
**Output:** `5`
**Explanation:** Sorted: [1,2,3,4,5,6], 2nd largest is 5

### Example 2
**Input:** `nums = [3,2,3,1,2,4,5,5,6], k = 4`
**Output:** `4`
**Explanation:** Sorted: [1,2,2,3,3,4,5,5,6], 4th largest is 4

### Example 3
**Input:** `nums = [1], k = 1`
**Output:** `1`
**Explanation:** Single element

### Example 4
**Input:** `nums = [2,1], k = 1`
**Output:** `2`
**Explanation:** Largest of two elements

---

## Optimal Solution

### Implementation

```python
def findKthLargest(nums: List[int], k: int) -> int:
    """
    Use min heap of size k for optimal solution.

    Time: O(n log k), Space: O(k)
    """
    import heapq
    # Maintain min heap of k largest elements
    heap = nums[:k]
    heapq.heapify(heap)

    for num in nums[k:]:
        if num > heap[0]:
            heapq.heapreplace(heap, num)

    return heap[0]
```

### Complexity Analysis

**Time: O(n log k) - heap operations. Space: O(k) - heap storage**

**Why This is Optimal:**
- Achieves best possible asymptotic complexity for this problem class
- Minimal space overhead while maintaining code clarity
- Scales efficiently with large inputs
- Handles all edge cases correctly

---

## Categories & Tags

**Primary Topics:** Array, Divide and Conquer, Sorting, Heap (Priority Queue), Quickselect

**Difficulty Level:** MEDIUM

---

## Real-World Applications

Understanding this algorithmic pattern has direct real-world applications:

1. **Analytics Dashboards:** Google Analytics top K pages by traffic
2. **E-commerce:** Amazon/eBay top K products by sales
3. **Social Media:** Twitter/Instagram top K trending posts
4. **Database Queries:** MySQL/PostgreSQL ORDER BY LIMIT optimization
5. **Load Balancing:** Finding top K loaded servers for redistribution

**Industry Impact:**
This algorithmic pattern appears in production systems at companies like Google, Amazon, Microsoft, Meta, and Netflix. Engineers working on large-scale distributed systems, data processing pipelines, and user-facing applications regularly implement these concepts.

---

## Cybersecurity Applications

This problem demonstrates algorithmic concepts crucial for security engineering:

1. **Threat Prioritization:** Splunk top K critical security alerts
2. **Attack Detection:** Finding top K IPs by failed login attempts
3. **Vulnerability Scanning:** Nessus/OpenVAS top K critical CVEs
4. **Network Analysis:** Wireshark top K packets by size/frequency
5. **Log Analysis:** ELK finding top K error codes in security logs
6. **Malware Analysis:** Top K suspicious processes by resource usage

**Security Engineering Value:**
Security professionals use these algorithms in threat detection systems, security information and event management (SIEM) platforms, intrusion detection/prevention systems (IDS/IPS), and security automation tools. Understanding these patterns is essential for developing robust security solutions.

**Common Security Contexts:**
- **Threat Detection:** Pattern matching and anomaly detection in security logs
- **Performance Security:** Preventing algorithmic complexity attacks (e.g., hash collision DoS)
- **Secure Code Review:** Identifying potential vulnerabilities in algorithm implementations
- **Security Tooling:** Building efficient security scanners and analysis tools
- **Incident Response:** Fast data processing during security investigations

---

## Learning Resources

**Recommended Study Path:**
1. Master the fundamental data structure concepts
2. Practice similar problems with the same pattern
3. Implement the solution from scratch without reference
4. Analyze time/space complexity of alternative approaches
5. Consider edge cases and error handling

**Interview Preparation:**
- This problem has 86.9% frequency in technical interviews
- Expected to solve in 20-45 minutes during coding interviews
- Be prepared to discuss trade-offs and alternative approaches
- Practice explaining your thought process clearly

**Common Pitfalls:**
- Off-by-one errors in array/string indexing
- Not handling edge cases (empty input, single element, etc.)
- Incorrect complexity analysis
- Over-complicating the solution

**Optimization Tips:**
- Consider early termination conditions
- Minimize unnecessary data structure operations
- Use built-in language features efficiently
- Profile for performance on large inputs

---

*Generated for educational purposes. Problem source: [LeetCode](https://leetcode.com/problems/kth-largest-element-in-an-array)*
