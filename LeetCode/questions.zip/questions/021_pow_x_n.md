# 021. Pow(x, n)

**Difficulty:** MEDIUM
**Frequency:** 74.9%
**Acceptance Rate:** 37.0%
**LeetCode Link:** [Pow(x, n)](https://leetcode.com/problems/powx-n)

---

## Problem Description

Implement `pow(x, n)`, which calculates `x` raised to the power `n` (i.e., `x^n`).

**Constraints:**
- -100.0 < x < 100.0
- -2^31 <= n <= 2^31-1
- -10^4 <= x^n <= 10^4

---

## Examples

### Example 1
**Input:** `x = 2.00000, n = 10`
**Output:** `1024.00000`
**Explanation:** 2^10 = 1024

### Example 2
**Input:** `x = 2.10000, n = 3`
**Output:** `9.26100`
**Explanation:** 2.1^3 = 9.261

### Example 3
**Input:** `x = 2.00000, n = -2`
**Output:** `0.25000`
**Explanation:** 2^-2 = 1/4 = 0.25

### Example 4
**Input:** `x = 0.00001, n = 2147483647`
**Output:** `0.00000`
**Explanation:** Very small number with large exponent

---

## Optimal Solution

### Implementation

```python
def myPow(x: float, n: int) -> float:
    """
    Fast power using binary exponentiation (divide and conquer).

    Time: O(log n), Space: O(log n) for recursion
    """
    def helper(x, n):
        if n == 0:
            return 1.0

        # Calculate half power
        half = helper(x, n // 2)

        if n % 2 == 0:
            return half * half
        else:
            return half * half * x

    result = helper(x, abs(n))
    return result if n >= 0 else 1 / result
```

### Complexity Analysis

**Time: O(log n) - divide problem by 2 each step. Space: O(log n) - recursion depth**

**Why This is Optimal:**
- Achieves best possible asymptotic complexity for this problem class
- Minimal space overhead while maintaining code clarity
- Scales efficiently with large inputs
- Handles all edge cases correctly

---

## Categories & Tags

**Primary Topics:** Math, Recursion

**Difficulty Level:** MEDIUM

---

## Real-World Applications

Understanding this algorithmic pattern has direct real-world applications:

1. **Scientific Computing:** NumPy/SciPy matrix exponentials in machine learning
2. **Financial Modeling:** Compound interest calculations in banking systems
3. **Graphics Rendering:** OpenGL transformation matrix computations
4. **Cryptography:** RSA encryption modular exponentiation (OpenSSL)
5. **Database Systems:** MySQL/PostgreSQL power functions in queries
6. **Game Engines:** Unity/Unreal physics calculations for acceleration

**Industry Impact:**
This algorithmic pattern appears in production systems at companies like Google, Amazon, Microsoft, Meta, and Netflix. Engineers working on large-scale distributed systems, data processing pipelines, and user-facing applications regularly implement these concepts.

---

## Cybersecurity Applications

This problem demonstrates algorithmic concepts crucial for security engineering:

1. **Public Key Cryptography:** RSA encryption using modular exponentiation
2. **Diffie-Hellman:** Key exchange protocol power computations
3. **Digital Signatures:** DSA signature generation using exponentiation
4. **Hash Functions:** Cryptographic hash strength analysis (2^n operations)
5. **Blockchain:** Proof-of-work difficulty calculations (Bitcoin mining)
6. **Password Cracking:** Estimating brute force complexity (26^n combinations)
7. **Elliptic Curve Crypto:** ECC point multiplication in TLS/SSL

**Security Engineering Value:**
Security professionals use these algorithms in threat detection systems, security information and event management (SIEM) platforms, intrusion detection/prevention systems (IDS/IPS), and security automation tools. Understanding these patterns is essential for developing robust security solutions.

**Common Security Contexts:**
- **Threat Detection:** Pattern matching and anomaly detection in security logs
- **Performance Security:** Preventing algorithmic complexity attacks (e.g., hash collision DoS)
- **Secure Code Review:** Identifying potential vulnerabilities in algorithm implementations
- **Security Tooling:** Building efficient security scanners and analysis tools
- **Incident Response:** Fast data processing during security investigations

---

## Learning Resources

**Recommended Study Path:**
1. Master the fundamental data structure concepts
2. Practice similar problems with the same pattern
3. Implement the solution from scratch without reference
4. Analyze time/space complexity of alternative approaches
5. Consider edge cases and error handling

**Interview Preparation:**
- This problem has 74.9% frequency in technical interviews
- Expected to solve in 20-45 minutes during coding interviews
- Be prepared to discuss trade-offs and alternative approaches
- Practice explaining your thought process clearly

**Common Pitfalls:**
- Off-by-one errors in array/string indexing
- Not handling edge cases (empty input, single element, etc.)
- Incorrect complexity analysis
- Over-complicating the solution

**Optimization Tips:**
- Consider early termination conditions
- Minimize unnecessary data structure operations
- Use built-in language features efficiently
- Profile for performance on large inputs

---

*Generated for educational purposes. Problem source: [LeetCode](https://leetcode.com/problems/powx-n)*
