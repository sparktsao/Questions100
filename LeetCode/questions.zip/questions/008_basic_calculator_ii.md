# 008. Basic Calculator II

**Difficulty:** MEDIUM
**Frequency:** 84.0%
**Acceptance Rate:** 45.8%
**LeetCode Link:** [Basic Calculator II](https://leetcode.com/problems/basic-calculator-ii)

---

## Problem Description

Given a string `s` which represents an expression, evaluate this expression and return its value.

The integer division should truncate toward zero.

You may assume that the given expression is always valid. All intermediate results will be in the range of [-2^31, 2^31 - 1].

**Note:** You are not allowed to use any built-in function which evaluates strings as mathematical expressions, such as eval().

**Constraints:**
- 1 <= s.length <= 3 * 10^5
- s consists of integers and operators ('+', '-', '*', '/') separated by spaces
- s represents a valid expression
- All integers are non-negative
- The answer is guaranteed to fit in 32-bit integer

---

## Examples

### Example 1
**Input:** `s = "3+2*2"`
**Output:** `7`
**Explanation:** Multiplication has higher precedence

### Example 2
**Input:** `s = " 3/2 "`
**Output:** `1`
**Explanation:** Division truncates toward zero

### Example 3
**Input:** `s = " 3+5 / 2 "`
**Output:** `5`
**Explanation:** 5/2 = 2, then 3+2 = 5

### Example 4
**Input:** `s = "42"`
**Output:** `42`
**Explanation:** Single number

---

## Optimal Solution

### Implementation

```python
def calculate(s: str) -> int:
    """
    Stack-based calculator with operator precedence.

    Time: O(n), Space: O(n)
    """
    if not s:
        return 0

    stack = []
    num = 0
    sign = '+'

    for i, char in enumerate(s):
        if char.isdigit():
            num = num * 10 + int(char)

        if char in '+-*/' or i == len(s) - 1:
            if sign == '+':
                stack.append(num)
            elif sign == '-':
                stack.append(-num)
            elif sign == '*':
                stack.append(stack.pop() * num)
            elif sign == '/':
                stack.append(int(stack.pop() / num))

            if char in '+-*/':
                sign = char
                num = 0

    return sum(stack)
```

### Complexity Analysis

**Time: O(n) - single pass. Space: O(n) - stack storage**

**Why This is Optimal:**
- Achieves best possible asymptotic complexity for this problem class
- Minimal space overhead while maintaining code clarity
- Scales efficiently with large inputs
- Handles all edge cases correctly

---

## Categories & Tags

**Primary Topics:** Math, String, Stack

**Difficulty Level:** MEDIUM

---

## Real-World Applications

Understanding this algorithmic pattern has direct real-world applications:

1. **Spreadsheets:** Excel/Google Sheets formula evaluation
2. **Programming Languages:** Python/JavaScript expression parsing
3. **Database Queries:** SQL calculated fields in SELECT statements
4. **Configuration Files:** Nginx/Apache evaluating numeric expressions
5. **Scientific Calculators:** Casio/TI calculator expression evaluation

**Industry Impact:**
This algorithmic pattern appears in production systems at companies like Google, Amazon, Microsoft, Meta, and Netflix. Engineers working on large-scale distributed systems, data processing pipelines, and user-facing applications regularly implement these concepts.

---

## Cybersecurity Applications

This problem demonstrates algorithmic concepts crucial for security engineering:

1. **SQL Injection:** Detecting mathematical expressions in SQLi payloads
2. **Expression Injection:** Preventing code injection via eval-like functions
3. **WAF Rules:** ModSecurity parsing arithmetic in attack patterns
4. **Log Analysis:** SIEM evaluating threshold expressions in rules
5. **Fuzzing:** AFL testing calculator/parser input validation
6. **Template Injection:** Detecting SSTI in Jinja2/Twig templates

**Security Engineering Value:**
Security professionals use these algorithms in threat detection systems, security information and event management (SIEM) platforms, intrusion detection/prevention systems (IDS/IPS), and security automation tools. Understanding these patterns is essential for developing robust security solutions.

**Common Security Contexts:**
- **Threat Detection:** Pattern matching and anomaly detection in security logs
- **Performance Security:** Preventing algorithmic complexity attacks (e.g., hash collision DoS)
- **Secure Code Review:** Identifying potential vulnerabilities in algorithm implementations
- **Security Tooling:** Building efficient security scanners and analysis tools
- **Incident Response:** Fast data processing during security investigations

---

## Learning Resources

**Recommended Study Path:**
1. Master the fundamental data structure concepts
2. Practice similar problems with the same pattern
3. Implement the solution from scratch without reference
4. Analyze time/space complexity of alternative approaches
5. Consider edge cases and error handling

**Interview Preparation:**
- This problem has 84.0% frequency in technical interviews
- Expected to solve in 20-45 minutes during coding interviews
- Be prepared to discuss trade-offs and alternative approaches
- Practice explaining your thought process clearly

**Common Pitfalls:**
- Off-by-one errors in array/string indexing
- Not handling edge cases (empty input, single element, etc.)
- Incorrect complexity analysis
- Over-complicating the solution

**Optimization Tips:**
- Consider early termination conditions
- Minimize unnecessary data structure operations
- Use built-in language features efficiently
- Profile for performance on large inputs

---

*Generated for educational purposes. Problem source: [LeetCode](https://leetcode.com/problems/basic-calculator-ii)*
