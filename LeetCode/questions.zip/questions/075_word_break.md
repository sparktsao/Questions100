# 075. Word Break

**Difficulty:** MEDIUM
**Frequency:** 40.7%
**Acceptance Rate:** 48.3%
**LeetCode Link:** [Word Break](https://leetcode.com/problems/word-break)

---

## Problem Description

Given a string `s` and a dictionary of strings `wordDict`, return `true` if `s` can be segmented into a space-separated sequence of one or more dictionary words.

**Note:** The same word in the dictionary may be reused multiple times in the segmentation.

**Constraints:**
- `1 <= s.length <= 300`
- `1 <= wordDict.length <= 1000`
- `1 <= wordDict[i].length <= 20`
- `s` and `wordDict[i]` consist of only lowercase English letters
- All the strings of `wordDict` are unique

---

## Examples

### Example 1
**Input:** `s = "leetcode", wordDict = ["leet","code"]`
**Output:** `true`
**Explanation:** Return true because "leetcode" can be segmented as "leet code".

### Example 2
**Input:** `s = "applepenapple", wordDict = ["apple","pen"]`
**Output:** `true`
**Explanation:** Return true because "applepenapple" can be segmented as "apple pen apple". Note that you are allowed to reuse a dictionary word.

### Example 3
**Input:** `s = "catsandog", wordDict = ["cats","dog","sand","and","cat"]`
**Output:** `false`
**Explanation:** No valid segmentation exists. "catsand" + "og" doesn't work because "og" is not in the dictionary.

### Example 4
**Input:** `s = "cars", wordDict = ["car","ca","rs"]`
**Output:** `true`
**Explanation:** Can be segmented as "car s" or "ca rs".

---

## Optimal Solution

### Implementation

```python
def wordBreak(s: str, wordDict: List[str]) -> bool:
    """
    Dynamic programming solution to check if string can be segmented.

    Time: O(n² × m), Space: O(n)
    where n is string length, m is average word length
    """
    word_set = set(wordDict)
    n = len(s)

    # dp[i] = True if s[0:i] can be segmented
    dp = [False] * (n + 1)
    dp[0] = True  # Empty string is valid

    for i in range(1, n + 1):
        for j in range(i):
            # Check if s[0:j] is valid AND s[j:i] is in dictionary
            if dp[j] and s[j:i] in word_set:
                dp[i] = True
                break  # Found valid segmentation for s[0:i]

    return dp[n]
```

### Alternative Implementation (Optimized)

```python
def wordBreak(s: str, wordDict: List[str]) -> bool:
    """
    Optimized DP with max word length constraint.

    Time: O(n × m × k), Space: O(n)
    where k is max word length
    """
    word_set = set(wordDict)
    max_len = max(len(word) for word in wordDict)
    n = len(s)

    dp = [False] * (n + 1)
    dp[0] = True

    for i in range(1, n + 1):
        # Only check substrings up to max word length
        for j in range(max(0, i - max_len), i):
            if dp[j] and s[j:i] in word_set:
                dp[i] = True
                break

    return dp[n]
```

### Complexity Analysis

**Time: O(n² × m) - nested loops with substring operations. Space: O(n) - DP array plus set storage**

**Optimized Time: O(n × k × m) - where k is max word length, typically much better in practice**

**Why This is Optimal:**
- DP approach avoids redundant computation by memoizing subproblem solutions
- Converting wordDict to set provides O(1) average lookup time
- Early termination (break) once valid segmentation found for position i
- Bottom-up DP eliminates recursion overhead
- Optimization using max word length significantly reduces inner loop iterations

---

## Categories & Tags

**Primary Topics:** Array, Hash Table, String, Dynamic Programming, Trie, Memoization

**Difficulty Level:** MEDIUM

---

## Real-World Applications

Understanding this algorithmic pattern has direct real-world applications:

1. **Natural Language Processing:** Google Translate/DeepL word segmentation for languages without spaces (Chinese, Japanese, Thai)
2. **Search Engines:** Google/Bing query parsing - breaking search queries into meaningful terms for better results
3. **Spell Checkers:** Microsoft Word/Grammarly compound word validation and correction suggestions
4. **Code Completion:** IntelliJ IDEA/VS Code IntelliSense breaking camelCase/snake_case identifiers into words
5. **DNA Sequencing:** BLAST genome analysis segmenting DNA sequences into known gene patterns
6. **URL Parsing:** Web crawlers (Googlebot) segmenting domain names and paths into meaningful components

**Industry Impact:**
This dynamic programming pattern for string segmentation appears in production NLP pipelines at Google (search query understanding), Amazon (product search), Meta (content understanding), and Microsoft (Office suite). Compilers use similar logic for lexical analysis, breaking source code into tokens. Speech recognition systems (Alexa, Siri) use segmentation for word boundary detection.

---

## Cybersecurity Applications

This problem demonstrates algorithmic concepts crucial for security engineering:

1. **Malware Detection:** Signature matching in antivirus (ClamAV, Windows Defender) - segmenting byte sequences into known malware patterns
2. **SQL Injection Detection:** WAF (ModSecurity, Cloudflare) parsing input to identify SQL keyword sequences
3. **Command Injection Prevention:** Segmenting user input to detect shell command patterns (bash, PowerShell)
4. **URL Analysis:** Phishing detection segmenting obfuscated URLs into known malicious domain patterns
5. **Log Parsing:** SIEM (Splunk, QRadar) breaking unstructured logs into known attack pattern sequences
6. **Protocol Analysis:** Wireshark/tcpdump segmenting packet payloads into protocol message patterns

**Security Engineering Value:**
Security professionals use string segmentation algorithms for pattern matching in IDS/IPS systems, parsing malformed input in vulnerability scanners, analyzing obfuscated code in malware sandboxes (Cuckoo, ANY.RUN), and tokenizing security logs for threat detection. Understanding DP-based parsing helps build robust input validation and anomaly detection systems.

**Common Security Contexts:**
- **Threat Detection:** Segmenting network traffic and logs into attack pattern sequences
- **Performance Security:** Preventing ReDoS attacks through efficient parsing algorithms
- **Secure Code Review:** Identifying input validation vulnerabilities in parsing logic
- **Security Tooling:** Building efficient pattern matching engines for threat intelligence
- **Incident Response:** Parsing and analyzing forensic data to reconstruct attack sequences

---

## Learning Resources

**Recommended Study Path:**
1. Master dynamic programming fundamentals and string processing
2. Practice similar problems: Word Break II, Concatenated Words, Palindrome Partitioning
3. Implement both unoptimized and optimized versions
4. Understand the DP state transition: dp[i] depends on all dp[j] where j < i
5. Consider edge cases: empty string, single character, no valid segmentation

**Interview Preparation:**
- This problem has 40.7% frequency in technical interviews
- Expected to solve in 20-45 minutes during coding interviews
- Be prepared to explain the DP recurrence relation clearly
- Practice explaining why set lookup is important for optimization

**Common Pitfalls:**
- Forgetting to convert wordDict to set (O(n) lookup instead of O(1))
- Not initializing dp[0] = True (base case for empty string)
- Incorrect loop bounds causing index errors
- Not using break after finding valid segmentation (unnecessary work)
- Attempting recursive solution without memoization (exponential time)

**Optimization Tips:**
- Always use set for wordDict lookup
- Add early break when dp[i] becomes True
- Optimize inner loop using max word length constraint
- Consider using Trie for prefix matching in advanced cases
- For Word Break II variant, use backtracking with memoization

---

*Generated for educational purposes. Problem source: [LeetCode](https://leetcode.com/problems/word-break)*
