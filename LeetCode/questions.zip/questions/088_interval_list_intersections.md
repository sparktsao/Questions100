# 088. Interval List Intersections

**Difficulty:** MEDIUM
**Frequency:** 32.0%
**Acceptance Rate:** 72.7%
**LeetCode Link:** [Interval List Intersections](https://leetcode.com/problems/interval-list-intersections)

---

## Problem Description

You are given two lists of closed intervals, `firstList` and `secondList`, where `firstList[i] = [starti, endi]` and `secondList[j] = [startj, endj]`. Each list of intervals is pairwise disjoint and in sorted order.

Return the intersection of these two interval lists.

A closed interval `[a, b]` (with `a <= b`) denotes the set of real numbers `x` with `a <= x <= b`.

The intersection of two closed intervals is a set of real numbers that are either empty or represented as a closed interval. For example, the intersection of `[1, 3]` and `[2, 4]` is `[2, 3]`.

**Constraints:**
- 0 <= firstList.length, secondList.length <= 1000
- firstList.length + secondList.length >= 1
- 0 <= starti < endi <= 10^9
- endi < starti+1
- 0 <= startj < endj <= 10^9
- endj < startj+1

---

## Examples

### Example 1
**Input:** `firstList = [[0,2],[5,10],[13,23],[24,25]], secondList = [[1,5],[8,12],[15,24],[25,26]]`
**Output:** `[[1,2],[5,5],[8,10],[15,23],[24,24],[25,25]]`
**Explanation:** Multiple overlapping intervals

### Example 2
**Input:** `firstList = [[1,3],[5,9]], secondList = []`
**Output:** `[]`
**Explanation:** One list is empty

### Example 3
**Input:** `firstList = [[1,7]], secondList = [[3,10]]`
**Output:** `[[3,7]]`
**Explanation:** Single interval intersection

### Example 4
**Input:** `firstList = [[1,2],[3,4]], secondList = [[5,6],[7,8]]`
**Output:** `[]`
**Explanation:** No overlapping intervals

---

## Optimal Solution

### Implementation

```python
def intervalIntersection(firstList: List[List[int]], secondList: List[List[int]]) -> List[List[int]]:
    """
    Find all interval intersections using two pointers.

    Time: O(m + n), Space: O(1) excluding output
    """
    result = []
    i, j = 0, 0

    while i < len(firstList) and j < len(secondList):
        # Get current intervals
        start1, end1 = firstList[i]
        start2, end2 = secondList[j]

        # Calculate intersection
        # Intersection exists if intervals overlap
        intersection_start = max(start1, start2)
        intersection_end = min(end1, end2)

        # Check if valid intersection
        if intersection_start <= intersection_end:
            result.append([intersection_start, intersection_end])

        # Move pointer for interval that ends first
        if end1 < end2:
            i += 1
        else:
            j += 1

    return result
```

### Alternative Implementation (More Explicit)

```python
def intervalIntersection(firstList: List[List[int]], secondList: List[List[int]]) -> List[List[int]]:
    """
    Two pointer approach with explicit overlap check.

    Time: O(m + n), Space: O(1)
    """
    result = []
    i, j = 0, 0
    m, n = len(firstList), len(secondList)

    while i < m and j < n:
        a_start, a_end = firstList[i]
        b_start, b_end = secondList[j]

        # Check if intervals overlap
        # Two intervals [a_start, a_end] and [b_start, b_end] overlap if:
        # a_start <= b_end AND b_start <= a_end
        if a_start <= b_end and b_start <= a_end:
            # Add intersection
            result.append([max(a_start, b_start), min(a_end, b_end)])

        # Advance the pointer of interval that ends earlier
        if a_end < b_end:
            i += 1
        else:
            j += 1

    return result
```

### Complexity Analysis

**Time: O(m + n) - single pass through both lists. Space: O(1) - constant extra space (output not counted)**

**Why This is Optimal:**
- Each interval visited exactly once (two pointer technique)
- No sorting needed (lists already sorted)
- Minimal space overhead
- Handles all edge cases: empty lists, no overlaps, complete overlaps
- Linear time is optimal since we must examine all intervals

---

## Categories & Tags

**Primary Topics:** Array, Two Pointers, Line Sweep

**Difficulty Level:** MEDIUM

---

## Real-World Applications

Understanding this algorithmic pattern has direct real-world applications:

1. **Calendar Systems:** Google Calendar and Outlook finding meeting time conflicts and available slots
2. **CPU Scheduling:** Operating system schedulers (Linux CFS, Windows Task Scheduler) finding process time overlaps
3. **Network Traffic Management:** Cisco routers and switches identifying overlapping time windows in QoS policies
4. **Resource Allocation:** Kubernetes and Docker finding container resource contention periods
5. **Conference Room Booking:** Microsoft Teams and Zoom scheduling finding room availability across multiple calendars

**Industry Impact:**
This algorithmic pattern appears in production systems at Google (Calendar API), Microsoft (Exchange Server), and Salesforce (event scheduling). Engineers working on scheduling systems, resource management, and time-based conflict resolution regularly implement these concepts.

---

## Cybersecurity Applications

This problem demonstrates algorithmic concepts crucial for security engineering:

1. **Firewall Rule Merging:** iptables and pfSense consolidating overlapping IP range rules for optimization
2. **Intrusion Detection:** Snort and Suricata correlating overlapping time windows of suspicious events
3. **Access Control:** Finding conflicting permission windows in temporal RBAC systems (HashiCorp Vault, AWS IAM)
4. **Vulnerability Windows:** Nessus and Qualys identifying time periods when multiple vulnerabilities overlap
5. **Log Correlation:** SIEM platforms finding overlapping event time ranges across different log sources
6. **DDoS Detection:** Identifying overlapping attack time windows from multiple sources in Cloudflare and Akamai

**Security Engineering Value:**
Security professionals use interval intersection algorithms in threat correlation engines to identify coordinated attacks across time windows, in compliance systems to detect overlapping access permissions that violate segregation of duties, and in incident response to correlate multi-stage attack timelines.

**Common Security Contexts:**
- **Threat Detection:** Correlating overlapping suspicious activity windows from multiple sensors
- **Performance Security:** Identifying time periods of concurrent resource exhaustion attempts
- **Secure Code Review:** Understanding efficient algorithms for temporal access control
- **Security Tooling:** Building timeline correlation in forensic analysis tools
- **Incident Response:** Merging event timelines from multiple security tools

---

## Learning Resources

**Recommended Study Path:**
1. Master two-pointer technique for sorted arrays
2. Understand interval overlap conditions
3. Practice similar problems: Merge Intervals (56), Insert Interval (57), Meeting Rooms II (253)
4. Learn line sweep algorithm for advanced interval problems
5. Study calendar scheduling algorithms

**Interview Preparation:**
- This problem has 32.0% frequency in technical interviews
- Expected to solve in 20-30 minutes during coding interviews
- Be prepared to explain overlap detection logic clearly
- Practice drawing timeline diagrams to visualize

**Common Pitfalls:**
- Incorrect overlap detection condition
- Forgetting to advance pointers correctly
- Not handling empty list edge cases
- Calculating intersection bounds incorrectly
- Missing single-point intersections (e.g., [1,5] and [5,9] → [5,5])

**Optimization Tips:**
- Two pointers is optimal for sorted lists
- Early termination when one list is exhausted
- No need for extra data structures
- Consider using min/max for cleaner intersection calculation
- Handle edge cases: empty lists, disjoint intervals, touching intervals

---

*Generated for educational purposes. Problem source: [LeetCode](https://leetcode.com/problems/interval-list-intersections)*
