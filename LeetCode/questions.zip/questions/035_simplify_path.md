# 035. Simplify Path

**Difficulty:** MEDIUM
**Frequency:** 65.0%
**Acceptance Rate:** 47.9%
**LeetCode Link:** [Simplify Path](https://leetcode.com/problems/simplify-path)

---

## Problem Description

You are given an absolute path for a Unix-style file system, which always begins with a slash '/'. Your task is to transform this absolute path into its simplified canonical path.

The rules of a Unix-style file system are as follows:
- A single period '.' represents the current directory
- A double period '..' represents the previous/parent directory
- Multiple consecutive slashes such as '//' and '///' are treated as a single slash '/'
- Any sequence of periods that does not match the rules above should be treated as a valid directory or file name (e.g., '...' and '....' are valid names)

The simplified canonical path should follow this format:
- The path must start with a single slash '/'
- Directories within the path must be separated by exactly one slash '/'
- The path must not end with a slash '/', unless it is the root directory
- The path must not have '.' or '..' as directory names

**Constraints:**
- 1 <= path.length <= 3000
- path consists of English letters, digits, period '.', slash '/', or underscore '_'
- path is a valid absolute Unix path

---

## Examples

### Example 1
**Input:** `path = "/home/"`
**Output:** `"/home"`
**Explanation:** The trailing slash should be removed

### Example 2
**Input:** `path = "/home//foo/"`
**Output:** `"/home/foo"`
**Explanation:** Multiple consecutive slashes are replaced by a single one

### Example 3
**Input:** `path = "/home/user/Documents/../Pictures"`
**Output:** `"/home/user/Pictures"`
**Explanation:** A double period ".." refers to the directory up a level

### Example 4
**Input:** `path = "/../"`
**Output:** `"/"`
**Explanation:** Going one level up from root is not possible, stay at root

---

## Optimal Solution

### Implementation

```python
def simplifyPath(path: str) -> str:
    """
    Use stack to handle directory navigation.

    Time: O(n), Space: O(n)
    """
    # Split by '/' and filter out empty strings and '.'
    components = path.split('/')
    stack = []

    for component in components:
        if component == '..' :
            # Go up one directory (pop from stack if possible)
            if stack:
                stack.pop()
        elif component and component != '.':
            # Valid directory name (not empty, not '.')
            stack.append(component)
        # Ignore empty strings and '.'

    # Build simplified path
    return '/' + '/'.join(stack)
```

### Alternative Implementation (More Explicit)

```python
def simplifyPath(path: str) -> str:
    """
    Explicit handling of each case.

    Time: O(n), Space: O(n)
    """
    stack = []
    parts = path.split('/')

    for part in parts:
        if part == '' or part == '.':
            # Empty or current directory - skip
            continue
        elif part == '..':
            # Parent directory - go back if possible
            if stack:
                stack.pop()
        else:
            # Valid directory name
            stack.append(part)

    # Join with '/' and prepend root '/'
    return '/' + '/'.join(stack)
```

### Complexity Analysis

**Time: O(n) - single pass through path. Space: O(n) - stack storage**

**Why This is Optimal:**
- Stack naturally handles directory navigation
- Single pass through the input
- Handles all special cases (., .., //, empty)
- Clean separation of parsing and path construction

---

## Categories & Tags

**Primary Topics:** String, Stack

**Difficulty Level:** MEDIUM

---

## Real-World Applications

Understanding this algorithmic pattern has direct real-world applications:

1. **File Systems:** Linux kernel path resolution, Windows file system canonicalization
2. **Web Servers:** Nginx, Apache HTTP Server URL normalization and security checks
3. **Version Control:** Git path handling, SVN repository navigation
4. **Container Systems:** Docker, Kubernetes volume mount path resolution
5. **IDEs:** VS Code, IntelliJ file explorer navigation and path display
6. **Cloud Storage:** AWS S3, Google Cloud Storage object path handling

**Industry Impact:**
Path simplification is fundamental to operating systems, web servers, and file management tools. Every system that handles file paths must implement canonical path resolution for security (preventing directory traversal attacks) and usability (consistent path representation).

---

## Cybersecurity Applications

This problem demonstrates algorithmic concepts crucial for security engineering:

1. **Path Traversal Prevention:** WAF (ModSecurity, AWS WAF) blocking attacks like "../../etc/passwd"
2. **URL Sanitization:** Web application firewalls normalizing URLs before security checks
3. **Access Control:** File system security validating paths don't escape restricted directories
4. **Container Security:** Docker, Kubernetes preventing volume escape via path manipulation
5. **Input Validation:** OWASP guidelines for secure path handling in applications
6. **Security Scanners:** Burp Suite, OWASP ZAP testing for directory traversal vulnerabilities

**Security Engineering Value:**
Proper path canonicalization is critical for preventing directory traversal attacks, one of the OWASP Top 10 vulnerabilities. Security tools must normalize paths before access control checks to prevent attackers from using ".." sequences to access unauthorized files. This technique is also used in container breakout detection and web application security.

**Common Security Contexts:**
- **Threat Detection:** Pattern matching and anomaly detection in security logs
- **Performance Security:** Preventing algorithmic complexity attacks (e.g., hash collision DoS)
- **Secure Code Review:** Identifying potential vulnerabilities in algorithm implementations
- **Security Tooling:** Building efficient security scanners and analysis tools
- **Incident Response:** Fast data processing during security investigations

---

## Learning Resources

**Recommended Study Path:**
1. Master the fundamental data structure concepts
2. Practice similar problems with the same pattern
3. Implement the solution from scratch without reference
4. Analyze time/space complexity of alternative approaches
5. Consider edge cases and error handling

**Interview Preparation:**
- This problem has 65.0% frequency in technical interviews
- Expected to solve in 20-45 minutes during coding interviews
- Be prepared to discuss trade-offs and alternative approaches
- Practice explaining your thought process clearly

**Common Pitfalls:**
- Off-by-one errors in array/string indexing
- Not handling edge cases (empty input, single element, etc.)
- Incorrect complexity analysis
- Over-complicating the solution

**Optimization Tips:**
- Consider early termination conditions
- Minimize unnecessary data structure operations
- Use built-in language features efficiently
- Profile for performance on large inputs

---

*Generated for educational purposes. Problem source: [LeetCode](https://leetcode.com/problems/simplify-path)*
