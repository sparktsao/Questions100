# 087. Maximum Subarray

**Difficulty:** MEDIUM
**Frequency:** 32.0%
**Acceptance Rate:** 52.1%
**LeetCode Link:** [Maximum Subarray](https://leetcode.com/problems/maximum-subarray)

---

## Problem Description

Given an integer array `nums`, find the subarray with the largest sum, and return its sum.

A subarray is a contiguous non-empty sequence of elements within an array.

**Constraints:**
- 1 <= nums.length <= 10^5
- -10^4 <= nums[i] <= 10^4

**Follow up:** If you have figured out the O(n) solution, try coding another solution using the divide and conquer approach, which is more subtle.

---

## Examples

### Example 1
**Input:** `nums = [-2,1,-3,4,-1,2,1,-5,4]`
**Output:** `6`
**Explanation:** The subarray [4,-1,2,1] has the largest sum 6

### Example 2
**Input:** `nums = [1]`
**Output:** `1`
**Explanation:** The subarray [1] has the largest sum 1

### Example 3
**Input:** `nums = [5,4,-1,7,8]`
**Output:** `23`
**Explanation:** The subarray [5,4,-1,7,8] has the largest sum 23

### Example 4
**Input:** `nums = [-1]`
**Output:** `-1`
**Explanation:** Single negative element

---

## Optimal Solution

### Implementation (Kadane's Algorithm)

```python
def maxSubArray(nums: List[int]) -> int:
    """
    Find maximum subarray sum using Kadane's Algorithm.

    Time: O(n), Space: O(1)
    """
    max_sum = nums[0]
    current_sum = 0

    for num in nums:
        # Reset if current sum becomes negative
        if current_sum < 0:
            current_sum = 0

        current_sum += num
        max_sum = max(max_sum, current_sum)

    return max_sum
```

### Alternative Implementation (DP Approach)

```python
def maxSubArray(nums: List[int]) -> int:
    """
    Dynamic programming approach.

    dp[i] = max sum ending at index i
    Time: O(n), Space: O(1) with optimization
    """
    max_ending_here = nums[0]
    max_so_far = nums[0]

    for i in range(1, len(nums)):
        # Either extend existing subarray or start new
        max_ending_here = max(nums[i], max_ending_here + nums[i])
        max_so_far = max(max_so_far, max_ending_here)

    return max_so_far
```

### Divide and Conquer Solution

```python
def maxSubArray(nums: List[int]) -> int:
    """
    Divide and conquer approach.

    Time: O(n log n), Space: O(log n) for recursion
    """
    def max_crossing_sum(arr, left, mid, right):
        """Find max sum crossing the midpoint"""
        # Left side of mid
        left_sum = float('-inf')
        curr_sum = 0
        for i in range(mid, left - 1, -1):
            curr_sum += arr[i]
            left_sum = max(left_sum, curr_sum)

        # Right side of mid
        right_sum = float('-inf')
        curr_sum = 0
        for i in range(mid + 1, right + 1):
            curr_sum += arr[i]
            right_sum = max(right_sum, curr_sum)

        return left_sum + right_sum

    def max_subarray_helper(arr, left, right):
        if left == right:
            return arr[left]

        mid = (left + right) // 2

        # Max in left half, right half, or crossing mid
        return max(
            max_subarray_helper(arr, left, mid),
            max_subarray_helper(arr, mid + 1, right),
            max_crossing_sum(arr, left, mid, right)
        )

    return max_subarray_helper(nums, 0, len(nums) - 1)
```

### Complexity Analysis

**Kadane's Algorithm:**
**Time: O(n) - single pass. Space: O(1) - constant space**

**Divide and Conquer:**
**Time: O(n log n) - recursive splitting. Space: O(log n) - recursion stack**

**Why This is Optimal:**
- Kadane's algorithm achieves optimal O(n) time with O(1) space
- Single pass through array, no backtracking needed
- Handles all negative numbers correctly
- Simple to implement and understand
- Divide and conquer provides alternative approach with different insights

---

## Categories & Tags

**Primary Topics:** Array, Divide and Conquer, Dynamic Programming

**Difficulty Level:** MEDIUM

---

## Real-World Applications

Understanding this algorithmic pattern has direct real-world applications:

1. **Stock Trading:** Finding maximum profit period in stock price changes - used in trading algorithms at Goldman Sachs and Jane Street
2. **Time Series Analysis:** Identifying peak performance periods in Google Analytics and New Relic monitoring
3. **Resource Allocation:** AWS Auto Scaling determining optimal resource usage windows for cost optimization
4. **Video Streaming:** Netflix and YouTube identifying best quality segments in variable bitrate streaming
5. **Financial Analysis:** Bloomberg Terminal analyzing consecutive profit/loss periods in portfolio management

**Industry Impact:**
This algorithmic pattern appears in production systems at quantitative trading firms (Two Sigma, Citadel), cloud platforms (AWS CloudWatch, Azure Monitor), and analytics tools (Tableau, Looker). Engineers working on time-series analysis, financial systems, and performance monitoring regularly implement these concepts.

---

## Cybersecurity Applications

This problem demonstrates algorithmic concepts crucial for security engineering:

1. **Network Traffic Analysis:** Detecting sustained attack periods in DDoS traffic using Cloudflare and Akamai WAF
2. **Anomaly Detection:** SIEM platforms like Splunk identifying maximum deviation periods in baseline behavior
3. **Resource Exhaustion Detection:** Prometheus and Grafana finding peak resource consumption windows indicating attacks
4. **Brute Force Detection:** Fail2ban and Crowdsec identifying maximum failed login attempt windows
5. **Log Correlation:** ELK Stack finding temporal clusters of security events
6. **Threat Scoring:** Calculating maximum threat score accumulation over time windows in threat intelligence platforms

**Security Engineering Value:**
Security professionals use maximum subarray algorithms in intrusion detection systems to identify sustained attack patterns, in SIEM platforms to detect temporal anomalies, and in performance monitoring to spot resource exhaustion attacks. This pattern is fundamental to time-window based threat detection.

**Common Security Contexts:**
- **Threat Detection:** Identifying sustained malicious activity periods in time-series security data
- **Performance Security:** Detecting resource exhaustion and SlowLoris attacks through usage pattern analysis
- **Secure Code Review:** Understanding efficient algorithms to prevent algorithmic complexity vulnerabilities
- **Security Tooling:** Building real-time anomaly detection in sliding time windows
- **Incident Response:** Analyzing attack timelines to identify peak threat activity periods

---

## Learning Resources

**Recommended Study Path:**
1. Understand the greedy approach in Kadane's algorithm
2. Learn how dynamic programming formulation relates to greedy solution
3. Practice similar problems: Best Time to Buy and Sell Stock (121), Maximum Product Subarray (152)
4. Master divide and conquer for deeper algorithmic understanding
5. Extend to 2D version: Maximum Sum Rectangle in a 2D Matrix

**Interview Preparation:**
- This problem has 32.0% frequency in technical interviews
- Expected to solve in 15-25 minutes during coding interviews
- Be prepared to explain why greedy approach works
- Practice deriving the algorithm from first principles

**Common Pitfalls:**
- Not handling all-negative arrays correctly
- Resetting current sum at wrong time
- Off-by-one errors in array indexing
- Incorrect initialization of max_sum
- Forgetting that subarray must be non-empty

**Optimization Tips:**
- Kadane's algorithm is optimal for this problem
- Track subarray indices if needed (with minimal modification)
- Consider prefix sum approach for multiple queries
- Early termination when all elements are positive
- Handle empty array edge case based on problem constraints

---

*Generated for educational purposes. Problem source: [LeetCode](https://leetcode.com/problems/maximum-subarray)*
