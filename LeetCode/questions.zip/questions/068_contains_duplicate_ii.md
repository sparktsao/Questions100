# 068. Contains Duplicate II

**Difficulty:** EASY
**Frequency:** 40.7%
**Acceptance Rate:** 49.0%
**LeetCode Link:** [Contains Duplicate II](https://leetcode.com/problems/contains-duplicate-ii)

---

## Problem Description

Given an integer array `nums` and an integer `k`, return `true` if there are two distinct indices `i` and `j` in the array such that `nums[i] == nums[j]` and `abs(i - j) <= k`.

**Constraints:**
- 1 <= nums.length <= 10^5
- -10^9 <= nums[i] <= 10^9
- 0 <= k <= 10^5

---

## Examples

### Example 1
**Input:** `nums = [1,2,3,1], k = 3`
**Output:** `true`
**Explanation:** nums[0] == nums[3] and abs(0 - 3) = 3 <= k

### Example 2
**Input:** `nums = [1,0,1,1], k = 1`
**Output:** `true`
**Explanation:** nums[2] == nums[3] and abs(2 - 3) = 1 <= k

### Example 3
**Input:** `nums = [1,2,3,1,2,3], k = 2`
**Output:** `false`
**Explanation:** No two equal numbers are within distance k of each other

### Example 4
**Input:** `nums = [1,2,1], k = 0`
**Output:** `false`
**Explanation:** k = 0 means indices must be identical, which is impossible for distinct indices

---

## Optimal Solution

### Implementation

```python
def containsNearbyDuplicate(nums: List[int], k: int) -> bool:
    """
    Use hash map to track most recent index of each value.

    Time: O(n), Space: O(min(n, k))
    """
    seen = {}

    for i, num in enumerate(nums):
        # Check if we've seen this number before
        if num in seen:
            # Check if within distance k
            if i - seen[num] <= k:
                return True

        # Update/store the current index for this number
        seen[num] = i

    return False
```

### Alternative Implementation (Sliding Window with Set)

```python
def containsNearbyDuplicate(nums: List[int], k: int) -> bool:
    """
    Use sliding window with set to maintain window of size k.

    Time: O(n), Space: O(min(n, k))
    """
    window = set()

    for i, num in enumerate(nums):
        # If number already in window, we found duplicate within k distance
        if num in window:
            return True

        # Add current number to window
        window.add(num)

        # Maintain window size of k
        if len(window) > k:
            # Remove the element that's now outside the window
            window.remove(nums[i - k])

    return False
```

### Complexity Analysis

**Time: O(n) - single pass through array. Space: O(min(n, k)) - hash map/set stores at most k+1 elements**

**Why This is Optimal:**
- Must examine each element at least once, so O(n) is optimal
- Space is bounded by min(n, k) since we only need to track elements within window
- Hash table provides O(1) lookup and insertion
- Sliding window approach maintains only relevant elements
- Early termination when duplicate found

---

## Categories & Tags

**Primary Topics:** Array, Hash Table, Sliding Window

**Difficulty Level:** EASY

---

## Real-World Applications

Understanding this algorithmic pattern has direct real-world applications:

1. **Fraud Detection:** Credit card systems detecting duplicate transactions within time windows (Stripe, PayPal)
2. **Rate Limiting:** API gateways tracking request frequencies within sliding windows (Kong, AWS API Gateway)
3. **Network Security:** IDS systems detecting duplicate packets within time windows (Snort, Suricata)
4. **Cache Management:** Detecting duplicate cache entries in Redis, Memcached
5. **Log Analysis:** SIEM systems identifying duplicate log entries within time ranges (Splunk, ELK)

**Industry Impact:**
Sliding window algorithms with hash tables are fundamental to real-time monitoring systems, fraud detection, and rate limiting. These patterns appear in payment processors, API gateways, CDNs, and security monitoring tools processing millions of events per second.

---

## Cybersecurity Applications

This problem demonstrates algorithmic concepts crucial for security engineering:

1. **Brute Force Detection:** Login attempt monitoring in fail2ban, detecting repeated failed logins within time window
2. **DDoS Mitigation:** Cloudflare/Akamai detecting duplicate requests from same IP within sliding window
3. **Anomaly Detection:** SIEM platforms (Splunk, QRadar) identifying repeated security events
4. **Session Fixation Prevention:** Web application firewalls detecting duplicate session IDs
5. **Replay Attack Detection:** Network security tools identifying duplicate authentication tokens within time windows
6. **API Abuse Prevention:** Rate limiters in OAuth providers (Auth0, Okta) tracking duplicate requests

**Security Engineering Value:**
Understanding sliding window algorithms is critical for building real-time security monitoring systems. These patterns enable efficient detection of repeated attacks, brute force attempts, and anomalous behavior in high-throughput environments. Security engineers use these techniques in WAFs, IDS/IPS systems, and threat detection platforms.

**Common Security Contexts:**
- **Threat Detection:** Pattern matching and anomaly detection in security logs
- **Performance Security:** Preventing algorithmic complexity attacks (e.g., hash collision DoS)
- **Secure Code Review:** Identifying potential vulnerabilities in algorithm implementations
- **Security Tooling:** Building efficient security scanners and analysis tools
- **Incident Response:** Fast data processing during security investigations

---

## Learning Resources

**Recommended Study Path:**
1. Master the fundamental data structure concepts
2. Practice similar problems with the same pattern
3. Implement the solution from scratch without reference
4. Analyze time/space complexity of alternative approaches
5. Consider edge cases and error handling

**Interview Preparation:**
- This problem has 40.7% frequency in technical interviews
- Expected to solve in 20-45 minutes during coding interviews
- Be prepared to discuss trade-offs and alternative approaches
- Practice explaining your thought process clearly

**Common Pitfalls:**
- Off-by-one errors in array/string indexing
- Not handling edge cases (empty input, single element, etc.)
- Incorrect complexity analysis
- Over-complicating the solution
- Using O(n) space when O(k) is sufficient
- Not maintaining sliding window correctly
- Edge case: k = 0 (impossible to have duplicate at same index)

**Optimization Tips:**
- Consider early termination conditions
- Minimize unnecessary data structure operations
- Use built-in language features efficiently
- Profile for performance on large inputs
- Choose between hash map (tracks indices) vs set (sliding window) based on needs
- For very large k, hash map approach may be more memory efficient

---

*Generated for educational purposes. Problem source: [LeetCode](https://leetcode.com/problems/contains-duplicate-ii)*
