# 011. Nested List Weight Sum

**Difficulty:** MEDIUM
**Frequency:** 81.7%
**Acceptance Rate:** 85.5%
**LeetCode Link:** [Nested List Weight Sum](https://leetcode.com/problems/nested-list-weight-sum)

---

## Problem Description

Given a nested list of integers, return the sum of all integers in the list weighted by their depth.

Each element is either an integer, or a list -- whose elements may also be integers or other lists.

**Constraints:**
- 1 <= nestedList.length <= 50
- The values of the integers in the nested list is in the range [-100, 100]
- The maximum depth of any integer is less than or equal to 50

---

## Examples

### Example 1
**Input:** `[[1,1],2,[1,1]]`
**Output:** `10`
**Explanation:** (1*2 + 1*2) + (2*1) + (1*2 + 1*2) = 4 + 2 + 4 = 10

### Example 2
**Input:** `[1,[4,[6]]]`
**Output:** `27`
**Explanation:** 1*1 + 4*2 + 6*3 = 1 + 8 + 18 = 27

### Example 3
**Input:** `[0]`
**Output:** `0`
**Explanation:** Single element at depth 1

### Example 4
**Input:** `[[1,1],[2,2]]`
**Output:** `8`
**Explanation:** All at depth 2: (1+1+2+2)*2 = 12

---

## Optimal Solution

### Implementation

```python
def depthSum(nestedList: List[NestedInteger]) -> int:
    """
    DFS recursive approach with depth tracking.

    Time: O(n), Space: O(d) where d is max depth
    """
    def dfs(nested_list, depth):
        total = 0
        for item in nested_list:
            if item.isInteger():
                total += item.getInteger() * depth
            else:
                total += dfs(item.getList(), depth + 1)
        return total

    return dfs(nestedList, 1)
```

### Complexity Analysis

**Time: O(n) - visit each element once. Space: O(d) - recursion depth**

**Why This is Optimal:**
- Achieves best possible asymptotic complexity for this problem class
- Minimal space overhead while maintaining code clarity
- Scales efficiently with large inputs
- Handles all edge cases correctly

---

## Categories & Tags

**Primary Topics:** Depth-First Search, Breadth-First Search

**Difficulty Level:** MEDIUM

---

## Real-World Applications

Understanding this algorithmic pattern has direct real-world applications:

1. **JSON Parsing:** Processing nested API responses with depth-based priority
2. **File System Analysis:** Calculating directory sizes with depth weighting
3. **XML/HTML DOM:** Processing nested elements with importance by depth
4. **Configuration Management:** Ansible/Chef nested variable priority
5. **Database Queries:** PostgreSQL JSON/JSONB nested document scoring
6. **UI Component Trees:** React/Vue component hierarchy importance

**Industry Impact:**
This algorithmic pattern appears in production systems at companies like Google, Amazon, Microsoft, Meta, and Netflix. Engineers working on large-scale distributed systems, data processing pipelines, and user-facing applications regularly implement these concepts.

---

## Cybersecurity Applications

This problem demonstrates algorithmic concepts crucial for security engineering:

1. **Log Analysis:** Parsing nested JSON logs in Splunk/ELK with priority by depth
2. **Threat Intelligence:** STIX/TAXII nested indicator scoring by relationship depth
3. **Configuration Auditing:** Analyzing nested firewall rules with precedence
4. **Malware Analysis:** Scoring nested process trees by execution depth
5. **Network Packet Analysis:** Wireshark protocol layer importance (OSI model depth)
6. **Access Control:** RBAC nested permission inheritance depth scoring
7. **Security Policies:** AWS IAM nested policy evaluation priority

**Security Engineering Value:**
Security professionals use these algorithms in threat detection systems, security information and event management (SIEM) platforms, intrusion detection/prevention systems (IDS/IPS), and security automation tools. Understanding these patterns is essential for developing robust security solutions.

**Common Security Contexts:**
- **Threat Detection:** Pattern matching and anomaly detection in security logs
- **Performance Security:** Preventing algorithmic complexity attacks (e.g., hash collision DoS)
- **Secure Code Review:** Identifying potential vulnerabilities in algorithm implementations
- **Security Tooling:** Building efficient security scanners and analysis tools
- **Incident Response:** Fast data processing during security investigations

---

## Learning Resources

**Recommended Study Path:**
1. Master the fundamental data structure concepts
2. Practice similar problems with the same pattern
3. Implement the solution from scratch without reference
4. Analyze time/space complexity of alternative approaches
5. Consider edge cases and error handling

**Interview Preparation:**
- This problem has 81.7% frequency in technical interviews
- Expected to solve in 20-45 minutes during coding interviews
- Be prepared to discuss trade-offs and alternative approaches
- Practice explaining your thought process clearly

**Common Pitfalls:**
- Off-by-one errors in array/string indexing
- Not handling edge cases (empty input, single element, etc.)
- Incorrect complexity analysis
- Over-complicating the solution

**Optimization Tips:**
- Consider early termination conditions
- Minimize unnecessary data structure operations
- Use built-in language features efficiently
- Profile for performance on large inputs

---

*Generated for educational purposes. Problem source: [LeetCode](https://leetcode.com/problems/nested-list-weight-sum)*
