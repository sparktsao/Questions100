# 015. Top K Frequent Elements

**Difficulty:** MEDIUM
**Frequency:** 77.9%
**Acceptance Rate:** 64.6%
**LeetCode Link:** [Top K Frequent Elements](https://leetcode.com/problems/top-k-frequent-elements)

---

## Problem Description

Given an integer array `nums` and an integer `k`, return the `k` most frequent elements. You may return the answer in any order.

**Constraints:**
- 1 <= nums.length <= 10^5
- -10^4 <= nums[i] <= 10^4
- k is in the range [1, the number of unique elements in the array]
- It is guaranteed that the answer is unique

**Follow-up:** Your algorithm's time complexity must be better than O(n log n), where n is the array's size.

---

## Examples

### Example 1
**Input:** `nums = [1,1,1,2,2,3], k = 2`
**Output:** `[1,2]`
**Explanation:** Element 1 appears 3 times, element 2 appears 2 times, element 3 appears 1 time. The 2 most frequent are 1 and 2.

### Example 2
**Input:** `nums = [1], k = 1`
**Output:** `[1]`
**Explanation:** Only one element exists, so it's the most frequent

### Example 3
**Input:** `nums = [1,2,1,2,1,2,3,1,3,2], k = 2`
**Output:** `[1,2]`
**Explanation:** Both 1 and 2 appear 4 times each, making them the most frequent. Element 3 appears only 2 times.

### Example 4
**Input:** `nums = [4,1,-1,2,-1,2,3], k = 2`
**Output:** `[-1,2]`
**Explanation:** Elements -1 and 2 each appear 2 times, making them the most frequent (works with negative numbers)

---

## Optimal Solution

### Implementation (Bucket Sort - O(n) Time)

```python
from typing import List
from collections import Counter

def topKFrequent(nums: List[int], k: int) -> List[int]:
    """
    Find k most frequent elements using bucket sort.

    Time: O(n), Space: O(n)
    """
    # Count frequency of each element
    count = Counter(nums)

    # Create buckets where index represents frequency
    # bucket[i] contains all elements with frequency i
    bucket = [[] for _ in range(len(nums) + 1)]

    for num, freq in count.items():
        bucket[freq].append(num)

    # Collect k most frequent elements from highest frequency buckets
    result = []
    for i in range(len(bucket) - 1, 0, -1):
        for num in bucket[i]:
            result.append(num)
            if len(result) == k:
                return result

    return result
```

### Alternative Implementation (Min Heap - O(n log k) Time)

```python
from typing import List
from collections import Counter
import heapq

def topKFrequent(nums: List[int], k: int) -> List[int]:
    """
    Find k most frequent elements using min heap.

    Time: O(n log k), Space: O(n)
    """
    # Count frequency of each element
    count = Counter(nums)

    # Use min heap to keep top k frequent elements
    # Heap stores tuples of (frequency, number)
    return heapq.nlargest(k, count.keys(), key=count.get)
```

### Complexity Analysis

**Bucket Sort: Time O(n), Space O(n) - optimal for this problem**
**Min Heap: Time O(n log k), Space O(n) - better when k is small**

**Why Bucket Sort is Optimal:**
- Achieves O(n) time complexity, which is optimal for this problem
- Leverages the fact that maximum frequency cannot exceed n
- No sorting required, just bucket indexing
- Handles all edge cases including single element and all duplicates
- Meets the follow-up requirement of being better than O(n log n)

---

## Categories & Tags

**Primary Topics:** Array, Hash Table, Divide and Conquer, Sorting, Heap (Priority Queue), Bucket Sort, Counting, Quickselect

**Difficulty Level:** MEDIUM

---

## Real-World Applications

Understanding this algorithmic pattern has direct real-world applications:

1. **Search Autocomplete:** Google Search, Amazon product search showing top k most frequently searched terms
2. **Trending Analysis:** Twitter/X trending topics, Reddit hot posts identifying most frequently mentioned items
3. **Analytics Dashboards:** Google Analytics showing top k pages by visits, Mixpanel event frequency analysis
4. **E-Commerce:** Amazon "Frequently Bought Together", best-selling product tracking across millions of transactions
5. **Log Analysis:** Splunk/Datadog finding most frequent error codes, CloudWatch metrics aggregation

**Industry Impact:**
Top-k frequency analysis is fundamental to modern analytics and recommendation systems. Companies like Google, Meta, Amazon, and Netflix use this pattern for real-time trending analysis, content ranking, performance monitoring, and user behavior analytics. The O(n) bucket sort approach scales to billions of events per day.

---

## Cybersecurity Applications

This problem demonstrates algorithmic concepts crucial for security engineering:

1. **Attack Pattern Detection:** Identifying top k most frequent attack signatures in IDS/IPS logs (Snort, Suricata, Zeek)
2. **Threat Hunting:** Finding most frequently occurring IOCs (IP addresses, domains, file hashes) in SIEM platforms (Splunk, QRadar, Sentinel)
3. **DDoS Analysis:** Identifying top k source IPs in volumetric attacks for mitigation (Cloudflare, Akamai, AWS Shield)
4. **Malware Family Classification:** Finding most common API call sequences in malware samples (Cuckoo Sandbox, ANY.RUN)
5. **Vulnerability Prioritization:** Ranking most frequently exploited CVEs for patch management (Nessus, Qualys, Rapid7)
6. **Fraud Detection:** Identifying most frequent transaction patterns in financial fraud analysis

**Security Engineering Value:**
Top-k frequency analysis is essential for security operations that process millions of events. Security teams use this pattern to prioritize threats, identify attack trends, optimize detection rules, and allocate incident response resources. The O(n) time complexity is critical for real-time threat detection at scale.

**Common Security Contexts:**
- **Threat Detection:** Real-time identification of most frequent attack patterns in network traffic
- **Performance Security:** Efficient log analysis without overwhelming SIEM systems
- **Secure Code Review:** Analyzing most common vulnerability patterns in code repositories
- **Security Tooling:** Building efficient threat intelligence aggregation systems
- **Incident Response:** Quickly identifying most impacted assets during security incidents

---

## Learning Resources

**Recommended Study Path:**
1. Master the fundamental data structure concepts
2. Practice similar problems with the same pattern
3. Implement the solution from scratch without reference
4. Analyze time/space complexity of alternative approaches
5. Consider edge cases and error handling

**Interview Preparation:**
- This problem has 77.9% frequency in technical interviews
- Expected to solve in 20-45 minutes during coding interviews
- Be prepared to discuss trade-offs and alternative approaches
- Practice explaining your thought process clearly

**Common Pitfalls:**
- Off-by-one errors in array/string indexing
- Not handling edge cases (empty input, single element, etc.)
- Incorrect complexity analysis
- Over-complicating the solution

**Optimization Tips:**
- Consider early termination conditions
- Minimize unnecessary data structure operations
- Use built-in language features efficiently
- Profile for performance on large inputs

---

*Generated for educational purposes. Problem source: [LeetCode](https://leetcode.com/problems/top-k-frequent-elements)*
