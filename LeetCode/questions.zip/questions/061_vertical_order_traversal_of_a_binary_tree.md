# 061. Vertical Order Traversal of a Binary Tree

**Difficulty:** HARD
**Frequency:** 47.0%
**Acceptance Rate:** 51.3%
**LeetCode Link:** [Vertical Order Traversal of a Binary Tree](https://leetcode.com/problems/vertical-order-traversal-of-a-binary-tree)

---

## Problem Description

Given the `root` of a binary tree, calculate the vertical order traversal of the binary tree.

For each node at position `(row, col)`, its left and right children will be at positions `(row + 1, col - 1)` and `(row + 1, col + 1)` respectively. The root of the tree is at `(0, 0)`.

The vertical order traversal of a binary tree is a list of top-to-bottom orderings for each column index starting from the leftmost column and ending on the rightmost column. There may be multiple nodes in the same row and same column. In such a case, sort these nodes by their values.

Return the vertical order traversal of the binary tree.

**Constraints:**
- The number of nodes in the tree is in the range [1, 1000]
- 0 <= Node.val <= 1000

---

## Examples

### Example 1
**Input:** `root = [3,9,20,null,null,15,7]`
**Output:** `[[9],[3,15],[20],[7]]`
**Explanation:** Column order: -1:[9], 0:[3,15], 1:[20], 2:[7]

### Example 2
**Input:** `root = [1,2,3,4,5,6,7]`
**Output:** `[[4],[2],[1,5,6],[3],[7]]`
**Explanation:** Same column nodes sorted by value

### Example 3
**Input:** `root = [1,2,3,4,6,5,7]`
**Output:** `[[4],[2],[1,5,6],[3],[7]]`
**Explanation:** Values are sorted when at same position

---

## Optimal Solution

### Implementation

```python
def verticalTraversal(root: TreeNode) -> List[List[int]]:
    """
    DFS to collect (col, row, val), then sort and group.

    Time: O(n log n), Space: O(n)
    """
    nodes = []

    def dfs(node, row, col):
        if not node:
            return

        nodes.append((col, row, node.val))
        dfs(node.left, row + 1, col - 1)
        dfs(node.right, row + 1, col + 1)

    dfs(root, 0, 0)

    # Sort by column, then row, then value
    nodes.sort()

    result = []
    prev_col = float('-inf')

    for col, row, val in nodes:
        if col != prev_col:
            result.append([])
            prev_col = col
        result[-1].append(val)

    return result
```

### Complexity Analysis

**Time: O(n log n) - sorting nodes. Space: O(n) - storing all nodes**

**Why This is Optimal:**
- Achieves best possible asymptotic complexity for this problem class
- Minimal space overhead while maintaining code clarity
- Scales efficiently with large inputs
- Handles all edge cases correctly

---

## Categories & Tags

**Primary Topics:** Hash Table, Tree, Depth-First Search, Breadth-First Search, Sorting, Binary Tree

**Difficulty Level:** HARD

---

## Real-World Applications

Understanding this algorithmic pattern has direct real-world applications:

1. **UI Layout:** Rendering columnar layouts in web browsers
2. **Data Visualization:** Column charts in Tableau/PowerBI
3. **Calendar Apps:** Google Calendar vertical timeline view
4. **Org Charts:** Vertical department structure rendering
5. **File Explorers:** Column view in macOS Finder
6. **Gantt Charts:** Project management timeline columns

**Industry Impact:**
This algorithmic pattern appears in production systems at companies like Google, Amazon, Microsoft, Meta, and Netflix. Engineers working on large-scale distributed systems, data processing pipelines, and user-facing applications regularly implement these concepts.

---

## Cybersecurity Applications

This problem demonstrates algorithmic concepts crucial for security engineering:

1. **Timeline Analysis:** Vertical event ordering in incident response
2. **Network Flow:** Vertical hop-by-hop packet path analysis
3. **Attack Graph:** Vertical attack stage visualization (MITRE ATT&CK)
4. **Process Tree:** Vertical parent-child process relationship display
5. **Privilege Escalation:** Vertical permission level analysis (BloodHound)
6. **Log Correlation:** Vertical timestamp-aligned event display
7. **Certificate Chain:** Vertical CA hierarchy visualization

**Security Engineering Value:**
Security professionals use these algorithms in threat detection systems, security information and event management (SIEM) platforms, intrusion detection/prevention systems (IDS/IPS), and security automation tools. Understanding these patterns is essential for developing robust security solutions.

**Common Security Contexts:**
- **Threat Detection:** Pattern matching and anomaly detection in security logs
- **Performance Security:** Preventing algorithmic complexity attacks (e.g., hash collision DoS)
- **Secure Code Review:** Identifying potential vulnerabilities in algorithm implementations
- **Security Tooling:** Building efficient security scanners and analysis tools
- **Incident Response:** Fast data processing during security investigations

---

## Learning Resources

**Recommended Study Path:**
1. Master the fundamental data structure concepts
2. Practice similar problems with the same pattern
3. Implement the solution from scratch without reference
4. Analyze time/space complexity of alternative approaches
5. Consider edge cases and error handling

**Interview Preparation:**
- This problem has 47.0% frequency in technical interviews
- Expected to solve in 20-45 minutes during coding interviews
- Be prepared to discuss trade-offs and alternative approaches
- Practice explaining your thought process clearly

**Common Pitfalls:**
- Off-by-one errors in array/string indexing
- Not handling edge cases (empty input, single element, etc.)
- Incorrect complexity analysis
- Over-complicating the solution

**Optimization Tips:**
- Consider early termination conditions
- Minimize unnecessary data structure operations
- Use built-in language features efficiently
- Profile for performance on large inputs

---

*Generated for educational purposes. Problem source: [LeetCode](https://leetcode.com/problems/vertical-order-traversal-of-a-binary-tree)*
