# 001. Minimum Remove to Make Valid Parentheses

**Difficulty:** MEDIUM
**Frequency:** 100.0%
**Acceptance Rate:** 70.7%
**LeetCode Link:** [Minimum Remove to Make Valid Parentheses](https://leetcode.com/problems/minimum-remove-to-make-valid-parentheses)

---

## Problem Description

Given a string `s` of '(' , ')' and lowercase English characters, remove the minimum number of parentheses ( '(' or ')', in any positions ) so that the resulting parentheses string is valid and return any valid string.

A string is valid if:
- Open brackets must be closed by the same type of brackets.
- Open brackets must be closed in the correct order.

**Constraints:**
- 1 <= s.length <= 10^5
- s[i] is either '(' , ')', or lowercase English letter

---

## Examples

### Example 1
**Input:** `s = "lee(t(c)o)de)"`
**Output:** `"lee(t(c)o)de"`
**Explanation:** Remove the extra ) at the end

### Example 2
**Input:** `s = "a)b(c)d"`
**Output:** `"ab(c)d"`
**Explanation:** Remove the extra ) at index 1

### Example 3
**Input:** `s = "))(("`
**Output:** `""`
**Explanation:** All parentheses are invalid, remove all

### Example 4
**Input:** `s = "(a(b(c)d)"`
**Output:** `"a(b(c)d)" or "(a(b(c)d))"`
**Explanation:** Multiple valid answers possible

---

## Optimal Solution

### Implementation

```python
def minRemoveToMakeValid(s: str) -> str:
    """
    Remove minimum parentheses using stack to track indices.

    Time: O(n), Space: O(n)
    """
    to_remove = set()
    stack = []

    # Find indices to remove
    for i, char in enumerate(s):
        if char == '(':
            stack.append(i)
        elif char == ')':
            if stack:
                stack.pop()
            else:
                to_remove.add(i)

    # Add unmatched '(' to remove set
    to_remove.update(stack)

    # Build result
    return ''.join(char for i, char in enumerate(s) if i not in to_remove)
```

### Complexity Analysis

**Time: O(n) - single pass. Space: O(n) - stack and set storage**

**Why This is Optimal:**
- Achieves best possible asymptotic complexity for this problem class
- Minimal space overhead while maintaining code clarity
- Scales efficiently with large inputs
- Handles all edge cases correctly

---

## Categories & Tags

**Primary Topics:** String, Stack

**Difficulty Level:** MEDIUM

---

## Real-World Applications

Understanding this algorithmic pattern has direct real-world applications:

1. **Code Editors:** IntelliJ IDEA auto-fixing unbalanced parentheses
2. **Compilers:** GCC/Clang error recovery during parsing
3. **JSON Validators:** Auto-correcting malformed JSON structures
4. **Formula Editors:** Excel/Google Sheets fixing formula syntax
5. **Text Processing:** Markdown parsers handling malformed inline code

**Industry Impact:**
This algorithmic pattern appears in production systems at companies like Google, Amazon, Microsoft, Meta, and Netflix. Engineers working on large-scale distributed systems, data processing pipelines, and user-facing applications regularly implement these concepts.

---

## Cybersecurity Applications

This problem demonstrates algorithmic concepts crucial for security engineering:

1. **WAF Sanitization:** ModSecurity cleaning malformed input in SQL injection attempts
2. **XSS Prevention:** Sanitizing unbalanced script tags in user input
3. **Log Parsing:** Splunk handling malformed log entries with unmatched delimiters
4. **Protocol Fuzzing:** AFL/LibFuzzer testing parser robustness
5. **Input Validation:** OWASP filtering malformed expressions
6. **Deobfuscation:** Cleaning malware code with intentionally broken syntax

**Security Engineering Value:**
Security professionals use these algorithms in threat detection systems, security information and event management (SIEM) platforms, intrusion detection/prevention systems (IDS/IPS), and security automation tools. Understanding these patterns is essential for developing robust security solutions.

**Common Security Contexts:**
- **Threat Detection:** Pattern matching and anomaly detection in security logs
- **Performance Security:** Preventing algorithmic complexity attacks (e.g., hash collision DoS)
- **Secure Code Review:** Identifying potential vulnerabilities in algorithm implementations
- **Security Tooling:** Building efficient security scanners and analysis tools
- **Incident Response:** Fast data processing during security investigations

---

## Learning Resources

**Recommended Study Path:**
1. Master the fundamental data structure concepts
2. Practice similar problems with the same pattern
3. Implement the solution from scratch without reference
4. Analyze time/space complexity of alternative approaches
5. Consider edge cases and error handling

**Interview Preparation:**
- This problem has 100.0% frequency in technical interviews
- Expected to solve in 20-45 minutes during coding interviews
- Be prepared to discuss trade-offs and alternative approaches
- Practice explaining your thought process clearly

**Common Pitfalls:**
- Off-by-one errors in array/string indexing
- Not handling edge cases (empty input, single element, etc.)
- Incorrect complexity analysis
- Over-complicating the solution

**Optimization Tips:**
- Consider early termination conditions
- Minimize unnecessary data structure operations
- Use built-in language features efficiently
- Profile for performance on large inputs

---

*Generated for educational purposes. Problem source: [LeetCode](https://leetcode.com/problems/minimum-remove-to-make-valid-parentheses)*
