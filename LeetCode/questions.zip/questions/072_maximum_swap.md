# 072. Maximum Swap

**Difficulty:** MEDIUM
**Frequency:** 40.7%
**Acceptance Rate:** 51.8%
**LeetCode Link:** [Maximum Swap](https://leetcode.com/problems/maximum-swap)

---

## Problem Description

You are given an integer `num`. You can swap two digits at most once to get the maximum valued number.

Return the maximum valued number you can get.

**Constraints:**
- 0 <= num <= 10^8

---

## Examples

### Example 1
**Input:** `num = 2736`
**Output:** `7236`
**Explanation:** Swap 2 and 7 to get maximum

### Example 2
**Input:** `num = 9973`
**Output:** `9973`
**Explanation:** Already maximum, no swap needed

### Example 3
**Input:** `num = 98368`
**Output:** `98863`
**Explanation:** Swap 3 and 8 to maximize

### Example 4
**Input:** `num = 1993`
**Output:** `9913`
**Explanation:** Swap first 1 with last 9

---

## Optimal Solution

### Implementation

```python
def maximumSwap(num: int) -> int:
    """
    Find rightmost occurrence of each digit, greedy swap.

    Time: O(n), Space: O(1) - max 10 digits
    """
    digits = list(str(num))
    n = len(digits)

    # Record last occurrence of each digit
    last = {int(d): i for i, d in enumerate(digits)}

    # Try to find first digit that can be swapped with larger one
    for i in range(n):
        # Look for larger digit (9 down to current+1)
        for d in range(9, int(digits[i]), -1):
            if last.get(d, -1) > i:
                # Swap with rightmost occurrence of larger digit
                digits[i], digits[last[d]] = digits[last[d]], digits[i]
                return int(''.join(digits))

    return num
```

### Complexity Analysis

**Time: O(n) - single pass with constant digit checks. Space: O(1) - max 10 digits**

**Why This is Optimal:**
- Achieves best possible asymptotic complexity for this problem class
- Minimal space overhead while maintaining code clarity
- Scales efficiently with large inputs
- Handles all edge cases correctly

---

## Categories & Tags

**Primary Topics:** Math, Greedy

**Difficulty Level:** MEDIUM

---

## Real-World Applications

Understanding this algorithmic pattern has direct real-world applications:

1. **Pricing Optimization:** Adjusting prices for maximum appeal
2. **Phone Number Selection:** Choosing most memorable number permutations
3. **ID Generation:** Optimizing identifier values
4. **Lottery Analysis:** Finding best number combinations
5. **Financial Trading:** Order price optimization with minimal changes
6. **Serial Numbers:** Generating attractive product serial numbers

**Industry Impact:**
This algorithmic pattern appears in production systems at companies like Google, Amazon, Microsoft, Meta, and Netflix. Engineers working on large-scale distributed systems, data processing pipelines, and user-facing applications regularly implement these concepts.

---

## Cybersecurity Applications

This problem demonstrates algorithmic concepts crucial for security engineering:

1. **Password Cracking:** Testing common digit swap variations in passwords
2. **Brute Force:** Optimizing attack payloads by maximizing effectiveness
3. **Evasion Techniques:** Slightly modifying signatures to maximize detection bypass
4. **Port Selection:** Choosing ports to maximize likelihood of being open
5. **Hash Collision:** Finding maximum collision-prone values
6. **Fuzzing:** Generating test inputs that maximize code coverage
7. **Obfuscation:** Maximizing code value changes with minimal modifications

**Security Engineering Value:**
Security professionals use these algorithms in threat detection systems, security information and event management (SIEM) platforms, intrusion detection/prevention systems (IDS/IPS), and security automation tools. Understanding these patterns is essential for developing robust security solutions.

**Common Security Contexts:**
- **Threat Detection:** Pattern matching and anomaly detection in security logs
- **Performance Security:** Preventing algorithmic complexity attacks (e.g., hash collision DoS)
- **Secure Code Review:** Identifying potential vulnerabilities in algorithm implementations
- **Security Tooling:** Building efficient security scanners and analysis tools
- **Incident Response:** Fast data processing during security investigations

---

## Learning Resources

**Recommended Study Path:**
1. Master the fundamental data structure concepts
2. Practice similar problems with the same pattern
3. Implement the solution from scratch without reference
4. Analyze time/space complexity of alternative approaches
5. Consider edge cases and error handling

**Interview Preparation:**
- This problem has 40.7% frequency in technical interviews
- Expected to solve in 20-45 minutes during coding interviews
- Be prepared to discuss trade-offs and alternative approaches
- Practice explaining your thought process clearly

**Common Pitfalls:**
- Off-by-one errors in array/string indexing
- Not handling edge cases (empty input, single element, etc.)
- Incorrect complexity analysis
- Over-complicating the solution

**Optimization Tips:**
- Consider early termination conditions
- Minimize unnecessary data structure operations
- Use built-in language features efficiently
- Profile for performance on large inputs

---

*Generated for educational purposes. Problem source: [LeetCode](https://leetcode.com/problems/maximum-swap)*
