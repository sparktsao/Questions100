# 042. Find First and Last Position of Element in Sorted Array

**Difficulty:** MEDIUM
**Frequency:** 59.4%
**Acceptance Rate:** 46.8%
**LeetCode Link:** [Find First and Last Position of Element in Sorted Array](https://leetcode.com/problems/find-first-and-last-position-of-element-in-sorted-array)

---

## Problem Description

Given an array of integers `nums` sorted in non-decreasing order, find the starting and ending position of a given `target` value.

If `target` is not found in the array, return `[-1, -1]`.

You must write an algorithm with O(log n) runtime complexity.

**Constraints:**
- 0 <= nums.length <= 10^5
- -10^9 <= nums[i] <= 10^9
- nums is a non-decreasing array
- -10^9 <= target <= 10^9

---

## Examples

### Example 1
**Input:** `nums = [5,7,7,8,8,10], target = 8`
**Output:** `[3,4]`
**Explanation:** Target 8 appears at indices 3 and 4

### Example 2
**Input:** `nums = [5,7,7,8,8,10], target = 6`
**Output:** `[-1,-1]`
**Explanation:** Target 6 is not in the array

### Example 3
**Input:** `nums = [], target = 0`
**Output:** `[-1,-1]`
**Explanation:** Empty array, target cannot be found

### Example 4
**Input:** `nums = [1], target = 1`
**Output:** `[0,0]`
**Explanation:** Single element that matches target

---

## Optimal Solution

### Implementation

```python
def searchRange(nums: List[int], target: int) -> List[int]:
    """
    Find first and last position using two binary searches.

    Time: O(log n), Space: O(1)
    """
    def findBound(nums: List[int], target: int, isFirst: bool) -> int:
        """Helper to find left or right boundary"""
        left, right = 0, len(nums) - 1
        bound = -1

        while left <= right:
            mid = left + (right - left) // 2

            if nums[mid] == target:
                bound = mid
                # Continue searching for first/last occurrence
                if isFirst:
                    right = mid - 1  # Search left half for first
                else:
                    left = mid + 1   # Search right half for last
            elif nums[mid] < target:
                left = mid + 1
            else:
                right = mid - 1

        return bound

    if not nums:
        return [-1, -1]

    first = findBound(nums, target, True)
    if first == -1:
        return [-1, -1]

    last = findBound(nums, target, False)
    return [first, last]
```

### Alternative Concise Implementation

```python
def searchRange(nums: List[int], target: int) -> List[int]:
    """
    Using bisect library for cleaner code.

    Time: O(log n), Space: O(1)
    """
    import bisect

    left = bisect.bisect_left(nums, target)
    right = bisect.bisect_right(nums, target) - 1

    if left <= right:
        return [left, right]
    return [-1, -1]
```

### Complexity Analysis

**Time: O(log n) - two binary searches. Space: O(1) - constant**

**Why This is Optimal:**
- Meets the required O(log n) time complexity constraint
- Two separate binary searches for first and last positions
- No extra space needed beyond variables
- Handles duplicates efficiently by continuing search after finding target

---

## Categories & Tags

**Primary Topics:** Array, Binary Search

**Difficulty Level:** MEDIUM

---

## Real-World Applications

Understanding this algorithmic pattern has direct real-world applications:

1. **Database Indexing:** PostgreSQL B-tree index range scans, MySQL InnoDB clustered index lookups for finding all records in a range
2. **Time-Series Databases:** Finding start/end of time ranges in InfluxDB, TimescaleDB for querying sensor data within specific timestamps
3. **Log Analysis:** Elasticsearch range queries for finding log entries within a time window, Splunk search optimization
4. **E-commerce:** Amazon/eBay price range filters finding products within min/max price bounds
5. **Search Engines:** Google search result pagination, finding first and last relevant documents for a query term

**Industry Impact:**
This pattern is fundamental to range query optimization in databases and search systems. Every major database system uses variants of this algorithm for index range scans. Understanding this helps optimize queries that filter by ranges, which is one of the most common operations in production systems.

---

## Cybersecurity Applications

This problem demonstrates algorithmic concepts crucial for security engineering:

1. **Log Correlation:** Finding temporal boundaries of security events in SIEM systems (Splunk, ELK) to correlate attack patterns across time ranges
2. **Threat Hunting:** Identifying first and last occurrence of malicious IP addresses in firewall logs (Palo Alto, Fortinet) for timeline reconstruction
3. **Forensic Analysis:** Locating file access time ranges during incident response using filesystem metadata analysis (Autopsy, FTK)
4. **Intrusion Detection:** Finding start/end of anomalous behavior patterns in IDS/IPS systems (Snort, Suricata) for attack duration analysis
5. **Vulnerability Scanning:** Identifying version ranges of vulnerable software in asset inventories (Nessus, Qualys) for patch prioritization
6. **Access Control Auditing:** Finding first/last access attempts for compromised credentials in IAM audit logs (Okta, Auth0)

**Security Engineering Value:**
Range queries are essential for security timeline analysis. During incident response, security teams need to quickly identify when an attack started and ended. This algorithm pattern enables efficient temporal correlation of security events, helping teams understand attack progression and blast radius.

**Common Security Contexts:**
- **Threat Detection:** Pattern matching and anomaly detection in security logs
- **Performance Security:** Preventing algorithmic complexity attacks (e.g., hash collision DoS)
- **Secure Code Review:** Identifying potential vulnerabilities in algorithm implementations
- **Security Tooling:** Building efficient security scanners and analysis tools
- **Incident Response:** Fast data processing during security investigations

---

## Learning Resources

**Recommended Study Path:**
1. Master standard binary search before attempting variants
2. Practice similar problems: First Bad Version, Search Insert Position
3. Implement the solution from scratch without reference
4. Understand the difference between left and right boundary searches
5. Consider edge cases: empty array, target not found, all duplicates

**Interview Preparation:**
- This problem has 59.4% frequency in technical interviews
- Expected to solve in 25-35 minutes during coding interviews
- Be prepared to explain why two separate binary searches are needed
- Practice explaining boundary search logic clearly

**Common Pitfalls:**
- Using single binary search and then expanding linearly (breaks O(log n) requirement)
- Incorrect boundary conditions in while loop
- Off-by-one errors when updating left/right pointers
- Not handling empty array or target not found cases

**Optimization Tips:**
- Early exit if first position is not found
- Can optimize to single pass using modified binary search
- Consider using built-in bisect functions for cleaner code
- Test with arrays where all elements are the target

---

*Generated for educational purposes. Problem source: [LeetCode](https://leetcode.com/problems/find-first-and-last-position-of-element-in-sorted-array)*
