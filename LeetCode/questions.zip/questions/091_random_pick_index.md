# 091. Random Pick Index

**Difficulty:** MEDIUM
**Frequency:** 32.0%
**Acceptance Rate:** 64.5%
**LeetCode Link:** [Random Pick Index](https://leetcode.com/problems/random-pick-index)

---

## Problem Description

Given an integer array `nums` with possible duplicates, randomly output the index of a given `target` number. You can assume that the given target number must exist in the array.

Implement the `Solution` class:

- `Solution(int[] nums)` Initializes the object with the array `nums`
- `int pick(int target)` Picks a random index `i` from `nums` where `nums[i] == target`. If there are multiple valid indices, each index should have equal probability of returning

**Constraints:**
- 1 <= nums.length <= 2 * 10^4
- -2^31 <= nums[i] <= 2^31 - 1
- target is an integer from nums
- At most 10^4 calls to pick

---

## Examples

### Example 1
**Input:** `["Solution", "pick", "pick", "pick"]\n[[[1,2,3,3,3]], [3], [1], [3]]`
**Output:** `[null, 4, 0, 2]`
**Explanation:** pick(3) can return 2, 3, or 4 with equal probability

### Example 2
**Input:** `nums = [1,1,1], pick(1)`
**Output:** `0, 1, or 2`
**Explanation:** All indices equally likely

### Example 3
**Input:** `nums = [1,2,3], pick(2)`
**Output:** `1`
**Explanation:** Only one occurrence of 2

---

## Optimal Solution

### Implementation

```python
class Solution:
    def __init__(self, nums: List[int]):
        """
        Store array for reservoir sampling.

        Time: O(1), Space: O(n)
        """
        self.nums = nums

    def pick(self, target: int) -> int:
        """
        Reservoir sampling for uniform random selection.

        Time: O(n), Space: O(1)
        """
        import random
        result = -1
        count = 0

        for i, num in enumerate(self.nums):
            if num == target:
                count += 1
                # Reservoir sampling: replace with probability 1/count
                if random.randint(1, count) == 1:
                    result = i

        return result
```

### Complexity Analysis

**Time: O(n) for pick. Space: O(n) - storing array**

**Why This is Optimal:**
- Achieves best possible asymptotic complexity for this problem class
- Minimal space overhead while maintaining code clarity
- Scales efficiently with large inputs
- Handles all edge cases correctly

---

## Categories & Tags

**Primary Topics:** Hash Table, Math, Reservoir Sampling, Randomized

**Difficulty Level:** MEDIUM

---

## Real-World Applications

Understanding this algorithmic pattern has direct real-world applications:

1. **Load Balancing:** Randomly selecting from available servers (Nginx, HAProxy)
2. **A/B Testing:** Randomly assigning users to test groups
3. **Sampling:** Random data sampling in analytics (Google Analytics)
4. **Game Development:** Random item selection from inventory
5. **Ad Selection:** Random ad from pool with equal weight
6. **Playlist Shuffle:** Spotify/Apple Music random song selection

**Industry Impact:**
This algorithmic pattern appears in production systems at companies like Google, Amazon, Microsoft, Meta, and Netflix. Engineers working on large-scale distributed systems, data processing pipelines, and user-facing applications regularly implement these concepts.

---

## Cybersecurity Applications

This problem demonstrates algorithmic concepts crucial for security engineering:

1. **Honeypot Selection:** Randomly choosing decoy from pool
2. **Decoy Routing:** Randomly selecting decoy paths to confuse attackers
3. **Port Randomization:** Random source port selection for connections
4. **Canary Selection:** Randomly placing canary tokens in file system
5. **Deception Technology:** Random fake credential placement
6. **Traffic Analysis Resistance:** Random timing for covert channels
7. **Security Testing:** Random test case selection for fuzzing

**Security Engineering Value:**
Security professionals use these algorithms in threat detection systems, security information and event management (SIEM) platforms, intrusion detection/prevention systems (IDS/IPS), and security automation tools. Understanding these patterns is essential for developing robust security solutions.

**Common Security Contexts:**
- **Threat Detection:** Pattern matching and anomaly detection in security logs
- **Performance Security:** Preventing algorithmic complexity attacks (e.g., hash collision DoS)
- **Secure Code Review:** Identifying potential vulnerabilities in algorithm implementations
- **Security Tooling:** Building efficient security scanners and analysis tools
- **Incident Response:** Fast data processing during security investigations

---

## Learning Resources

**Recommended Study Path:**
1. Master the fundamental data structure concepts
2. Practice similar problems with the same pattern
3. Implement the solution from scratch without reference
4. Analyze time/space complexity of alternative approaches
5. Consider edge cases and error handling

**Interview Preparation:**
- This problem has 32.0% frequency in technical interviews
- Expected to solve in 20-45 minutes during coding interviews
- Be prepared to discuss trade-offs and alternative approaches
- Practice explaining your thought process clearly

**Common Pitfalls:**
- Off-by-one errors in array/string indexing
- Not handling edge cases (empty input, single element, etc.)
- Incorrect complexity analysis
- Over-complicating the solution

**Optimization Tips:**
- Consider early termination conditions
- Minimize unnecessary data structure operations
- Use built-in language features efficiently
- Profile for performance on large inputs

---

*Generated for educational purposes. Problem source: [LeetCode](https://leetcode.com/problems/random-pick-index)*
