# 002. Valid Word Abbreviation

**Difficulty:** EASY
**Frequency:** 95.4%
**Acceptance Rate:** 36.9%
**LeetCode Link:** [Valid Word Abbreviation](https://leetcode.com/problems/valid-word-abbreviation)

---

## Problem Description

A string can be abbreviated by replacing any number of non-adjacent, non-empty substrings with their lengths. For example, "substitution" can be abbreviated as "s10n" ("s ubstitutio n"), "sub4u4" ("sub stit u tion"), and more.

Given a string `word` and an abbreviation `abbr`, return whether the abbreviation matches the string.

**Constraints:**
- 1 <= word.length <= 20
- word consists of only lowercase English letters
- 1 <= abbr.length <= 10
- abbr consists of lowercase English letters and digits
- All numbers in abbr will fit in 32-bit integer

---

## Examples

### Example 1
**Input:** `word = "internationalization", abbr = "i12iz4n"`
**Output:** `true`
**Explanation:** i + 12 chars + iz + 4 chars + n matches

### Example 2
**Input:** `word = "apple", abbr = "a2e"`
**Output:** `false`
**Explanation:** a + 2 chars should be 'pp', but next char is 'e' not 'l'

### Example 3
**Input:** `word = "substitution", abbr = "s10n"`
**Output:** `true`
**Explanation:** s + 10 chars + n matches

### Example 4
**Input:** `word = "hi", abbr = "1"`
**Output:** `false`
**Explanation:** Leading zeros not allowed (implicit)

---

## Optimal Solution

### Implementation

```python
def validWordAbbreviation(word: str, abbr: str) -> bool:
    """
    Two pointers to validate abbreviation.

    Time: O(n), Space: O(1)
    """
    i = j = 0

    while i < len(word) and j < len(abbr):
        if abbr[j].isdigit():
            # Leading zero check
            if abbr[j] == '0':
                return False

            # Parse number
            num = 0
            while j < len(abbr) and abbr[j].isdigit():
                num = num * 10 + int(abbr[j])
                j += 1
            i += num
        else:
            # Character must match
            if word[i] != abbr[j]:
                return False
            i += 1
            j += 1

    return i == len(word) and j == len(abbr)
```

### Complexity Analysis

**Time: O(n) - single pass. Space: O(1) - constant**

**Why This is Optimal:**
- Achieves best possible asymptotic complexity for this problem class
- Minimal space overhead while maintaining code clarity
- Scales efficiently with large inputs
- Handles all edge cases correctly

---

## Categories & Tags

**Primary Topics:** Two Pointers, String

**Difficulty Level:** EASY

---

## Real-World Applications

Understanding this algorithmic pattern has direct real-world applications:

1. **Text Compression:** Slack/Discord message compression for bandwidth
2. **Code Refactoring:** VS Code abbreviation expansion
3. **Documentation:** API docs using abbreviated type names
4. **URL Shorteners:** Bitly/TinyURL pattern matching
5. **Natural Language:** Autocomplete systems understanding abbreviations

**Industry Impact:**
This algorithmic pattern appears in production systems at companies like Google, Amazon, Microsoft, Meta, and Netflix. Engineers working on large-scale distributed systems, data processing pipelines, and user-facing applications regularly implement these concepts.

---

## Cybersecurity Applications

This problem demonstrates algorithmic concepts crucial for security engineering:

1. **Log Analysis:** SIEM normalizing abbreviated log formats
2. **Signature Matching:** Antivirus detecting abbreviated malware patterns
3. **Command Injection:** WAF detecting abbreviated shell commands
4. **Protocol Analysis:** Wireshark decoding abbreviated protocol fields
5. **Threat Intelligence:** MISP matching abbreviated IOC formats
6. **Fuzzing:** Testing parsers with abbreviated input variations

**Security Engineering Value:**
Security professionals use these algorithms in threat detection systems, security information and event management (SIEM) platforms, intrusion detection/prevention systems (IDS/IPS), and security automation tools. Understanding these patterns is essential for developing robust security solutions.

**Common Security Contexts:**
- **Threat Detection:** Pattern matching and anomaly detection in security logs
- **Performance Security:** Preventing algorithmic complexity attacks (e.g., hash collision DoS)
- **Secure Code Review:** Identifying potential vulnerabilities in algorithm implementations
- **Security Tooling:** Building efficient security scanners and analysis tools
- **Incident Response:** Fast data processing during security investigations

---

## Learning Resources

**Recommended Study Path:**
1. Master the fundamental data structure concepts
2. Practice similar problems with the same pattern
3. Implement the solution from scratch without reference
4. Analyze time/space complexity of alternative approaches
5. Consider edge cases and error handling

**Interview Preparation:**
- This problem has 95.4% frequency in technical interviews
- Expected to solve in 20-45 minutes during coding interviews
- Be prepared to discuss trade-offs and alternative approaches
- Practice explaining your thought process clearly

**Common Pitfalls:**
- Off-by-one errors in array/string indexing
- Not handling edge cases (empty input, single element, etc.)
- Incorrect complexity analysis
- Over-complicating the solution

**Optimization Tips:**
- Consider early termination conditions
- Minimize unnecessary data structure operations
- Use built-in language features efficiently
- Profile for performance on large inputs

---

*Generated for educational purposes. Problem source: [LeetCode](https://leetcode.com/problems/valid-word-abbreviation)*
