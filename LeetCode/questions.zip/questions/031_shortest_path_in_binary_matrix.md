# 031. Shortest Path in Binary Matrix

**Difficulty:** MEDIUM
**Frequency:** 67.4%
**Acceptance Rate:** 49.8%
**LeetCode Link:** [Shortest Path in Binary Matrix](https://leetcode.com/problems/shortest-path-in-binary-matrix)

---

## Problem Description

Given an n x n binary matrix `grid`, return the length of the shortest clear path in the matrix. If there is no clear path, return -1.

A clear path in a binary matrix is a path from the top-left cell (i.e., (0, 0)) to the bottom-right cell (i.e., (n - 1, n - 1)) such that:
- All the visited cells of the path are 0
- All the adjacent cells of the path are 8-directionally connected (i.e., they are different and they share an edge or a corner)
- The length of a clear path is the number of visited cells of this path

**Constraints:**
- n == grid.length
- n == grid[i].length
- 1 <= n <= 100
- grid[i][j] is 0 or 1

---

## Examples

### Example 1
**Input:** `grid = [[0,1],[1,0]]`
**Output:** `2`
**Explanation:** The path from top-left to bottom-right is clear with length 2

### Example 2
**Input:** `grid = [[0,0,0],[1,1,0],[1,1,0]]`
**Output:** `4`
**Explanation:** The shortest clear path has length 4

### Example 3
**Input:** `grid = [[1,0,0],[1,1,0],[1,1,0]]`
**Output:** `-1`
**Explanation:** No clear path exists since top-left cell is 1

### Example 4
**Input:** `grid = [[0]]`
**Output:** `1`
**Explanation:** Single cell grid, path length is 1

---

## Optimal Solution

### Implementation

```python
def shortestPathBinaryMatrix(grid: List[List[int]]) -> int:
    """
    BFS to find shortest path in binary matrix with 8-directional movement.

    Time: O(n^2), Space: O(n^2)
    """
    from collections import deque

    n = len(grid)

    # Check if start or end is blocked
    if grid[0][0] == 1 or grid[n-1][n-1] == 1:
        return -1

    # 8 directions: up, down, left, right, and 4 diagonals
    directions = [(-1,-1), (-1,0), (-1,1), (0,-1), (0,1), (1,-1), (1,0), (1,1)]

    # BFS
    queue = deque([(0, 0, 1)])  # (row, col, path_length)
    grid[0][0] = 1  # Mark as visited

    while queue:
        row, col, length = queue.popleft()

        # Check if reached destination
        if row == n-1 and col == n-1:
            return length

        # Explore all 8 directions
        for dr, dc in directions:
            new_row, new_col = row + dr, col + dc

            # Check bounds and if cell is unvisited (0)
            if 0 <= new_row < n and 0 <= new_col < n and grid[new_row][new_col] == 0:
                queue.append((new_row, new_col, length + 1))
                grid[new_row][new_col] = 1  # Mark as visited

    return -1  # No path found
```

### Complexity Analysis

**Time: O(n^2) - visit each cell at most once. Space: O(n^2) - queue size in worst case**

**Why This is Optimal:**
- BFS guarantees shortest path in unweighted graphs
- Each cell visited at most once due to marking
- 8-directional movement handled efficiently
- Early termination when destination reached

---

## Categories & Tags

**Primary Topics:** Array, Breadth-First Search, Matrix

**Difficulty Level:** MEDIUM

---

## Real-World Applications

Understanding this algorithmic pattern has direct real-world applications:

1. **GPS Navigation:** Google Maps, Waze finding shortest routes on city grids
2. **Game Development:** Pathfinding algorithms in Unity, Unreal Engine for character movement
3. **Robotics:** Motion planning for autonomous vehicles, warehouse robots (Amazon Robotics)
4. **Network Routing:** Finding shortest paths in mesh networks, data packet routing
5. **Image Processing:** Maze solving algorithms, connected component analysis

**Industry Impact:**
BFS-based pathfinding algorithms are fundamental to navigation systems, game AI, robotics platforms, and network protocols. Companies like Google, Tesla, and game studios rely on efficient pathfinding algorithms for real-time route calculation and autonomous decision-making.

---

## Cybersecurity Applications

This problem demonstrates algorithmic concepts crucial for security engineering:

1. **Network Security:** Modeling attack paths through network topology in Metasploit
2. **Firewall Analysis:** Finding shortest attack paths through firewall rules
3. **Vulnerability Chaining:** CVSS score calculation with exploit path analysis
4. **Penetration Testing:** Automated path discovery for privilege escalation
5. **Access Control:** Graph-based permission analysis in IAM systems
6. **Threat Modeling:** Attack tree analysis for risk assessment

**Security Engineering Value:**
Pathfinding algorithms help security engineers model attack surfaces, analyze network vulnerabilities, and identify potential exploit chains. These techniques are used in penetration testing frameworks, vulnerability scanners, and security graph databases to map and analyze system connectivity.

**Common Security Contexts:**
- **Threat Detection:** Pattern matching and anomaly detection in security logs
- **Performance Security:** Preventing algorithmic complexity attacks (e.g., hash collision DoS)
- **Secure Code Review:** Identifying potential vulnerabilities in algorithm implementations
- **Security Tooling:** Building efficient security scanners and analysis tools
- **Incident Response:** Fast data processing during security investigations

---

## Learning Resources

**Recommended Study Path:**
1. Master the fundamental data structure concepts
2. Practice similar problems with the same pattern
3. Implement the solution from scratch without reference
4. Analyze time/space complexity of alternative approaches
5. Consider edge cases and error handling

**Interview Preparation:**
- This problem has 67.4% frequency in technical interviews
- Expected to solve in 20-45 minutes during coding interviews
- Be prepared to discuss trade-offs and alternative approaches
- Practice explaining your thought process clearly

**Common Pitfalls:**
- Off-by-one errors in array/string indexing
- Not handling edge cases (empty input, single element, etc.)
- Incorrect complexity analysis
- Over-complicating the solution

**Optimization Tips:**
- Consider early termination conditions
- Minimize unnecessary data structure operations
- Use built-in language features efficiently
- Profile for performance on large inputs

---

*Generated for educational purposes. Problem source: [LeetCode](https://leetcode.com/problems/shortest-path-in-binary-matrix)*
