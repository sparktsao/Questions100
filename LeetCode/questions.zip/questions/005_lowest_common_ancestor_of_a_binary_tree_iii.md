# 005. Lowest Common Ancestor of a Binary Tree III

**Difficulty:** MEDIUM
**Frequency:** 89.6%
**Acceptance Rate:** 82.5%
**LeetCode Link:** [Lowest Common Ancestor of a Binary Tree III](https://leetcode.com/problems/lowest-common-ancestor-of-a-binary-tree-iii)

---

## Problem Description

Given two nodes of a binary tree `p` and `q`, return their lowest common ancestor (LCA).

Each node will have a reference to its parent node. The definition for Node is:
```
class Node {
    public int val;
    public Node left;
    public Node right;
    public Node parent;
}
```

**Constraints:**
- The number of nodes in the tree is in the range [2, 10^5]
- -10^9 <= Node.val <= 10^9
- All Node.val are unique
- p != q
- p and q exist in the tree

---

## Examples

### Example 1
**Input:** `root = [3,5,1,6,2,0,8,null,null,7,4], p = 5, q = 1`
**Output:** `3`
**Explanation:** LCA of 5 and 1 is 3

### Example 2
**Input:** `root = [3,5,1,6,2,0,8,null,null,7,4], p = 5, q = 4`
**Output:** `5`
**Explanation:** LCA of 5 and 4 is 5 (node can be ancestor of itself)

### Example 3
**Input:** `root = [1,2], p = 1, q = 2`
**Output:** `1`
**Explanation:** Root is LCA

---

## Optimal Solution

### Implementation

```python
def lowestCommonAncestor(p: 'Node', q: 'Node') -> 'Node':
    """
    Use parent pointers like finding intersection in linked lists.

    Time: O(h), Space: O(1)
    """
    # Get depths
    p1, p2 = p, q

    # Traverse to root, when reach None, switch to other node's path
    # They will meet at LCA
    while p1 != p2:
        p1 = p1.parent if p1.parent else q
        p2 = p2.parent if p2.parent else p

    return p1
```

### Complexity Analysis

**Time: O(h) - height of tree. Space: O(1) - constant**

**Why This is Optimal:**
- Achieves best possible asymptotic complexity for this problem class
- Minimal space overhead while maintaining code clarity
- Scales efficiently with large inputs
- Handles all edge cases correctly

---

## Categories & Tags

**Primary Topics:** Hash Table, Two Pointers, Tree, Binary Tree

**Difficulty Level:** MEDIUM

---

## Real-World Applications

Understanding this algorithmic pattern has direct real-world applications:

1. **Version Control:** Git finding merge base of two branches
2. **File Systems:** Finding common parent directory in Unix/Linux paths
3. **Organization Charts:** HR systems finding common manager
4. **Taxonomy Systems:** Biology databases finding common ancestor species
5. **Network Routing:** Finding common network gateway

**Industry Impact:**
This algorithmic pattern appears in production systems at companies like Google, Amazon, Microsoft, Meta, and Netflix. Engineers working on large-scale distributed systems, data processing pipelines, and user-facing applications regularly implement these concepts.

---

## Cybersecurity Applications

This problem demonstrates algorithmic concepts crucial for security engineering:

1. **Privilege Escalation:** BloodHound finding common privilege point in AD
2. **Attack Path:** MITRE ATT&CK finding common technique node
3. **Process Tree:** Windows Sysinternals finding common parent process
4. **Certificate Chain:** OpenSSL finding common CA in cert validation
5. **Access Control:** Finding common permission ancestor in RBAC hierarchy
6. **Malware Analysis:** Finding common behavior node in execution tree

**Security Engineering Value:**
Security professionals use these algorithms in threat detection systems, security information and event management (SIEM) platforms, intrusion detection/prevention systems (IDS/IPS), and security automation tools. Understanding these patterns is essential for developing robust security solutions.

**Common Security Contexts:**
- **Threat Detection:** Pattern matching and anomaly detection in security logs
- **Performance Security:** Preventing algorithmic complexity attacks (e.g., hash collision DoS)
- **Secure Code Review:** Identifying potential vulnerabilities in algorithm implementations
- **Security Tooling:** Building efficient security scanners and analysis tools
- **Incident Response:** Fast data processing during security investigations

---

## Learning Resources

**Recommended Study Path:**
1. Master the fundamental data structure concepts
2. Practice similar problems with the same pattern
3. Implement the solution from scratch without reference
4. Analyze time/space complexity of alternative approaches
5. Consider edge cases and error handling

**Interview Preparation:**
- This problem has 89.6% frequency in technical interviews
- Expected to solve in 20-45 minutes during coding interviews
- Be prepared to discuss trade-offs and alternative approaches
- Practice explaining your thought process clearly

**Common Pitfalls:**
- Off-by-one errors in array/string indexing
- Not handling edge cases (empty input, single element, etc.)
- Incorrect complexity analysis
- Over-complicating the solution

**Optimization Tips:**
- Consider early termination conditions
- Minimize unnecessary data structure operations
- Use built-in language features efficiently
- Profile for performance on large inputs

---

*Generated for educational purposes. Problem source: [LeetCode](https://leetcode.com/problems/lowest-common-ancestor-of-a-binary-tree-iii)*
