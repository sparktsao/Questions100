# 080. Longest Substring Without Repeating Characters

**Difficulty:** MEDIUM
**Frequency:** 40.7%
**Acceptance Rate:** 36.9%
**LeetCode Link:** [Longest Substring Without Repeating Characters](https://leetcode.com/problems/longest-substring-without-repeating-characters)

---

## Problem Description

Given a string `s`, find the length of the longest substring without repeating characters.

**Constraints:**
- 0 <= s.length <= 5 * 10^4
- s consists of English letters, digits, symbols and spaces

---

## Examples

### Example 1
**Input:** `s = "abcabcbb"`
**Output:** `3`
**Explanation:** Longest substring is "abc", length 3

### Example 2
**Input:** `s = "bbbbb"`
**Output:** `1`
**Explanation:** Longest substring is "b", length 1

### Example 3
**Input:** `s = "pwwkew"`
**Output:** `3`
**Explanation:** Longest substring is "wke", length 3

### Example 4
**Input:** `s = ""`
**Output:** `0`
**Explanation:** Empty string

---

## Optimal Solution

### Implementation

```python
def lengthOfLongestSubstring(s: str) -> int:
    """
    Sliding window with hash set.

    Time: O(n), Space: O(min(m,n)) where m is charset size
    """
    char_set = set()
    left = 0
    max_length = 0

    for right in range(len(s)):
        # Shrink window if duplicate found
        while s[right] in char_set:
            char_set.remove(s[left])
            left += 1

        char_set.add(s[right])
        max_length = max(max_length, right - left + 1)

    return max_length
```

### Complexity Analysis

**Time: O(n) - each char visited at most twice. Space: O(min(m,n)) - character set**

**Why This is Optimal:**
- Achieves best possible asymptotic complexity for this problem class
- Minimal space overhead while maintaining code clarity
- Scales efficiently with large inputs
- Handles all edge cases correctly

---

## Categories & Tags

**Primary Topics:** Hash Table, String, Sliding Window

**Difficulty Level:** MEDIUM

---

## Real-World Applications

Understanding this algorithmic pattern has direct real-world applications:

1. **Text Editors:** Autocomplete substring analysis in VS Code
2. **Data Deduplication:** Finding unique data chunks for compression
3. **Stream Processing:** Kafka/Flink unique event windows
4. **Cache Design:** LRU cache key uniqueness validation
5. **URL Parsing:** Extracting unique parameter segments
6. **Database Query:** Finding distinct consecutive records

**Industry Impact:**
This algorithmic pattern appears in production systems at companies like Google, Amazon, Microsoft, Meta, and Netflix. Engineers working on large-scale distributed systems, data processing pipelines, and user-facing applications regularly implement these concepts.

---

## Cybersecurity Applications

This problem demonstrates algorithmic concepts crucial for security engineering:

1. **Password Strength:** Checking character diversity in passwords
2. **Session Token:** Validating unique character distribution in tokens
3. **Log Analysis:** Finding unique event patterns in security logs
4. **Malware Detection:** Analyzing unique byte sequences in samples
5. **Intrusion Detection:** Finding unusual unique packet patterns
6. **API Key Validation:** Checking entropy in generated keys
7. **Fuzzing:** Generating inputs with maximum unique character variety

**Security Engineering Value:**
Security professionals use these algorithms in threat detection systems, security information and event management (SIEM) platforms, intrusion detection/prevention systems (IDS/IPS), and security automation tools. Understanding these patterns is essential for developing robust security solutions.

**Common Security Contexts:**
- **Threat Detection:** Pattern matching and anomaly detection in security logs
- **Performance Security:** Preventing algorithmic complexity attacks (e.g., hash collision DoS)
- **Secure Code Review:** Identifying potential vulnerabilities in algorithm implementations
- **Security Tooling:** Building efficient security scanners and analysis tools
- **Incident Response:** Fast data processing during security investigations

---

## Learning Resources

**Recommended Study Path:**
1. Master the fundamental data structure concepts
2. Practice similar problems with the same pattern
3. Implement the solution from scratch without reference
4. Analyze time/space complexity of alternative approaches
5. Consider edge cases and error handling

**Interview Preparation:**
- This problem has 40.7% frequency in technical interviews
- Expected to solve in 20-45 minutes during coding interviews
- Be prepared to discuss trade-offs and alternative approaches
- Practice explaining your thought process clearly

**Common Pitfalls:**
- Off-by-one errors in array/string indexing
- Not handling edge cases (empty input, single element, etc.)
- Incorrect complexity analysis
- Over-complicating the solution

**Optimization Tips:**
- Consider early termination conditions
- Minimize unnecessary data structure operations
- Use built-in language features efficiently
- Profile for performance on large inputs

---

*Generated for educational purposes. Problem source: [LeetCode](https://leetcode.com/problems/longest-substring-without-repeating-characters)*
