# 056. Remove Invalid Parentheses

**Difficulty:** HARD
**Frequency:** 47.0%
**Acceptance Rate:** 49.2%
**LeetCode Link:** [Remove Invalid Parentheses](https://leetcode.com/problems/remove-invalid-parentheses)

---

## Problem Description

Given a string `s` that contains parentheses and letters, remove the minimum number of invalid parentheses to make the input string valid.

Return a list of unique strings that are valid with the minimum number of removals. You may return the answer in any order.

**Constraints:**
- 1 <= s.length <= 25
- s consists of lowercase English letters and parentheses '(' and ')'
- There will be at most 20 parentheses in s

---

## Examples

### Example 1
**Input:** `s = "()())()"`
**Output:** `["(())()","()()()"]`
**Explanation:** Remove one ')' to make it valid. Two possible results.

### Example 2
**Input:** `s = "(a)())()"`
**Output:** `["(a())()","(a)()()"]`
**Explanation:** Remove one ')' at index 4 or 5

### Example 3
**Input:** `s = ")("`
**Output:** `[""]`
**Explanation:** Both parentheses are invalid, remove both

### Example 4
**Input:** `s = "()"`
**Output:** `["()"]`
**Explanation:** String is already valid

---

## Optimal Solution

### Implementation (BFS)

```python
from collections import deque

def removeInvalidParentheses(s: str) -> List[str]:
    """
    BFS to find all valid strings with minimum removals.

    Time: O(2^n) worst case, Space: O(2^n)
    """
    def is_valid(s: str) -> bool:
        """Check if string has valid parentheses."""
        count = 0
        for char in s:
            if char == '(':
                count += 1
            elif char == ')':
                count -= 1
                if count < 0:
                    return False
        return count == 0

    # BFS to generate strings by removing one char at a time
    queue = deque([s])
    visited = {s}
    result = []
    found = False

    while queue:
        current = queue.popleft()

        if is_valid(current):
            result.append(current)
            found = True

        # If we found valid strings, don't go deeper
        if found:
            continue

        # Generate next level by removing one parenthesis
        for i in range(len(current)):
            if current[i] not in '()':
                continue

            next_str = current[:i] + current[i+1:]
            if next_str not in visited:
                visited.add(next_str)
                queue.append(next_str)

    return result
```

### Alternative Implementation (DFS with Pruning)

```python
def removeInvalidParentheses(s: str) -> List[str]:
    """
    DFS with early pruning based on minimum removals needed.

    Time: O(2^n), Space: O(n) for recursion stack
    """
    def calc_removals(s: str) -> tuple:
        """Calculate minimum left and right parentheses to remove."""
        left_remove = right_remove = 0
        for char in s:
            if char == '(':
                left_remove += 1
            elif char == ')':
                if left_remove > 0:
                    left_remove -= 1
                else:
                    right_remove += 1
        return left_remove, right_remove

    def is_valid(s: str) -> bool:
        """Check if string has valid parentheses."""
        count = 0
        for char in s:
            if char == '(':
                count += 1
            elif char == ')':
                count -= 1
                if count < 0:
                    return False
        return count == 0

    def dfs(s: str, start: int, left_rem: int, right_rem: int, result: set) -> None:
        """DFS to find all valid strings."""
        if left_rem == 0 and right_rem == 0:
            if is_valid(s):
                result.add(s)
            return

        for i in range(start, len(s)):
            # Skip duplicates
            if i > start and s[i] == s[i-1]:
                continue

            if s[i] == '(' and left_rem > 0:
                dfs(s[:i] + s[i+1:], i, left_rem - 1, right_rem, result)
            elif s[i] == ')' and right_rem > 0:
                dfs(s[:i] + s[i+1:], i, left_rem, right_rem - 1, result)

    left_rem, right_rem = calc_removals(s)
    result = set()
    dfs(s, 0, left_rem, right_rem, result)
    return list(result)
```

### Complexity Analysis

**BFS Approach:**
- **Time:** O(2^n) in worst case where we try removing each character
  - Each string can generate up to n new strings
  - Validation takes O(n) per string
- **Space:** O(2^n) for queue and visited set in worst case

**DFS Approach:**
- **Time:** O(2^n) but with better pruning in practice
  - Pre-calculating removals reduces search space significantly
  - Skip duplicate characters for optimization
- **Space:** O(n) for recursion stack, plus O(n * 2^n) for result storage

**Why BFS is Often Preferred:**
- Naturally finds minimum removal level (breadth-first)
- Once valid strings found at a level, stop going deeper
- Easier to understand and implement
- Better for finding all solutions at minimum removal count

---

## Categories & Tags

**Primary Topics:** String, Backtracking, Breadth-First Search

**Difficulty Level:** HARD

---

## Real-World Applications

Understanding this algorithmic pattern has direct real-world applications:

1. **Code Auto-Repair:** IDE auto-fix features in IntelliJ IDEA, Visual Studio repairing syntax errors
2. **Compiler Error Recovery:** GCC, Clang attempting to continue compilation after bracket errors
3. **JSON Repair Tools:** Automatically fixing malformed JSON in data pipelines (BigQuery, Spark)
4. **Formula Validators:** Excel, Google Sheets suggesting minimal fixes for formula errors
5. **Web Scraping:** BeautifulSoup, Scrapy handling malformed HTML with unbalanced tags
6. **Configuration File Repair:** YAML/XML validators suggesting minimal corrections

**Industry Impact:**
Error recovery algorithms are critical in development tools, data processing systems, and automated testing. Companies invest heavily in tools that can intelligently suggest minimal fixes to syntax errors, improving developer productivity.

---

## Cybersecurity Applications

This problem demonstrates algorithmic concepts crucial for security engineering:

1. **Malware Deobfuscation:** Reconstructing valid code from obfuscated malware samples in analysis tools
2. **WAF Bypass Detection:** Identifying minimal changes to payloads that evade security filters
3. **Log Sanitization:** Repairing malformed security logs for SIEM ingestion (Splunk, ELK)
4. **Protocol Fuzzing:** Generating near-valid protocol messages for security testing (AFL, Peach)
5. **XSS Filter Testing:** Finding minimal changes to bypass XSS filters in web applications
6. **Configuration Auditing:** Detecting security misconfigurations with minimal valid corrections

**Security Engineering Value:**
Understanding minimal repair algorithms helps security engineers analyze evasion techniques, build robust parsers for malformed input, and develop better fuzzing tools. This is essential for both offensive security (finding bypasses) and defensive security (handling malicious input gracefully).

**Common Security Contexts:**
- **Threat Detection:** Analyzing variations of attack payloads to detect evasion attempts
- **Performance Security:** Preventing DoS through malformed input that triggers expensive repairs
- **Secure Code Review:** Understanding parser robustness and error handling
- **Security Tooling:** Building fuzzers that generate near-valid malicious inputs
- **Incident Response:** Reconstructing valid commands from obfuscated attack logs

---

## Learning Resources

**Recommended Study Path:**
1. Master basic parentheses validation with stack
2. Understand BFS level-order traversal
3. Study backtracking with pruning techniques
4. Practice calculating minimum removals needed
5. Compare BFS vs DFS approaches for this problem

**Interview Preparation:**
- This problem has 47.0% frequency in technical interviews
- Expected to solve in 35-45 minutes during coding interviews
- Start with BFS approach as it's more intuitive
- Be prepared to explain why BFS guarantees minimum removals
- Common follow-up: optimize space complexity, handle multiple bracket types

**Common Pitfalls:**
- Not using visited set leads to exponential redundant work
- Continuing BFS after finding valid strings (not stopping at current level)
- Not handling duplicates (multiple identical results)
- Incorrectly validating strings (forgetting to check final count is 0)
- Not considering strings with letters mixed in

**Optimization Tips:**
- Pre-calculate minimum removals to prune search space (DFS)
- Stop BFS once valid strings found at current level
- Skip consecutive duplicate characters to avoid redundant work
- Use set for results to automatically deduplicate
- Consider the constraint: max 20 parentheses makes brute force feasible

---

*Generated for educational purposes. Problem source: [LeetCode](https://leetcode.com/problems/remove-invalid-parentheses)*
