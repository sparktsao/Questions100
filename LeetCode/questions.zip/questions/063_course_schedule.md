# 063. Course Schedule

**Difficulty:** MEDIUM
**Frequency:** 47.0%
**Acceptance Rate:** 49.2%
**LeetCode Link:** [Course Schedule](https://leetcode.com/problems/course-schedule)

---

## Problem Description

There are a total of `numCourses` courses you have to take, labeled from `0` to `numCourses - 1`. You are given an array `prerequisites` where `prerequisites[i] = [ai, bi]` indicates that you must take course `bi` first if you want to take course `ai`.

For example, the pair `[0, 1]`, indicates that to take course `0` you have to first take course `1`.

Return `true` if you can finish all courses. Otherwise, return `false`.

**Constraints:**
- 1 <= numCourses <= 2000
- 0 <= prerequisites.length <= 5000
- prerequisites[i].length == 2
- 0 <= ai, bi < numCourses
- All the pairs prerequisites[i] are unique

---

## Examples

### Example 1
**Input:** `numCourses = 2, prerequisites = [[1,0]]`
**Output:** `true`
**Explanation:** Take course 0, then course 1

### Example 2
**Input:** `numCourses = 2, prerequisites = [[1,0],[0,1]]`
**Output:** `false`
**Explanation:** Circular dependency - impossible

### Example 3
**Input:** `numCourses = 3, prerequisites = [[1,0],[2,1]]`
**Output:** `true`
**Explanation:** Take 0, then 1, then 2

### Example 4
**Input:** `numCourses = 4, prerequisites = []`
**Output:** `true`
**Explanation:** No prerequisites - all can be taken

---

## Optimal Solution

### Implementation

```python
def canFinish(numCourses: int, prerequisites: List[List[int]]) -> bool:
    """
    Cycle detection using DFS with three states.

    Time: O(V + E), Space: O(V + E)
    """
    from collections import defaultdict

    # Build adjacency list
    graph = defaultdict(list)
    for course, prereq in prerequisites:
        graph[course].append(prereq)

    # 0 = unvisited, 1 = visiting, 2 = visited
    state = [0] * numCourses

    def has_cycle(course):
        if state[course] == 1:  # Currently visiting - cycle!
            return True
        if state[course] == 2:  # Already fully explored
            return False

        # Mark as visiting
        state[course] = 1

        # Check all prerequisites
        for prereq in graph[course]:
            if has_cycle(prereq):
                return True

        # Mark as visited
        state[course] = 2
        return False

    # Check each course
    for course in range(numCourses):
        if has_cycle(course):
            return False

    return True
```

### Complexity Analysis

**Time: O(V + E) - visit vertices and edges. Space: O(V + E) - graph storage**

**Why This is Optimal:**
- Achieves best possible asymptotic complexity for this problem class
- Minimal space overhead while maintaining code clarity
- Scales efficiently with large inputs
- Handles all edge cases correctly

---

## Categories & Tags

**Primary Topics:** Depth-First Search, Breadth-First Search, Graph, Topological Sort

**Difficulty Level:** MEDIUM

---

## Real-World Applications

Understanding this algorithmic pattern has direct real-world applications:

1. **Build Systems:** Maven/Gradle dependency resolution
2. **Package Managers:** npm/pip detecting circular dependencies
3. **Task Scheduling:** Microsoft Project task ordering
4. **Database Schema:** Foreign key circular reference detection
5. **Module Loading:** JavaScript/Python import cycle detection
6. **Compiler:** Detecting circular includes in C/C++

**Industry Impact:**
This algorithmic pattern appears in production systems at companies like Google, Amazon, Microsoft, Meta, and Netflix. Engineers working on large-scale distributed systems, data processing pipelines, and user-facing applications regularly implement these concepts.

---

## Cybersecurity Applications

This problem demonstrates algorithmic concepts crucial for security engineering:

1. **Access Control:** Detecting circular permission dependencies in RBAC
2. **Certificate Chains:** Detecting circular trust in PKI
3. **Dependency Analysis:** Finding circular dependencies in software supply chain
4. **Attack Prerequisites:** Validating attack chain feasibility
5. **Privilege Escalation:** Detecting circular privilege dependencies
6. **Firewall Rules:** Detecting circular rule dependencies
7. **Trust Relationships:** AD trust loop detection (BloodHound)

**Security Engineering Value:**
Security professionals use these algorithms in threat detection systems, security information and event management (SIEM) platforms, intrusion detection/prevention systems (IDS/IPS), and security automation tools. Understanding these patterns is essential for developing robust security solutions.

**Common Security Contexts:**
- **Threat Detection:** Pattern matching and anomaly detection in security logs
- **Performance Security:** Preventing algorithmic complexity attacks (e.g., hash collision DoS)
- **Secure Code Review:** Identifying potential vulnerabilities in algorithm implementations
- **Security Tooling:** Building efficient security scanners and analysis tools
- **Incident Response:** Fast data processing during security investigations

---

## Learning Resources

**Recommended Study Path:**
1. Master the fundamental data structure concepts
2. Practice similar problems with the same pattern
3. Implement the solution from scratch without reference
4. Analyze time/space complexity of alternative approaches
5. Consider edge cases and error handling

**Interview Preparation:**
- This problem has 47.0% frequency in technical interviews
- Expected to solve in 20-45 minutes during coding interviews
- Be prepared to discuss trade-offs and alternative approaches
- Practice explaining your thought process clearly

**Common Pitfalls:**
- Off-by-one errors in array/string indexing
- Not handling edge cases (empty input, single element, etc.)
- Incorrect complexity analysis
- Over-complicating the solution

**Optimization Tips:**
- Consider early termination conditions
- Minimize unnecessary data structure operations
- Use built-in language features efficiently
- Profile for performance on large inputs

---

*Generated for educational purposes. Problem source: [LeetCode](https://leetcode.com/problems/course-schedule)*
