# 023. Custom Sort String

**Difficulty:** MEDIUM
**Frequency:** 73.2%
**Acceptance Rate:** 72.0%
**LeetCode Link:** [Custom Sort String](https://leetcode.com/problems/custom-sort-string)

---

## Problem Description

You are given two strings `order` and `s`. All the characters of `order` are unique and were sorted in some custom order previously.

Permute the characters of `s` so that they match the order that `order` was sorted. More specifically, if a character `x` occurs before a character `y` in `order`, then `x` should occur before `y` in the permuted string.

Return any permutation of `s` that satisfies this property.

**Constraints:**
- 1 <= order.length <= 26
- 1 <= s.length <= 200
- order and s consist of lowercase English letters
- All characters of order are unique

---

## Examples

### Example 1
**Input:** `order = "cba", s = "abcd"`
**Output:** `"dcba"`
**Explanation:** c comes before b and a, so order is d, c, b, a

### Example 2
**Input:** `order = "cbafg", s = "abcd"`
**Output:** `"cbad"`
**Explanation:** c, b, a are ordered, d is not in order so goes at end

### Example 3
**Input:** `order = "kqep", s = "pekeq"`
**Output:** `"kqeep"`
**Explanation:** k first, then q, then e's, then p

### Example 4
**Input:** `order = "abc", s = "zzz"`
**Output:** `"zzz"`
**Explanation:** Characters not in order maintain relative positions

---

## Optimal Solution

### Implementation

```python
def customSortString(order: str, s: str) -> str:
    """
    Count characters and build result based on custom order.

    Time: O(n + m), Space: O(1) - fixed alphabet size
    """
    from collections import Counter

    count = Counter(s)
    result = []

    # Add characters in custom order
    for char in order:
        if char in count:
            result.append(char * count[char])
            del count[char]

    # Add remaining characters
    for char, freq in count.items():
        result.append(char * freq)

    return ''.join(result)
```

### Complexity Analysis

**Time: O(n + m) - count + iterate. Space: O(1) - max 26 lowercase letters**

**Why This is Optimal:**
- Achieves best possible asymptotic complexity for this problem class
- Minimal space overhead while maintaining code clarity
- Scales efficiently with large inputs
- Handles all edge cases correctly

---

## Categories & Tags

**Primary Topics:** Hash Table, String, Sorting

**Difficulty Level:** MEDIUM

---

## Real-World Applications

Understanding this algorithmic pattern has direct real-world applications:

1. **Database Sorting:** Custom collation in MySQL/PostgreSQL for locale-specific sorting
2. **File Managers:** Custom file sort order in Windows Explorer/macOS Finder
3. **Spreadsheets:** Excel custom sort lists for business hierarchies
4. **E-commerce:** Product sorting by custom priority (featured items first)
5. **Task Managers:** Jira/Trello custom priority-based task ordering
6. **Search Results:** Google/Bing custom ranking based on user preferences

**Industry Impact:**
This algorithmic pattern appears in production systems at companies like Google, Amazon, Microsoft, Meta, and Netflix. Engineers working on large-scale distributed systems, data processing pipelines, and user-facing applications regularly implement these concepts.

---

## Cybersecurity Applications

This problem demonstrates algorithmic concepts crucial for security engineering:

1. **Security Event Prioritization:** SIEM custom severity ordering (critical first)
2. **Vulnerability Scoring:** Custom CVSS sorting in Nessus/Qualys scanners
3. **Firewall Rule Ordering:** iptables/pf custom rule priority evaluation
4. **Alert Triage:** Splunk Security custom alert categorization
5. **Incident Classification:** Custom severity ordering in incident response
6. **Threat Feed Ranking:** Custom IOC priority in ThreatConnect/MISP
7. **Compliance Reporting:** Custom control ordering in audit reports

**Security Engineering Value:**
Security professionals use these algorithms in threat detection systems, security information and event management (SIEM) platforms, intrusion detection/prevention systems (IDS/IPS), and security automation tools. Understanding these patterns is essential for developing robust security solutions.

**Common Security Contexts:**
- **Threat Detection:** Pattern matching and anomaly detection in security logs
- **Performance Security:** Preventing algorithmic complexity attacks (e.g., hash collision DoS)
- **Secure Code Review:** Identifying potential vulnerabilities in algorithm implementations
- **Security Tooling:** Building efficient security scanners and analysis tools
- **Incident Response:** Fast data processing during security investigations

---

## Learning Resources

**Recommended Study Path:**
1. Master the fundamental data structure concepts
2. Practice similar problems with the same pattern
3. Implement the solution from scratch without reference
4. Analyze time/space complexity of alternative approaches
5. Consider edge cases and error handling

**Interview Preparation:**
- This problem has 73.2% frequency in technical interviews
- Expected to solve in 20-45 minutes during coding interviews
- Be prepared to discuss trade-offs and alternative approaches
- Practice explaining your thought process clearly

**Common Pitfalls:**
- Off-by-one errors in array/string indexing
- Not handling edge cases (empty input, single element, etc.)
- Incorrect complexity analysis
- Over-complicating the solution

**Optimization Tips:**
- Consider early termination conditions
- Minimize unnecessary data structure operations
- Use built-in language features efficiently
- Profile for performance on large inputs

---

*Generated for educational purposes. Problem source: [LeetCode](https://leetcode.com/problems/custom-sort-string)*
