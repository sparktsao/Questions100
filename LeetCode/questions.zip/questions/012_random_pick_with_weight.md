# 012. Random Pick with Weight

**Difficulty:** MEDIUM
**Frequency:** 80.5%
**Acceptance Rate:** 48.3%
**LeetCode Link:** [Random Pick with Weight](https://leetcode.com/problems/random-pick-with-weight)

---

## Problem Description

You are given a 0-indexed array of positive integers `w` where `w[i]` describes the weight of the i-th index.

You need to implement the function `pickIndex()`, which randomly picks an index in the range `[0, w.length - 1]` (inclusive) and returns it. The probability of picking an index `i` is `w[i] / sum(w)`.

For example, if `w = [1, 3]`, the probability of picking index 0 is `1 / (1 + 3) = 0.25` (25%), and the probability of picking index 1 is `3 / (1 + 3) = 0.75` (75%).

**Constraints:**
- 1 <= w.length <= 10^4
- 1 <= w[i] <= 10^5
- pickIndex will be called at most 10^4 times

---

## Examples

### Example 1
**Input:** `["Solution","pickIndex"], [[[1]],[]]`
**Output:** `[null,0]`
**Explanation:** The only option is to return 0 since there is only one element in w.

### Example 2
**Input:** `["Solution","pickIndex","pickIndex","pickIndex","pickIndex","pickIndex"], [[[1,3]],[],[],[],[],[]]`
**Output:** `[null,1,1,1,1,0]`
**Explanation:**
- Solution(w = [1,3]) creates the Solution object
- pickIndex() should return index 1 with 75% probability (weight 3) and index 0 with 25% probability (weight 1)
- In this example, it returns 1 four times and 0 once, which is consistent with the expected probability distribution

### Example 3
**Input:** `["Solution","pickIndex"], [[[1,2,3,4]],[]]`
**Output:** `[null,3]`
**Explanation:** With weights [1,2,3,4], index 3 has the highest probability (4/10 = 40%) of being picked

### Example 4
**Input:** `["Solution","pickIndex","pickIndex"], [[[5,5,5,5]],[],[]]`
**Output:** `[null,2,0]`
**Explanation:** All weights are equal, so each index has equal 25% probability of being picked

---

## Optimal Solution

### Implementation

```python
import random
from typing import List

class Solution:
    def __init__(self, w: List[int]):
        """
        Initialize with weights array, computing prefix sums for weighted random selection.

        Time: O(n), Space: O(n)
        """
        self.prefix_sums = []
        prefix_sum = 0

        # Build prefix sum array
        for weight in w:
            prefix_sum += weight
            self.prefix_sums.append(prefix_sum)

        self.total_sum = prefix_sum

    def pickIndex(self) -> int:
        """
        Pick a random index based on weights using binary search.

        Time: O(log n), Space: O(1)
        """
        # Generate random number in range [1, total_sum]
        target = random.randint(1, self.total_sum)

        # Binary search for the target in prefix sums
        left, right = 0, len(self.prefix_sums) - 1

        while left < right:
            mid = left + (right - left) // 2

            if self.prefix_sums[mid] < target:
                left = mid + 1
            else:
                right = mid

        return left

# Your Solution object will be instantiated and called as such:
# obj = Solution(w)
# param_1 = obj.pickIndex()
```

### Complexity Analysis

**Time: O(n) for initialization, O(log n) for pickIndex. Space: O(n) - prefix sum array**

**Why This is Optimal:**
- Prefix sum array enables O(log n) weighted random selection via binary search
- Initialization is O(n), which is unavoidable since we must process all weights
- Space complexity is optimal for this approach
- Binary search efficiently finds the target index in the cumulative weight distribution
- Handles all edge cases including single element and equal weights correctly

---

## Categories & Tags

**Primary Topics:** Array, Math, Binary Search, Prefix Sum, Randomized

**Difficulty Level:** MEDIUM

---

## Real-World Applications

Understanding this algorithmic pattern has direct real-world applications:

1. **Load Balancing:** Nginx weighted round-robin for distributing traffic based on server capacity, AWS ELB weighted target groups
2. **Ad Serving:** Google AdWords selecting ads based on bid weights, Facebook ad auction systems
3. **A/B Testing:** Experiment frameworks (Optimizely, Google Optimize) distributing users across variants with weighted probabilities
4. **Gaming Systems:** Loot box probability systems, random item drops with rarity weights in games like Fortnite, League of Legends
5. **Recommendation Engines:** Spotify playlist shuffle with artist weighting, YouTube video suggestions with engagement-based weights

**Industry Impact:**
Weighted random selection is fundamental to modern distributed systems. Companies like Google, Meta, Amazon, and Netflix use this pattern for traffic distribution, content delivery, experimentation platforms, and personalization systems. The prefix sum + binary search approach is production-ready and scales to billions of requests.

---

## Cybersecurity Applications

This problem demonstrates algorithmic concepts crucial for security engineering:

1. **Honeypot Traffic Distribution:** Weighted random selection for distributing attack traffic across honeypot systems (Cowrie, Dionaea) to avoid detection
2. **DDoS Mitigation:** Cloudflare/Akamai using weighted sampling to analyze attack traffic without overwhelming analysis systems
3. **Security Testing:** Fuzzing tools (AFL, LibFuzzer) prioritizing test inputs based on code coverage weights for efficient vulnerability discovery
4. **Threat Intelligence Sampling:** SIEM systems (Splunk, QRadar) using weighted sampling for log analysis when full processing is infeasible
5. **Deception Technology:** TrapX, Attivo Networks using weighted random responses to make honeypots appear more realistic
6. **Alert Prioritization:** Security operations centers using weighted random sampling for alert investigation when resources are limited

**Security Engineering Value:**
Weighted random selection is critical for security systems that must make probabilistic decisions under resource constraints. Understanding this pattern helps build efficient security monitoring systems, realistic deception technologies, and intelligent fuzzing frameworks that prioritize high-impact test cases.

**Common Security Contexts:**
- **Threat Detection:** Weighted sampling of network traffic for anomaly detection without packet loss
- **Performance Security:** Preventing resource exhaustion in security monitoring systems
- **Secure Code Review:** Understanding randomization in cryptographic nonce generation and security protocols
- **Security Tooling:** Building intelligent fuzzers and testing frameworks with weighted input generation
- **Incident Response:** Efficient sampling of large log datasets during investigations

---

## Learning Resources

**Recommended Study Path:**
1. Master the fundamental data structure concepts
2. Practice similar problems with the same pattern
3. Implement the solution from scratch without reference
4. Analyze time/space complexity of alternative approaches
5. Consider edge cases and error handling

**Interview Preparation:**
- This problem has 80.5% frequency in technical interviews
- Expected to solve in 20-45 minutes during coding interviews
- Be prepared to discuss trade-offs and alternative approaches
- Practice explaining your thought process clearly

**Common Pitfalls:**
- Off-by-one errors in array/string indexing
- Not handling edge cases (empty input, single element, etc.)
- Incorrect complexity analysis
- Over-complicating the solution

**Optimization Tips:**
- Consider early termination conditions
- Minimize unnecessary data structure operations
- Use built-in language features efficiently
- Profile for performance on large inputs

---

*Generated for educational purposes. Problem source: [LeetCode](https://leetcode.com/problems/random-pick-with-weight)*
