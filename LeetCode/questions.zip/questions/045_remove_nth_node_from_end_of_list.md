# 045. Remove Nth Node From End of List

**Difficulty:** MEDIUM
**Frequency:** 56.0%
**Acceptance Rate:** 49.0%
**LeetCode Link:** [Remove Nth Node From End of List](https://leetcode.com/problems/remove-nth-node-from-end-of-list)

---

## Problem Description

Given the `head` of a linked list, remove the nth node from the end of the list and return its head.

**Constraints:**
- The number of nodes in the list is sz
- 1 <= sz <= 30
- 0 <= Node.val <= 100
- 1 <= n <= sz

**Follow up:** Could you do this in one pass?

---

## Examples

### Example 1
**Input:** `head = [1,2,3,4,5], n = 2`
**Output:** `[1,2,3,5]`
**Explanation:** Remove the 2nd node from the end (node with value 4)

### Example 2
**Input:** `head = [1], n = 1`
**Output:** `[]`
**Explanation:** Remove the only node, resulting in empty list

### Example 3
**Input:** `head = [1,2], n = 1`
**Output:** `[1]`
**Explanation:** Remove the last node

### Example 4
**Input:** `head = [1,2], n = 2`
**Output:** `[2]`
**Explanation:** Remove the first node

---

## Optimal Solution

### Implementation

```python
# Definition for singly-linked list.
# class ListNode:
#     def __init__(self, val=0, next=None):
#         self.val = val
#         self.next = next

def removeNthFromEnd(head: Optional[ListNode], n: int) -> Optional[ListNode]:
    """
    One-pass solution using two pointers with gap of n.

    Time: O(L) where L is length, Space: O(1)
    """
    # Dummy node to handle edge case of removing head
    dummy = ListNode(0)
    dummy.next = head

    # Initialize two pointers
    first = dummy
    second = dummy

    # Move first pointer n+1 steps ahead
    for _ in range(n + 1):
        first = first.next

    # Move both pointers until first reaches end
    while first:
        first = first.next
        second = second.next

    # Remove the nth node from end
    second.next = second.next.next

    return dummy.next
```

### Alternative Two-Pass Solution

```python
def removeNthFromEnd(head: Optional[ListNode], n: int) -> Optional[ListNode]:
    """
    Two-pass solution: count length, then remove.

    Time: O(L), Space: O(1)
    """
    # First pass: count length
    length = 0
    current = head
    while current:
        length += 1
        current = current.next

    # Edge case: remove head
    if length == n:
        return head.next

    # Second pass: find node before target
    current = head
    for _ in range(length - n - 1):
        current = current.next

    # Remove target node
    current.next = current.next.next

    return head
```

### Complexity Analysis

**Time: O(L) - single pass through list. Space: O(1) - constant extra space**

**Why This is Optimal:**
- One-pass solution meets the follow-up requirement
- Dummy node elegantly handles edge case of removing head
- Two-pointer technique with fixed gap is a classic pattern
- No extra space needed beyond pointers

---

## Categories & Tags

**Primary Topics:** Linked List, Two Pointers

**Difficulty Level:** MEDIUM

---

## Real-World Applications

Understanding this algorithmic pattern has direct real-world applications:

1. **Memory Management:** Implementing LRU cache eviction in Redis, Memcached where least recently used items are removed from end
2. **Undo/Redo Systems:** Text editors (VS Code, Sublime) removing operations from history when limit is reached
3. **Browser History:** Removing entries from browsing history in Chrome, Firefox when storage limit exceeded
4. **Network Buffers:** TCP sliding window protocol removing acknowledged packets from transmission queue
5. **Audio/Video Streaming:** Removing old frames from circular buffers in media players (VLC, Netflix player)

**Industry Impact:**
Linked list manipulation is fundamental to many caching and buffering systems. The two-pointer technique used here is especially useful in scenarios where you need to maintain a sliding window or find elements relative to the end of a sequence without knowing the total length upfront.

---

## Cybersecurity Applications

This problem demonstrates algorithmic concepts crucial for security engineering:

1. **Session Management:** Removing expired sessions from linked list-based session stores in web applications (Express, Django)
2. **Log Rotation:** Efficiently removing old log entries from circular buffers in logging systems (syslog, journald)
3. **IDS/IPS Systems:** Removing outdated connection tracking entries in Snort, Suricata stateful inspection
4. **Rate Limiting:** Sliding window rate limiters removing old timestamp entries (nginx rate limiting, API gateways)
5. **Packet Filtering:** Network stacks removing acknowledged packets from retransmission queues
6. **Forensic Timeline:** Removing irrelevant events from incident timelines during security investigations

**Security Engineering Value:**
Efficient linked list operations are crucial for real-time security systems that maintain sliding windows of recent events. Understanding how to remove elements from the end efficiently enables building responsive security tools that can keep up with high-velocity event streams without memory bloat.

**Common Security Contexts:**
- **Threat Detection:** Pattern matching and anomaly detection in security logs
- **Performance Security:** Preventing algorithmic complexity attacks (e.g., hash collision DoS)
- **Secure Code Review:** Identifying potential vulnerabilities in algorithm implementations
- **Security Tooling:** Building efficient security scanners and analysis tools
- **Incident Response:** Fast data processing during security investigations

---

## Learning Resources

**Recommended Study Path:**
1. Master basic linked list operations (insertion, deletion, traversal)
2. Practice two-pointer techniques on linked lists
3. Understand dummy node pattern for handling edge cases
4. Implement the solution from scratch without reference
5. Consider edge cases: removing head, single node, minimum list size

**Interview Preparation:**
- This problem has 56.0% frequency in technical interviews
- Expected to solve in 20-30 minutes during coding interviews
- Be prepared to explain why dummy node is useful
- Practice explaining the two-pointer gap technique

**Common Pitfalls:**
- Not using dummy node and struggling with removing head
- Off-by-one errors in calculating gap between pointers
- Not handling edge case of single-node list
- Null pointer exceptions when accessing next

**Optimization Tips:**
- Dummy node simplifies edge case handling
- Gap of n+1 positions second pointer correctly before target
- Can combine with other linked list patterns (reversal, cycle detection)
- Test with minimum size lists (1 or 2 nodes)

---

*Generated for educational purposes. Problem source: [LeetCode](https://leetcode.com/problems/remove-nth-node-from-end-of-list)*
