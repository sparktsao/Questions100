# 078. Strobogrammatic Number

**Difficulty:** EASY
**Frequency:** 40.7%
**Acceptance Rate:** 47.6%
**LeetCode Link:** [Strobogrammatic Number](https://leetcode.com/problems/strobogrammatic-number)

---

## Problem Description

Given a string `num` which represents an integer, return `true` if `num` is a strobogrammatic number.

A strobogrammatic number is a number that looks the same when rotated 180 degrees (looked at upside down).

**Constraints:**
- 1 <= num.length <= 50
- num consists of only digits
- num does not contain any leading zeros except for zero itself

---

## Examples

### Example 1
**Input:** `num = "69"`
**Output:** `true`
**Explanation:** 69 rotated 180° is still 69

### Example 2
**Input:** `num = "88"`
**Output:** `true`
**Explanation:** 88 rotated 180° is still 88

### Example 3
**Input:** `num = "962"`
**Output:** `false`
**Explanation:** 962 rotated is not 962

### Example 4
**Input:** `num = "1"`
**Output:** `true`
**Explanation:** Single digit 1, 0, 8 are strobogrammatic

---

## Optimal Solution

### Implementation

```python
def isStrobogrammatic(num: str) -> bool:
    """
    Two pointers checking valid rotation pairs.

    Time: O(n), Space: O(1)
    """
    # Valid pairs when rotated 180°
    pairs = {'0': '0', '1': '1', '6': '9', '8': '8', '9': '6'}

    left, right = 0, len(num) - 1

    while left <= right:
        if num[left] not in pairs or pairs[num[left]] != num[right]:
            return False
        left += 1
        right -= 1

    return True
```

### Complexity Analysis

**Time: O(n) - single pass. Space: O(1) - constant mapping**

**Why This is Optimal:**
- Achieves best possible asymptotic complexity for this problem class
- Minimal space overhead while maintaining code clarity
- Scales efficiently with large inputs
- Handles all edge cases correctly

---

## Categories & Tags

**Primary Topics:** Hash Table, Two Pointers, String

**Difficulty Level:** EASY

---

## Real-World Applications

Understanding this algorithmic pattern has direct real-world applications:

1. **Display Design:** LCD/LED number validation for rotation invariance
2. **Data Validation:** Checking if numbers maintain meaning when flipped
3. **OCR Systems:** Validating scanned numbers in any orientation
4. **Mobile Apps:** Supporting auto-rotate number display
5. **Calculator Design:** Upside-down calculator tricks
6. **Accessibility:** Supporting users who view screens at odd angles

**Industry Impact:**
This algorithmic pattern appears in production systems at companies like Google, Amazon, Microsoft, Meta, and Netflix. Engineers working on large-scale distributed systems, data processing pipelines, and user-facing applications regularly implement these concepts.

---

## Cybersecurity Applications

This problem demonstrates algorithmic concepts crucial for security engineering:

1. **Visual Confusion:** Detecting ambiguous characters in phishing (homoglyph attacks)
2. **Obfuscation Detection:** Finding intentionally confusing number representations
3. **Input Validation:** Preventing unicode trickery with rotatable digits
4. **Social Engineering:** Detecting numbers designed to confuse when inverted
5. **Captcha Bypass:** Testing rotation-invariant number recognition
6. **Steganography:** Using rotation-invariant numbers as covert markers
7. **Domain Squatting:** Finding lookalike domains using rotatable characters

**Security Engineering Value:**
Security professionals use these algorithms in threat detection systems, security information and event management (SIEM) platforms, intrusion detection/prevention systems (IDS/IPS), and security automation tools. Understanding these patterns is essential for developing robust security solutions.

**Common Security Contexts:**
- **Threat Detection:** Pattern matching and anomaly detection in security logs
- **Performance Security:** Preventing algorithmic complexity attacks (e.g., hash collision DoS)
- **Secure Code Review:** Identifying potential vulnerabilities in algorithm implementations
- **Security Tooling:** Building efficient security scanners and analysis tools
- **Incident Response:** Fast data processing during security investigations

---

## Learning Resources

**Recommended Study Path:**
1. Master the fundamental data structure concepts
2. Practice similar problems with the same pattern
3. Implement the solution from scratch without reference
4. Analyze time/space complexity of alternative approaches
5. Consider edge cases and error handling

**Interview Preparation:**
- This problem has 40.7% frequency in technical interviews
- Expected to solve in 20-45 minutes during coding interviews
- Be prepared to discuss trade-offs and alternative approaches
- Practice explaining your thought process clearly

**Common Pitfalls:**
- Off-by-one errors in array/string indexing
- Not handling edge cases (empty input, single element, etc.)
- Incorrect complexity analysis
- Over-complicating the solution

**Optimization Tips:**
- Consider early termination conditions
- Minimize unnecessary data structure operations
- Use built-in language features efficiently
- Profile for performance on large inputs

---

*Generated for educational purposes. Problem source: [LeetCode](https://leetcode.com/problems/strobogrammatic-number)*
