# 053. Robot Room Cleaner

**Difficulty:** HARD
**Frequency:** 51.9%
**Acceptance Rate:** 77.5%
**LeetCode Link:** [Robot Room Cleaner](https://leetcode.com/problems/robot-room-cleaner)

---

## Problem Description

You are controlling a robot that is located somewhere in a room. The room is modeled as an `m x n` binary grid where 0 represents a wall and 1 represents an empty slot.

The robot starts at an unknown location in the room that is guaranteed to be empty, and you do not have access to the grid, but you can move the robot using the given API `Robot`.

You are tasked to use the robot to clean the entire room (i.e., clean every empty cell in the room). The robot with the four given APIs can move forward, turn left, or turn right. Each turn is 90 degrees.

When the robot tries to move into a wall cell, its bumper sensor detects an obstacle, and it stays on the current cell.

Design an algorithm to clean the entire room using the following APIs:

```
interface Robot {
  // returns true if next cell is open and robot moves into the cell.
  // returns false if next cell is obstacle and robot stays on current cell.
  boolean move();

  // Robot will stay on the same cell after calling turnLeft/turnRight.
  void turnLeft();
  void turnRight();

  // Clean the current cell.
  void clean();
}
```

**Constraints:**
- m == room.length
- n == room[i].length
- 1 <= m <= 100
- 1 <= n <= 200
- room[i][j] is either 0 or 1
- 0 <= row < m
- 0 <= col < n
- room[row][col] == 1
- All the empty cells can be visited from the starting position

---

## Examples

### Example 1
**Input:** `room = [[1,1,1,1,1,0,1,1],[1,1,1,1,1,0,1,1],[1,0,1,1,1,1,1,1],[0,0,0,1,0,0,0,0],[1,1,1,1,1,1,1,1]], row = 1, col = 3`
**Output:** `Robot cleaned all cells`
**Explanation:** All reachable cells are cleaned

### Example 2
**Input:** `room = [[1]], row = 0, col = 0`
**Output:** `Robot cleaned cell`
**Explanation:** Single cell room

### Example 3
**Input:** `room = [[1,1,1],[1,0,1],[1,1,1]], row = 1, col = 1`
**Output:** `Cannot start (wall)`
**Explanation:** But constraints guarantee start is empty

---

## Optimal Solution

### Implementation

```python
def cleanRoom(robot):
    """
    DFS with backtracking, tracking visited cells.

    Time: O(N - M), Space: O(N - M) where N is cells, M is obstacles
    """
    # Directions: up, right, down, left
    directions = [(-1, 0), (0, 1), (1, 0), (0, -1)]
    visited = set()

    def go_back():
        robot.turnRight()
        robot.turnRight()
        robot.move()
        robot.turnRight()
        robot.turnRight()

    def backtrack(cell=(0, 0), d=0):
        visited.add(cell)
        robot.clean()

        # Try all 4 directions
        for i in range(4):
            new_d = (d + i) % 4
            new_cell = (cell[0] + directions[new_d][0],
                       cell[1] + directions[new_d][1])

            if new_cell not in visited and robot.move():
                backtrack(new_cell, new_d)
                go_back()

            # Turn robot clockwise
            robot.turnRight()

    backtrack()
```

### Complexity Analysis

**Time: O(N - M) - visit each accessible cell once. Space: O(N - M) - visited set**

**Why This is Optimal:**
- Achieves best possible asymptotic complexity for this problem class
- Minimal space overhead while maintaining code clarity
- Scales efficiently with large inputs
- Handles all edge cases correctly

---

## Categories & Tags

**Primary Topics:** Backtracking, Interactive

**Difficulty Level:** HARD

---

## Real-World Applications

Understanding this algorithmic pattern has direct real-world applications:

1. **Vacuum Robots:** Roomba/Roborock path planning algorithms
2. **Warehouse Automation:** Amazon robotics floor coverage
3. **Lawn Mowers:** Autonomous mower complete yard coverage
4. **Floor Cleaning:** Commercial cleaning robot navigation
5. **Drone Surveying:** Complete area coverage in aerial mapping
6. **Agricultural Robots:** Harvesting robots covering entire fields

**Industry Impact:**
This algorithmic pattern appears in production systems at companies like Google, Amazon, Microsoft, Meta, and Netflix. Engineers working on large-scale distributed systems, data processing pipelines, and user-facing applications regularly implement these concepts.

---

## Cybersecurity Applications

This problem demonstrates algorithmic concepts crucial for security engineering:

1. **Network Scanning:** Complete subnet enumeration without topology knowledge
2. **Web Crawling:** Security spider discovering all pages (Burp Suite, OWASP ZAP)
3. **Fuzzing:** Complete input space exploration without specification
4. **Malware Analysis:** Sandbox environment exploration by malware
5. **Penetration Testing:** Blind network discovery and mapping
6. **Asset Discovery:** Finding all network assets without prior knowledge
7. **File System Scanning:** Antivirus complete drive scanning without index

**Security Engineering Value:**
Security professionals use these algorithms in threat detection systems, security information and event management (SIEM) platforms, intrusion detection/prevention systems (IDS/IPS), and security automation tools. Understanding these patterns is essential for developing robust security solutions.

**Common Security Contexts:**
- **Threat Detection:** Pattern matching and anomaly detection in security logs
- **Performance Security:** Preventing algorithmic complexity attacks (e.g., hash collision DoS)
- **Secure Code Review:** Identifying potential vulnerabilities in algorithm implementations
- **Security Tooling:** Building efficient security scanners and analysis tools
- **Incident Response:** Fast data processing during security investigations

---

## Learning Resources

**Recommended Study Path:**
1. Master the fundamental data structure concepts
2. Practice similar problems with the same pattern
3. Implement the solution from scratch without reference
4. Analyze time/space complexity of alternative approaches
5. Consider edge cases and error handling

**Interview Preparation:**
- This problem has 51.9% frequency in technical interviews
- Expected to solve in 20-45 minutes during coding interviews
- Be prepared to discuss trade-offs and alternative approaches
- Practice explaining your thought process clearly

**Common Pitfalls:**
- Off-by-one errors in array/string indexing
- Not handling edge cases (empty input, single element, etc.)
- Incorrect complexity analysis
- Over-complicating the solution

**Optimization Tips:**
- Consider early termination conditions
- Minimize unnecessary data structure operations
- Use built-in language features efficiently
- Profile for performance on large inputs

---

*Generated for educational purposes. Problem source: [LeetCode](https://leetcode.com/problems/robot-room-cleaner)*
