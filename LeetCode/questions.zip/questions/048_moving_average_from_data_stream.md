# 048. Moving Average from Data Stream

**Difficulty:** EASY
**Frequency:** 56.0%
**Acceptance Rate:** 79.9%
**LeetCode Link:** [Moving Average from Data Stream](https://leetcode.com/problems/moving-average-from-data-stream)

---

## Problem Description

Given a stream of integers and a window size, calculate the moving average of all integers in the sliding window.

Implement the `MovingAverage` class:
- `MovingAverage(int size)` Initializes the object with the size of the window
- `double next(int val)` Returns the moving average of the last `size` values of the stream

**Constraints:**
- 1 <= size <= 1000
- -10^5 <= val <= 10^5
- At most 10^4 calls will be made to next

---

## Examples

### Example 1
**Input:**
```
["MovingAverage", "next", "next", "next", "next"]
[[3], [1], [10], [3], [5]]
```
**Output:**
```
[null, 1.0, 5.5, 4.66667, 6.0]
```
**Explanation:**
```
MovingAverage movingAverage = new MovingAverage(3);
movingAverage.next(1); // return 1.0 = 1 / 1
movingAverage.next(10); // return 5.5 = (1 + 10) / 2
movingAverage.next(3); // return 4.66667 = (1 + 10 + 3) / 3
movingAverage.next(5); // return 6.0 = (10 + 3 + 5) / 3
```

### Example 2
**Input:**
```
["MovingAverage", "next", "next"]
[[1], [5], [10]]
```
**Output:**
```
[null, 5.0, 10.0]
```
**Explanation:** Window size 1, so each next() returns the current value

### Example 3
**Input:**
```
["MovingAverage", "next", "next", "next", "next", "next"]
[[2], [1], [2], [3], [4], [5]]
```
**Output:**
```
[null, 1.0, 1.5, 2.5, 3.5, 4.5]
```
**Explanation:** Window size 2, sliding window averages

---

## Optimal Solution

### Implementation

```python
from collections import deque

class MovingAverage:
    """
    Moving average using queue and running sum.

    Time: O(1) per operation, Space: O(size)
    """

    def __init__(self, size: int):
        """Initialize with window size"""
        self.size = size
        self.queue = deque()
        self.window_sum = 0

    def next(self, val: int) -> float:
        """Add new value and return current average"""
        # Add new value
        self.queue.append(val)
        self.window_sum += val

        # Remove oldest value if window is full
        if len(self.queue) > self.size:
            self.window_sum -= self.queue.popleft()

        # Return average
        return self.window_sum / len(self.queue)
```

### Alternative Implementation Using Circular Buffer

```python
class MovingAverage:
    """
    Moving average using circular buffer (array).

    Time: O(1) per operation, Space: O(size)
    """

    def __init__(self, size: int):
        """Initialize with fixed-size circular buffer"""
        self.size = size
        self.buffer = [0] * size
        self.count = 0
        self.index = 0
        self.window_sum = 0

    def next(self, val: int) -> float:
        """Add new value and return current average"""
        # Remove old value at current index
        self.window_sum -= self.buffer[self.index]

        # Add new value
        self.buffer[self.index] = val
        self.window_sum += val

        # Move to next position (circular)
        self.index = (self.index + 1) % self.size
        self.count = min(self.count + 1, self.size)

        # Return average
        return self.window_sum / self.count
```

### Naive Implementation (For Comparison)

```python
class MovingAverage:
    """
    Naive implementation recalculating sum each time.

    Time: O(size) per operation, Space: O(size)
    """

    def __init__(self, size: int):
        self.size = size
        self.queue = []

    def next(self, val: int) -> float:
        self.queue.append(val)
        if len(self.queue) > self.size:
            self.queue.pop(0)
        return sum(self.queue) / len(self.queue)
```

### Complexity Analysis

**Time: O(1) per next() call. Space: O(size) - window storage**

**Why This is Optimal:**
- Maintaining running sum avoids recalculating on each call
- Deque provides O(1) append and popleft operations
- Space usage is bounded by window size
- Each operation is constant time regardless of window size

---

## Categories & Tags

**Primary Topics:** Array, Design, Queue, Data Stream

**Difficulty Level:** EASY

---

## Real-World Applications

Understanding this algorithmic pattern has direct real-world applications:

1. **Stock Market Analysis:** Real-time moving averages in trading platforms (Bloomberg Terminal, TradingView) for technical analysis indicators (SMA, EMA)
2. **Network Monitoring:** Calculating average bandwidth/latency in network monitoring tools (Grafana, Prometheus) for performance metrics
3. **IoT Sensor Data:** Smoothing sensor readings in IoT devices (AWS IoT, Google Cloud IoT) to filter out noise and detect trends
4. **Application Performance Monitoring:** Request rate and response time averages in APM tools (New Relic, Datadog, AppDynamics)
5. **Video Streaming:** Calculating average bitrate in adaptive streaming (HLS, DASH) for quality adjustment decisions

**Industry Impact:**
Moving averages are fundamental to time-series analysis and real-time monitoring. Every metrics platform uses sliding window aggregations to provide insights into system behavior. Understanding this pattern is essential for building responsive monitoring and alerting systems.

---

## Cybersecurity Applications

This problem demonstrates algorithmic concepts crucial for security engineering:

1. **DDoS Detection:** Tracking moving average of request rates in WAF systems (ModSecurity, Cloudflare) to detect traffic spikes
2. **Anomaly Detection:** Calculating baseline metrics in SIEM tools (Splunk, ELK) to identify deviations indicating attacks
3. **Brute Force Detection:** Monitoring login attempt rates in authentication systems (Okta, Auth0) to detect credential stuffing
4. **Network Traffic Analysis:** IDS/IPS systems (Snort, Suricata) using moving averages to detect bandwidth anomalies
5. **API Rate Limiting:** Tracking request rates per user/IP in API gateways (Kong, Apigee) for abuse prevention
6. **Security Metrics:** Calculating rolling averages of security events for trend analysis in SOC dashboards

**Security Engineering Value:**
Moving averages enable real-time threat detection by establishing normal behavior baselines. Security tools use sliding windows to detect sudden changes in metrics that may indicate attacks, while filtering out normal fluctuations. This is critical for reducing false positives in security alerting.

**Common Security Contexts:**
- **Threat Detection:** Pattern matching and anomaly detection in security logs
- **Performance Security:** Preventing algorithmic complexity attacks (e.g., hash collision DoS)
- **Secure Code Review:** Identifying potential vulnerabilities in algorithm implementations
- **Security Tooling:** Building efficient security scanners and analysis tools
- **Incident Response:** Fast data processing during security investigations

---

## Learning Resources

**Recommended Study Path:**
1. Master queue/deque data structure operations
2. Practice similar problems: Design Hit Counter, Time Based Key-Value Store
3. Implement the solution from scratch without reference
4. Understand trade-offs between different implementations
5. Consider edge cases: window size 1, empty window, negative numbers

**Interview Preparation:**
- This problem has 56.0% frequency in technical interviews
- Expected to solve in 15-20 minutes during coding interviews
- Be prepared to discuss why running sum is better than recalculating
- Practice explaining trade-offs between deque and circular buffer

**Common Pitfalls:**
- Recalculating sum on every call (O(size) instead of O(1))
- Not handling window not yet full correctly
- Memory leaks in languages with manual memory management
- Integer overflow with running sum in some languages

**Optimization Tips:**
- Use deque for clean, readable code
- Circular buffer saves memory allocation overhead
- Running sum is key to O(1) performance
- Test with edge cases: size 1, many calls, negative values

---

*Generated for educational purposes. Problem source: [LeetCode](https://leetcode.com/problems/moving-average-from-data-stream)*
