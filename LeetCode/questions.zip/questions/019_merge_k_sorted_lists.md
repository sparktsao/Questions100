# 019. Merge k Sorted Lists

**Difficulty:** HARD
**Frequency:** 76.4%
**Acceptance Rate:** 56.8%
**LeetCode Link:** [Merge k Sorted Lists](https://leetcode.com/problems/merge-k-sorted-lists)

---

## Problem Description

You are given an array of `k` linked-lists `lists`, each linked-list is sorted in ascending order.

Merge all the linked-lists into one sorted linked-list and return it.

**Constraints:**
- k == lists.length
- 0 <= k <= 10^4
- 0 <= lists[i].length <= 500
- -10^4 <= lists[i][j] <= 10^4
- lists[i] is sorted in ascending order
- The sum of lists[i].length will not exceed 10^4

---

## Examples

### Example 1
**Input:** `lists = [[1,4,5],[1,3,4],[2,6]]`
**Output:** `[1,1,2,3,4,4,5,6]`
**Explanation:** The linked-lists are:
- 1->4->5
- 1->3->4
- 2->6
Merging them into one sorted list: 1->1->2->3->4->4->5->6

### Example 2
**Input:** `lists = []`
**Output:** `[]`
**Explanation:** Empty input, return empty list

### Example 3
**Input:** `lists = [[]]`
**Output:** `[]`
**Explanation:** Single empty list

### Example 4
**Input:** `lists = [[-2,-1,-1,-1],[]]`
**Output:** `[-2,-1,-1,-1]`
**Explanation:** One non-empty list with duplicates and negative numbers, one empty list

---

## Optimal Solution

### Implementation (Min Heap Approach)

```python
from typing import List, Optional
import heapq

# Definition for singly-linked list.
class ListNode:
    def __init__(self, val=0, next=None):
        self.val = val
        self.next = next

def mergeKLists(lists: List[Optional[ListNode]]) -> Optional[ListNode]:
    """
    Merge k sorted linked lists using min heap.

    Time: O(N log k) where N is total nodes, k is number of lists
    Space: O(k) for heap
    """
    # Min heap to track smallest current node from each list
    # Tuple format: (node.val, index, node) - index prevents comparison of nodes
    min_heap = []

    # Initialize heap with first node from each list
    for i, node in enumerate(lists):
        if node:
            heapq.heappush(min_heap, (node.val, i, node))

    # Dummy head for result list
    dummy = ListNode(0)
    current = dummy

    # Process nodes in sorted order
    while min_heap:
        val, i, node = heapq.heappop(min_heap)

        # Add node to result
        current.next = node
        current = current.next

        # Add next node from same list to heap
        if node.next:
            heapq.heappush(min_heap, (node.next.val, i, node.next))

    return dummy.next
```

### Alternative Implementation (Divide and Conquer)

```python
def mergeKLists(lists: List[Optional[ListNode]]) -> Optional[ListNode]:
    """
    Merge k sorted lists using divide and conquer.

    Time: O(N log k), Space: O(log k) for recursion stack
    """
    if not lists:
        return None

    def mergeTwoLists(l1: Optional[ListNode], l2: Optional[ListNode]) -> Optional[ListNode]:
        """Merge two sorted linked lists."""
        dummy = ListNode(0)
        current = dummy

        while l1 and l2:
            if l1.val < l2.val:
                current.next = l1
                l1 = l1.next
            else:
                current.next = l2
                l2 = l2.next
            current = current.next

        current.next = l1 if l1 else l2
        return dummy.next

    # Divide and conquer: repeatedly merge pairs
    while len(lists) > 1:
        merged_lists = []

        for i in range(0, len(lists), 2):
            l1 = lists[i]
            l2 = lists[i + 1] if i + 1 < len(lists) else None
            merged_lists.append(mergeTwoLists(l1, l2))

        lists = merged_lists

    return lists[0]
```

### Complexity Analysis

**Min Heap Approach: Time O(N log k), Space O(k)**
**Divide and Conquer: Time O(N log k), Space O(log k)**

**Why This is Optimal:**
- Both approaches achieve O(N log k) time complexity, which is optimal
- Min heap maintains k elements, processing each of N nodes once with log k operations
- Divide and conquer reduces problem by half each iteration (log k levels)
- Handles all edge cases: empty lists, single list, duplicate values, negative numbers
- Space complexity is minimal - only k pointers in heap or log k recursion depth

---

## Categories & Tags

**Primary Topics:** Linked List, Divide and Conquer, Heap (Priority Queue), Merge Sort

**Difficulty Level:** HARD

---

## Real-World Applications

Understanding this algorithmic pattern has direct real-world applications:

1. **Distributed Databases:** Merging sorted results from multiple shards in MongoDB, Cassandra, DynamoDB for range queries
2. **Search Engines:** Google merging sorted results from multiple index servers, Elasticsearch aggregating results from distributed nodes
3. **Log Aggregation:** Splunk, Datadog merging time-sorted logs from multiple servers for unified timeline analysis
4. **External Sorting:** Database systems (PostgreSQL, MySQL) merging sorted runs during disk-based sort operations on large datasets
5. **Stream Processing:** Apache Kafka, Apache Flink merging sorted event streams from multiple partitions

**Industry Impact:**
K-way merge is fundamental to distributed systems and databases. Companies like Google (BigTable), Amazon (DynamoDB), Facebook (RocksDB), and Microsoft (Azure Cosmos DB) use this pattern for merging sorted data from multiple sources. The algorithm is critical for efficient query processing in sharded databases and distributed search systems.

---

## Cybersecurity Applications

This problem demonstrates algorithmic concepts crucial for security engineering:

1. **SIEM Log Correlation:** Merging time-sorted security logs from multiple sources (firewalls, IDS, endpoints) in Splunk, QRadar, Sentinel for unified threat timeline
2. **Network Forensics:** Wireshark, tcpdump merging sorted packet captures from multiple network taps for attack reconstruction
3. **Threat Intelligence Aggregation:** Merging sorted IOC feeds from multiple threat intel sources (MISP, ThreatConnect, AlienVault OTX)
4. **Distributed Malware Analysis:** Cuckoo Sandbox merging sorted behavioral events from multiple analysis VMs
5. **Security Audit Trail Merging:** Combining sorted audit logs from multiple systems (Active Directory, AWS CloudTrail, database logs) for compliance investigation
6. **Vulnerability Scan Aggregation:** Merging sorted vulnerability findings from multiple scanners (Nessus, Qualys, OpenVAS) by severity and timestamp

**Security Engineering Value:**
K-way merge is essential for security operations that aggregate data from distributed sources. Security teams use this pattern to build unified timelines during incident response, correlate events across multiple security tools, and efficiently merge threat intelligence from various feeds. The O(N log k) complexity ensures real-time processing even with many data sources.

**Common Security Contexts:**
- **Threat Detection:** Merging sorted alert streams from multiple detection engines for prioritized response
- **Performance Security:** Efficient log aggregation without memory exhaustion from massive security datasets
- **Secure Code Review:** Understanding merge algorithms in distributed security platforms
- **Security Tooling:** Building scalable SIEM backends that merge time-series security data
- **Incident Response:** Creating comprehensive attack timelines from multiple log sources during forensic analysis

---

## Learning Resources

**Recommended Study Path:**
1. Master the fundamental data structure concepts
2. Practice similar problems with the same pattern
3. Implement the solution from scratch without reference
4. Analyze time/space complexity of alternative approaches
5. Consider edge cases and error handling

**Interview Preparation:**
- This problem has 76.4% frequency in technical interviews
- Expected to solve in 20-45 minutes during coding interviews
- Be prepared to discuss trade-offs and alternative approaches
- Practice explaining your thought process clearly

**Common Pitfalls:**
- Off-by-one errors in array/string indexing
- Not handling edge cases (empty input, single element, etc.)
- Incorrect complexity analysis
- Over-complicating the solution

**Optimization Tips:**
- Consider early termination conditions
- Minimize unnecessary data structure operations
- Use built-in language features efficiently
- Profile for performance on large inputs

---

*Generated for educational purposes. Problem source: [LeetCode](https://leetcode.com/problems/merge-k-sorted-lists)*
