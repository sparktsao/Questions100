# 062. Group Shifted Strings

**Difficulty:** MEDIUM
**Frequency:** 47.0%
**Acceptance Rate:** 67.4%
**LeetCode Link:** [Group Shifted Strings](https://leetcode.com/problems/group-shifted-strings)

---

## Problem Description

We can shift a string by shifting each of its letters to its successive letter.

- For example, "abc" can be shifted to be "bcd".

We can keep shifting the string to form a sequence.

- For example, we can keep shifting "abc" to form the sequence: "abc" -> "bcd" -> ... -> "xyz".

Given an array of strings `strings`, group all `strings[i]` that belong to the same shifting sequence. You may return the answer in any order.

**Constraints:**
- 1 <= strings.length <= 200
- 1 <= strings[i].length <= 50
- strings[i] consists of lowercase English letters

---

## Examples

### Example 1
**Input:** `strings = ["abc","bcd","acef","xyz","az","ba","a","z"]`
**Output:** `[["acef"],["a","z"],["abc","bcd","xyz"],["az","ba"]]`
**Explanation:**
- "abc", "bcd", "xyz" have the same shift pattern (each consecutive letter differs by 1)
- "az" and "ba" have the same shift pattern
- "acef" is unique
- "a" and "z" are single characters grouped together

### Example 2
**Input:** `strings = ["a"]`
**Output:** `[["a"]]`
**Explanation:** Single string forms its own group

### Example 3
**Input:** `strings = ["abc","bcd","xyz"]`
**Output:** `[["abc","bcd","xyz"]]`
**Explanation:** All three strings have identical shift patterns (differences of [1,1])

### Example 4
**Input:** `strings = ["az","ba","aa"]`
**Output:** `[["aa"],["az","ba"]]`
**Explanation:** "az" shifts to "ba" (z->a, wraps around), but "aa" has zero differences

---

## Optimal Solution

### Implementation

```python
def groupStrings(strings: List[str]) -> List[List[str]]:
    """
    Group strings by their shift pattern using hash table.

    Time: O(n * k), Space: O(n * k) where n = number of strings, k = avg string length
    """
    from collections import defaultdict

    def get_pattern(s):
        """
        Calculate the shift pattern as tuple of differences.
        For "abc": (1, 1) since b-a=1, c-b=1
        """
        if len(s) == 1:
            return (0,)

        pattern = []
        for i in range(len(s) - 1):
            # Calculate difference, handle wrap-around (a comes after z)
            diff = (ord(s[i + 1]) - ord(s[i])) % 26
            pattern.append(diff)

        return tuple(pattern)

    groups = defaultdict(list)

    for string in strings:
        pattern = get_pattern(string)
        groups[pattern].append(string)

    return list(groups.values())
```

### Alternative Implementation (Normalize to 'a')

```python
def groupStrings(strings: List[str]) -> List[List[str]]:
    """
    Alternative approach: normalize each string to start with 'a'.

    Time: O(n * k), Space: O(n * k)
    """
    from collections import defaultdict

    def normalize(s):
        """Shift string so it starts with 'a'"""
        if not s:
            return ""

        shift = ord(s[0]) - ord('a')
        normalized = []

        for char in s:
            # Shift each character back by the same amount
            new_char = chr((ord(char) - shift) % 26 + ord('a'))
            normalized.append(new_char)

        return ''.join(normalized)

    groups = defaultdict(list)

    for string in strings:
        key = normalize(string)
        groups[key].append(string)

    return list(groups.values())
```

### Complexity Analysis

**Time: O(n * k) - where n is number of strings and k is average string length. Space: O(n * k) - storing all strings in hash map**

**Why This is Optimal:**
- Single pass through all strings with O(k) work per string
- Hash table provides O(1) average lookup and insertion
- The shift pattern calculation is necessary to determine grouping
- Cannot do better than O(n * k) since we must examine every character
- Handles wrap-around correctly with modulo arithmetic

---

## Categories & Tags

**Primary Topics:** Array, Hash Table, String

**Difficulty Level:** MEDIUM

---

## Real-World Applications

Understanding this algorithmic pattern has direct real-world applications:

1. **Cryptography:** Caesar cipher decryption and pattern detection in security tools like CrypTool
2. **Text Analysis:** Plagiarism detection in Turnitin identifying shifted text patterns
3. **Genomics:** DNA sequence alignment in BLAST for identifying shifted genetic patterns
4. **Password Analysis:** Security audits detecting password variations (password1, password2) in breach databases
5. **Music Theory:** Transposition detection in music software like MuseScore or Finale

**Industry Impact:**
Pattern matching algorithms are fundamental in bioinformatics, cryptanalysis, and natural language processing. Companies like 23andMe use similar algorithms for genetic analysis, while security firms employ these techniques for password strength analysis and breach detection.

---

## Cybersecurity Applications

This problem demonstrates algorithmic concepts crucial for security engineering:

1. **Cipher Analysis:** Breaking substitution ciphers in tools like CyberChef, identifying Caesar cipher variants
2. **Password Pattern Detection:** Identifying weak password patterns in HashCat wordlist generation
3. **Malware Variants:** Grouping obfuscated malware samples with shifted string constants in YARA rules
4. **Data Deduplication:** SIEM systems like Splunk grouping similar log patterns with shifted timestamps
5. **API Key Rotation:** Detecting rotated credentials in secret scanning tools (GitGuardian, TruffleHog)
6. **Anomaly Detection:** Identifying similar attack patterns with shifted parameters in IDS/IPS systems

**Security Engineering Value:**
Understanding string transformation patterns is essential for security professionals analyzing obfuscated code, detecting pattern-based attacks, and building robust detection rules. These algorithms power tools used in malware analysis, threat intelligence, and security automation.

**Common Security Contexts:**
- **Threat Detection:** Pattern matching and anomaly detection in security logs
- **Performance Security:** Preventing algorithmic complexity attacks (e.g., hash collision DoS)
- **Secure Code Review:** Identifying potential vulnerabilities in algorithm implementations
- **Security Tooling:** Building efficient security scanners and analysis tools
- **Incident Response:** Fast data processing during security investigations

---

## Learning Resources

**Recommended Study Path:**
1. Master the fundamental data structure concepts
2. Practice similar problems with the same pattern
3. Implement the solution from scratch without reference
4. Analyze time/space complexity of alternative approaches
5. Consider edge cases and error handling

**Interview Preparation:**
- This problem has 47.0% frequency in technical interviews
- Expected to solve in 20-45 minutes during coding interviews
- Be prepared to discuss trade-offs and alternative approaches
- Practice explaining your thought process clearly

**Common Pitfalls:**
- Off-by-one errors in array/string indexing
- Not handling edge cases (empty input, single element, etc.)
- Incorrect complexity analysis
- Over-complicating the solution
- Forgetting to handle wrap-around (z -> a)
- Using wrong hash key causing incorrect groupings

**Optimization Tips:**
- Consider early termination conditions
- Minimize unnecessary data structure operations
- Use built-in language features efficiently
- Profile for performance on large inputs
- Choose hash key representation carefully (tuple vs string)

---

*Generated for educational purposes. Problem source: [LeetCode](https://leetcode.com/problems/group-shifted-strings)*
