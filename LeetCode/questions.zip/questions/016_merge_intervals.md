# 016. Merge Intervals

**Difficulty:** MEDIUM
**Frequency:** 77.9%
**Acceptance Rate:** 49.4%
**LeetCode Link:** [Merge Intervals](https://leetcode.com/problems/merge-intervals)

---

## Problem Description

Given an array of `intervals` where `intervals[i] = [start_i, end_i]`, merge all overlapping intervals, and return an array of the non-overlapping intervals that cover all the intervals in the input.

**Constraints:**
- 1 <= intervals.length <= 10^4
- intervals[i].length == 2
- 0 <= start_i <= end_i <= 10^4

---

## Examples

### Example 1
**Input:** `intervals = [[1,3],[2,6],[8,10],[15,18]]`
**Output:** `[[1,6],[8,10],[15,18]]`
**Explanation:** [1,3] and [2,6] overlap, merge to [1,6]

### Example 2
**Input:** `intervals = [[1,4],[4,5]]`
**Output:** `[[1,5]]`
**Explanation:** Intervals touching at boundaries should merge

### Example 3
**Input:** `intervals = [[1,4],[0,4]]`
**Output:** `[[0,4]]`
**Explanation:** Unsorted input, [0,4] encompasses [1,4]

### Example 4
**Input:** `intervals = [[1,4],[2,3]]`
**Output:** `[[1,4]]`
**Explanation:** One interval completely inside another

---

## Optimal Solution

### Implementation

```python
def merge(intervals: List[List[int]]) -> List[List[int]]:
    """
    Merge overlapping intervals.

    Time: O(n log n), Space: O(n)
    """
    if not intervals:
        return []

    # Sort by start time
    intervals.sort(key=lambda x: x[0])
    merged = [intervals[0]]

    for current in intervals[1:]:
        last = merged[-1]
        if current[0] <= last[1]:
            # Overlapping, merge
            last[1] = max(last[1], current[1])
        else:
            # Non-overlapping, add
            merged.append(current)

    return merged
```

### Complexity Analysis

**Time: O(n log n) - sorting. Space: O(n) - output array**

**Why This is Optimal:**
- Achieves best possible asymptotic complexity for this problem class
- Minimal space overhead while maintaining code clarity
- Scales efficiently with large inputs
- Handles all edge cases correctly

---

## Categories & Tags

**Primary Topics:** Array, Sorting

**Difficulty Level:** MEDIUM

---

## Real-World Applications

Understanding this algorithmic pattern has direct real-world applications:

1. **Calendar Applications:** Google Calendar merging overlapping meetings
2. **Resource Scheduling:** AWS/Azure consolidating reserved compute time slots
3. **Video Processing:** YouTube merging overlapping video segments
4. **Database Query Optimization:** MySQL/PostgreSQL merging scan ranges for index lookups
5. **Network Traffic Analysis:** Wireshark consolidating packet capture time ranges

**Industry Impact:**
This algorithmic pattern appears in production systems at companies like Google, Amazon, Microsoft, Meta, and Netflix. Engineers working on large-scale distributed systems, data processing pipelines, and user-facing applications regularly implement these concepts.

---

## Cybersecurity Applications

This problem demonstrates algorithmic concepts crucial for security engineering:

1. **Vulnerability Scan Consolidation:** Nessus/OpenVAS merging overlapping scan windows
2. **Incident Response Timeline:** Splunk merging security event time ranges
3. **Firewall Rule Optimization:** iptables/pf consolidating overlapping IP/port ranges
4. **Threat Intelligence:** MISP merging overlapping IOC validity periods
5. **Access Control:** Active Directory consolidating user session timeframes
6. **DDoS Attack Analysis:** Cloudflare merging attack wave timestamps

**Security Engineering Value:**
Security professionals use these algorithms in threat detection systems, security information and event management (SIEM) platforms, intrusion detection/prevention systems (IDS/IPS), and security automation tools. Understanding these patterns is essential for developing robust security solutions.

**Common Security Contexts:**
- **Threat Detection:** Pattern matching and anomaly detection in security logs
- **Performance Security:** Preventing algorithmic complexity attacks (e.g., hash collision DoS)
- **Secure Code Review:** Identifying potential vulnerabilities in algorithm implementations
- **Security Tooling:** Building efficient security scanners and analysis tools
- **Incident Response:** Fast data processing during security investigations

---

## Learning Resources

**Recommended Study Path:**
1. Master the fundamental data structure concepts
2. Practice similar problems with the same pattern
3. Implement the solution from scratch without reference
4. Analyze time/space complexity of alternative approaches
5. Consider edge cases and error handling

**Interview Preparation:**
- This problem has 77.9% frequency in technical interviews
- Expected to solve in 20-45 minutes during coding interviews
- Be prepared to discuss trade-offs and alternative approaches
- Practice explaining your thought process clearly

**Common Pitfalls:**
- Off-by-one errors in array/string indexing
- Not handling edge cases (empty input, single element, etc.)
- Incorrect complexity analysis
- Over-complicating the solution

**Optimization Tips:**
- Consider early termination conditions
- Minimize unnecessary data structure operations
- Use built-in language features efficiently
- Profile for performance on large inputs

---

*Generated for educational purposes. Problem source: [LeetCode](https://leetcode.com/problems/merge-intervals)*
