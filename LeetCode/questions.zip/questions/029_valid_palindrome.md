# 029. Valid Palindrome

**Difficulty:** EASY
**Frequency:** 69.5%
**Acceptance Rate:** 51.0%
**LeetCode Link:** [Valid Palindrome](https://leetcode.com/problems/valid-palindrome)

---

## Problem Description

A phrase is a palindrome if, after converting all uppercase letters into lowercase letters and removing all non-alphanumeric characters, it reads the same forward and backward. Alphanumeric characters include letters and numbers.

Given a string `s`, return `true` if it is a palindrome, or `false` otherwise.

**Constraints:**
- 1 <= s.length <= 2 * 10^5
- s consists only of printable ASCII characters

---

## Examples

### Example 1
**Input:** `s = "A man, a plan, a canal: Panama"`
**Output:** `true`
**Explanation:** After cleaning: "amanaplanacanalpanama" is palindrome

### Example 2
**Input:** `s = "race a car"`
**Output:** `false`
**Explanation:** After cleaning: "raceacar" is not palindrome

### Example 3
**Input:** `s = " "`
**Output:** `true`
**Explanation:** Empty string after cleaning is palindrome

### Example 4
**Input:** `s = "0P"`
**Output:** `false`
**Explanation:** 0p is not palindrome

---

## Optimal Solution

### Implementation

```python
def isPalindrome(s: str) -> bool:
    """
    Two pointers with in-place character validation.

    Time: O(n), Space: O(1)
    """
    left, right = 0, len(s) - 1

    while left < right:
        # Skip non-alphanumeric from left
        while left < right and not s[left].isalnum():
            left += 1

        # Skip non-alphanumeric from right
        while left < right and not s[right].isalnum():
            right -= 1

        # Compare characters (case-insensitive)
        if s[left].lower() != s[right].lower():
            return False

        left += 1
        right -= 1

    return True
```

### Complexity Analysis

**Time: O(n) - single pass. Space: O(1) - constant**

**Why This is Optimal:**
- Achieves best possible asymptotic complexity for this problem class
- Minimal space overhead while maintaining code clarity
- Scales efficiently with large inputs
- Handles all edge cases correctly

---

## Categories & Tags

**Primary Topics:** Two Pointers, String

**Difficulty Level:** EASY

---

## Real-World Applications

Understanding this algorithmic pattern has direct real-world applications:

1. **Data Validation:** Input validation in web forms (phone numbers, IDs)
2. **DNA Analysis:** Palindromic sequences in BLAST genomic analysis
3. **Text Processing:** Document analysis for linguistic patterns
4. **Data Deduplication:** Finding symmetric patterns in data cleanup
5. **String Matching:** Search algorithms with bidirectional validation
6. **Spell Checkers:** Grammarly detecting word patterns

**Industry Impact:**
This algorithmic pattern appears in production systems at companies like Google, Amazon, Microsoft, Meta, and Netflix. Engineers working on large-scale distributed systems, data processing pipelines, and user-facing applications regularly implement these concepts.

---

## Cybersecurity Applications

This problem demonstrates algorithmic concepts crucial for security engineering:

1. **Input Sanitization:** WAF validating palindromic patterns in SQL injection attempts
2. **Malware Detection:** Finding palindromic shellcode patterns (polymorphic malware)
3. **Protocol Analysis:** Detecting symmetric packet patterns in network traffic
4. **Password Policy:** Rejecting weak palindromic passwords
5. **Log Analysis:** Finding symmetric patterns indicating automated attacks
6. **Cryptanalysis:** Detecting patterns in encrypted data
7. **Obfuscation Detection:** Identifying palindromic obfuscation techniques

**Security Engineering Value:**
Security professionals use these algorithms in threat detection systems, security information and event management (SIEM) platforms, intrusion detection/prevention systems (IDS/IPS), and security automation tools. Understanding these patterns is essential for developing robust security solutions.

**Common Security Contexts:**
- **Threat Detection:** Pattern matching and anomaly detection in security logs
- **Performance Security:** Preventing algorithmic complexity attacks (e.g., hash collision DoS)
- **Secure Code Review:** Identifying potential vulnerabilities in algorithm implementations
- **Security Tooling:** Building efficient security scanners and analysis tools
- **Incident Response:** Fast data processing during security investigations

---

## Learning Resources

**Recommended Study Path:**
1. Master the fundamental data structure concepts
2. Practice similar problems with the same pattern
3. Implement the solution from scratch without reference
4. Analyze time/space complexity of alternative approaches
5. Consider edge cases and error handling

**Interview Preparation:**
- This problem has 69.5% frequency in technical interviews
- Expected to solve in 20-45 minutes during coding interviews
- Be prepared to discuss trade-offs and alternative approaches
- Practice explaining your thought process clearly

**Common Pitfalls:**
- Off-by-one errors in array/string indexing
- Not handling edge cases (empty input, single element, etc.)
- Incorrect complexity analysis
- Over-complicating the solution

**Optimization Tips:**
- Consider early termination conditions
- Minimize unnecessary data structure operations
- Use built-in language features efficiently
- Profile for performance on large inputs

---

*Generated for educational purposes. Problem source: [LeetCode](https://leetcode.com/problems/valid-palindrome)*
