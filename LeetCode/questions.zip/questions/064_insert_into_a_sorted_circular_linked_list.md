# 064. Insert into a Sorted Circular Linked List

**Difficulty:** MEDIUM
**Frequency:** 47.0%
**Acceptance Rate:** 38.1%
**LeetCode Link:** [Insert into a Sorted Circular Linked List](https://leetcode.com/problems/insert-into-a-sorted-circular-linked-list)

---

## Problem Description

Given a Circular Linked List node, which is sorted in non-descending order, write a function to insert a value `insertVal` into the list such that it remains a sorted circular list. The given node can be a reference to any single node in the list and may not necessarily be the smallest value in the circular list.

If there are multiple suitable places for insertion, you may choose any place to insert the new value. After the insertion, the circular list should remain sorted.

If the list is empty (i.e., the given node is `null`), you should create a new single circular list and return the reference to that single node. Otherwise, you should return the originally given node.

**Constraints:**
- The number of nodes in the list is in the range [0, 5 * 10^4]
- -10^6 <= Node.val <= insertVal <= 10^6

---

## Examples

### Example 1
**Input:** `head = [3,4,1], insertVal = 2`
**Output:** `[3,4,1,2]`
**Explanation:** In the figure below, there is a sorted circular list of three elements. You are given a reference to the node with value 3, and we need to insert 2 into the list. The new node should be inserted between node 1 and node 3. After the insertion, the list should still be sorted.

### Example 2
**Input:** `head = [], insertVal = 1`
**Output:** `[1]`
**Explanation:** The list is empty (given head is null). We create a new single circular list and return the reference to that single node.

### Example 3
**Input:** `head = [1], insertVal = 0`
**Output:** `[1,0]`
**Explanation:** The list has one node. The new node should be inserted between the only node and itself to form a circular list.

### Example 4
**Input:** `head = [3,3,3], insertVal = 3`
**Output:** `[3,3,3,3]`
**Explanation:** When all values are the same, insert at any position maintains sorted order.

---

## Optimal Solution

### Implementation

```python
class Node:
    def __init__(self, val=None, next=None):
        self.val = val
        self.next = next

def insert(head: 'Node', insertVal: int) -> 'Node':
    """
    Insert value into sorted circular linked list.

    Time: O(n), Space: O(1)
    """
    new_node = Node(insertVal)

    # Case 1: Empty list
    if not head:
        new_node.next = new_node
        return new_node

    # Case 2: Single node or need to traverse
    prev, curr = head, head.next

    # Traverse to find insertion point
    while True:
        # Case 2a: Insert between prev and curr (normal case)
        if prev.val <= insertVal <= curr.val:
            break

        # Case 2b: Insert at the boundary (largest to smallest transition)
        # This handles: insertVal >= max OR insertVal <= min
        if prev.val > curr.val:
            # We're at the wrap-around point
            if insertVal >= prev.val or insertVal <= curr.val:
                break

        prev = curr
        curr = curr.next

        # Case 2c: Completed full circle (all values are same or insertVal fits anywhere)
        if prev == head:
            break

    # Insert new_node between prev and curr
    prev.next = new_node
    new_node.next = curr

    return head
```

### Alternative Implementation (More Explicit)

```python
def insert(head: 'Node', insertVal: int) -> 'Node':
    """
    Alternative implementation with explicit condition checking.

    Time: O(n), Space: O(1)
    """
    new_node = Node(insertVal)

    # Empty list
    if not head:
        new_node.next = new_node
        return new_node

    # Find insertion point
    prev = head
    curr = head.next

    insert_done = False

    while True:
        # Normal insertion: prev <= insertVal <= curr
        if prev.val <= insertVal <= curr.val:
            insert_done = True

        # Boundary case: we're at max->min transition
        elif prev.val > curr.val:
            # Insert if value is >= max or <= min
            if insertVal >= prev.val or insertVal <= curr.val:
                insert_done = True

        if insert_done:
            prev.next = new_node
            new_node.next = curr
            return head

        prev = curr
        curr = curr.next

        # Completed full circle - all values same
        if prev == head:
            break

    # Insert anywhere (all values are equal)
    prev.next = new_node
    new_node.next = curr

    return head
```

### Complexity Analysis

**Time: O(n) - worst case traverse entire circular list. Space: O(1) - only create one new node**

**Why This is Optimal:**
- Must potentially visit all nodes to find correct insertion point
- O(1) space since we only allocate the new node
- No additional data structures needed
- Handles all edge cases: empty list, single node, all same values, boundary conditions
- In-place insertion maintains circular structure

---

## Categories & Tags

**Primary Topics:** Linked List

**Difficulty Level:** MEDIUM

---

## Real-World Applications

Understanding this algorithmic pattern has direct real-world applications:

1. **Operating Systems:** Round-robin process scheduling in Linux kernel, maintaining sorted ready queue
2. **Music Players:** Circular playlist management in Spotify, maintaining sorted favorite queue
3. **Network Routing:** Token ring networks, maintaining sorted priority packet queues
4. **Gaming:** Turn-based game systems, inserting players into sorted initiative order
5. **Task Scheduling:** Circular buffer implementations in real-time systems (RTOS)

**Industry Impact:**
Circular linked lists are fundamental in systems programming, embedded systems, and real-time applications. They appear in operating system kernels, network protocols, and multimedia applications where cyclic data structures provide efficient round-robin access patterns.

---

## Cybersecurity Applications

This problem demonstrates algorithmic concepts crucial for security engineering:

1. **IDS/IPS Systems:** Circular buffer for packet inspection in Snort/Suricata, maintaining sorted priority alerts
2. **Log Rotation:** Circular log buffers in syslog-ng, maintaining chronologically sorted events
3. **Rate Limiting:** Token bucket algorithms in API gateways (Kong, Nginx), sorted request queues
4. **Session Management:** Circular session cache in authentication systems, sorted by expiry time
5. **Firewall Rules:** Priority-based rule insertion in iptables/nftables circular chains
6. **Security Monitoring:** Circular event buffers in SIEM systems, maintaining sorted threat scores

**Security Engineering Value:**
Circular linked lists are used in security systems for efficient memory management, event logging, and priority-based processing. Understanding these structures is crucial for building performant security tools that handle high-throughput data streams while maintaining sorted priority queues.

**Common Security Contexts:**
- **Threat Detection:** Pattern matching and anomaly detection in security logs
- **Performance Security:** Preventing algorithmic complexity attacks (e.g., hash collision DoS)
- **Secure Code Review:** Identifying potential vulnerabilities in algorithm implementations
- **Security Tooling:** Building efficient security scanners and analysis tools
- **Incident Response:** Fast data processing during security investigations

---

## Learning Resources

**Recommended Study Path:**
1. Master the fundamental data structure concepts
2. Practice similar problems with the same pattern
3. Implement the solution from scratch without reference
4. Analyze time/space complexity of alternative approaches
5. Consider edge cases and error handling

**Interview Preparation:**
- This problem has 47.0% frequency in technical interviews
- Expected to solve in 20-45 minutes during coding interviews
- Be prepared to discuss trade-offs and alternative approaches
- Practice explaining your thought process clearly

**Common Pitfalls:**
- Off-by-one errors in array/string indexing
- Not handling edge cases (empty input, single element, etc.)
- Incorrect complexity analysis
- Over-complicating the solution
- Infinite loop when all values are identical
- Not maintaining circular structure after insertion
- Missing the boundary case (max to min transition)

**Optimization Tips:**
- Consider early termination conditions
- Minimize unnecessary data structure operations
- Use built-in language features efficiently
- Profile for performance on large inputs
- Handle edge cases first before main logic
- Test with all same values to catch infinite loops

---

*Generated for educational purposes. Problem source: [LeetCode](https://leetcode.com/problems/insert-into-a-sorted-circular-linked-list)*
