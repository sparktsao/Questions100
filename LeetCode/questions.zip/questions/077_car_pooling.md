# 077. Car Pooling

**Difficulty:** MEDIUM
**Frequency:** 40.7%
**Acceptance Rate:** 56.0%
**LeetCode Link:** [Car Pooling](https://leetcode.com/problems/car-pooling)

---

## Problem Description

There is a car with `capacity` empty seats. The vehicle only drives east (i.e., it cannot turn around and drive west).

You are given the integer `capacity` and an array `trips` where `trips[i] = [numPassengers_i, from_i, to_i]` indicates that the `i-th` trip has `numPassengers_i` passengers and the locations to pick them up and drop them off are `from_i` and `to_i` respectively. The locations are given as the number of kilometers due east from the car's initial location.

Return `true` if it is possible to pick up and drop off all passengers for all the given trips, or `false` otherwise.

**Constraints:**
- `1 <= trips.length <= 1000`
- `trips[i].length == 3`
- `1 <= numPassengers_i <= 100`
- `0 <= from_i < to_i <= 1000`
- `1 <= capacity <= 10^5`

---

## Examples

### Example 1
**Input:** `trips = [[2,1,5],[3,3,7]], capacity = 4`
**Output:** `false`
**Explanation:** At location 3, we have 2+3=5 passengers, which exceeds capacity of 4.

### Example 2
**Input:** `trips = [[2,1,5],[3,3,7]], capacity = 5`
**Output:** `true`
**Explanation:** At location 3, we have 5 passengers (exactly at capacity). At location 5, 2 passengers drop off, leaving 3 passengers until location 7.

### Example 3
**Input:** `trips = [[2,1,5],[3,5,7]], capacity = 3`
**Output:** `true`
**Explanation:** At location 1, pick up 2 passengers. At location 5, drop off 2 and pick up 3 (current = 3). At location 7, drop off 3.

### Example 4
**Input:** `trips = [[3,2,7],[3,7,9],[8,3,9]], capacity = 11`
**Output:** `true`
**Explanation:** Maximum concurrent passengers is 11 (at location 3-7 and location 7-9).

---

## Optimal Solution

### Implementation (Difference Array Approach)

```python
def carPooling(trips: List[List[int]], capacity: int) -> bool:
    """
    Difference array approach to track passenger changes.

    Time: O(n + m), Space: O(m)
    where n is number of trips, m is max location (1000)
    """
    # Track passenger changes at each location
    passenger_changes = [0] * 1001

    for num_passengers, start, end in trips:
        passenger_changes[start] += num_passengers
        passenger_changes[end] -= num_passengers

    # Check if capacity is ever exceeded
    current_passengers = 0
    for change in passenger_changes:
        current_passengers += change
        if current_passengers > capacity:
            return False

    return True
```

### Alternative Implementation (Sorting Approach)

```python
def carPooling(trips: List[List[int]], capacity: int) -> bool:
    """
    Sorting approach tracking pickup/dropoff events.

    Time: O(n log n), Space: O(n)
    """
    events = []

    # Create events for each pickup and dropoff
    for num_passengers, start, end in trips:
        events.append((start, num_passengers))    # Pickup
        events.append((end, -num_passengers))     # Dropoff

    # Sort by location (pickups before dropoffs at same location)
    events.sort()

    current_passengers = 0
    for location, change in events:
        current_passengers += change
        if current_passengers > capacity:
            return False

    return True
```

### Complexity Analysis

**Difference Array: Time: O(n + m) - where m is fixed at 1000. Space: O(m) - fixed size array**

**Sorting: Time: O(n log n) - sorting events. Space: O(n) - event storage**

**Why Difference Array is Optimal:**
- O(n) time when m is bounded (1000 locations)
- Avoids sorting overhead
- Simple prefix sum computation
- Fixed space regardless of number of trips
- Better for problems with bounded coordinate range

**Why Sorting Can Be Better:**
- When location range is very large (m >> n log n)
- More intuitive event-based simulation
- Only processes actual events, not empty locations
- Generalizes better to unbounded coordinates

---

## Categories & Tags

**Primary Topics:** Array, Sorting, Heap (Priority Queue), Simulation, Prefix Sum

**Difficulty Level:** MEDIUM

---

## Real-World Applications

Understanding this algorithmic pattern has direct real-world applications:

1. **Ride Sharing:** Uber/Lyft route optimization validating driver capacity across multi-stop trips
2. **Public Transportation:** Transit agencies (NYC MTA, London Transport) validating bus/train capacity across routes
3. **Delivery Services:** UPS/FedEx truck capacity validation for package pickup/delivery schedules
4. **Meeting Room Booking:** Google Calendar/Outlook validating room capacity for overlapping meetings
5. **Cloud Resource Management:** AWS/Azure validating VM capacity across time-based reservation windows
6. **Elevator Systems:** Otis/KONE elevator controllers validating passenger capacity across floors

**Industry Impact:**
This interval scheduling and capacity validation pattern appears in production systems at Uber (driver trip assignment), Google (resource scheduling), Amazon (delivery route planning), and Microsoft (Exchange meeting room booking). Logistics companies use similar algorithms for vehicle routing problems (VRP). Real-time systems use difference arrays for efficient range update operations.

---

## Cybersecurity Applications

This problem demonstrates algorithmic concepts crucial for security engineering:

1. **Rate Limiting:** API gateway (AWS API Gateway, Kong) validating concurrent request capacity across time windows
2. **Connection Pooling:** Database connection limits (PostgreSQL max_connections) validation across application lifecycle
3. **DDoS Protection:** Cloudflare/Akamai validating traffic capacity across attack time windows
4. **License Compliance:** Concurrent user license validation (Splunk, Adobe) across session lifecycles
5. **Resource Quotas:** Kubernetes validating pod resource limits across deployment windows
6. **Firewall Rules:** Palo Alto Networks validating connection limits across active sessions

**Security Engineering Value:**
Security professionals use capacity validation algorithms for rate limiting in WAFs, validating concurrent session limits in IAM systems, monitoring resource consumption in SIEM platforms, and enforcing quotas in cloud security posture management (CSPM). Understanding interval scheduling helps design robust resource management that prevents exhaustion attacks.

**Common Security Contexts:**
- **Threat Detection:** Monitoring capacity violations as indicators of resource exhaustion attacks
- **Performance Security:** Preventing DoS through capacity-aware resource allocation
- **Secure Code Review:** Identifying race conditions in concurrent resource management
- **Security Tooling:** Building efficient monitors for quota and rate limit enforcement
- **Incident Response:** Analyzing timeline of resource consumption during security incidents

---

## Learning Resources

**Recommended Study Path:**
1. Master difference array and prefix sum techniques
2. Practice similar problems: Meeting Rooms II, My Calendar, Interval Problems
3. Implement both difference array and sorting approaches
4. Understand when each approach is optimal (bounded vs unbounded ranges)
5. Consider edge cases: single trip, capacity equals max passengers, zero capacity

**Interview Preparation:**
- This problem has 40.7% frequency in technical interviews
- Expected to solve in 20-45 minutes during coding interviews
- Be prepared to explain both approaches and their tradeoffs
- Practice explaining the difference array technique clearly

**Common Pitfalls:**
- Confusing pickup/dropoff events at the same location
- Off-by-one errors: passengers drop off before location, not at location
- Not considering that dropoffs happen before pickups at same location (in sorting approach)
- Using heap when difference array is simpler for bounded ranges
- Incorrect array size (needs 1001 for locations 0-1000)

**Optimization Tips:**
- Use difference array for bounded coordinate problems (locations 0-1000)
- Use sorting for unbounded or sparse coordinate problems
- Consider heap approach for "Meeting Rooms II" variant (counting max overlaps)
- Early termination when capacity exceeded
- Recognize this pattern in interval scheduling problems

---

*Generated for educational purposes. Problem source: [LeetCode](https://leetcode.com/problems/car-pooling)*
