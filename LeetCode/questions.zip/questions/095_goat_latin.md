# 095. Goat Latin

**Difficulty:** EASY
**Frequency:** 32.0%
**Acceptance Rate:** 69.4%
**LeetCode Link:** [Goat Latin](https://leetcode.com/problems/goat-latin)

---

## Problem Description

You are given a string `sentence` that consists of words separated by spaces. Each word consists of lowercase and uppercase letters only.

We would like to convert the sentence to "Goat Latin" (a made-up language similar to Pig Latin.)

The rules of Goat Latin are as follows:
- If a word begins with a vowel ('a', 'e', 'i', 'o', or 'u'), append "ma" to the end of the word.
  - For example, the word "apple" becomes "applema".
- If a word begins with a consonant (i.e., not a vowel), remove the first letter and append it to the end, then add "ma".
  - For example, the word "goat" becomes "oatgma".
- Add one letter 'a' to the end of each word per its word index in the sentence, starting with 1.
  - For example, the first word gets "a" added to the end, the second word gets "aa" added to the end, and so on.

Return the final sentence representing the conversion from sentence to Goat Latin.

**Constraints:**
- 1 <= sentence.length <= 150
- sentence consists of English letters and spaces
- sentence has no leading or trailing spaces
- All words in sentence are separated by a single space

---

## Examples

### Example 1
**Input:** `sentence = "I speak Goat Latin"`
**Output:** `"Imaa peaksmaaa oatGmaaaa atinLmaaaaa"`
**Explanation:**
- "I" starts with vowel → "Ima" + "a" = "Imaa"
- "speak" starts with consonant → "peaksma" + "aa" = "peaksmaaa"
- "Goat" starts with consonant → "oatGma" + "aaa" = "oatGmaaaa"
- "Latin" starts with consonant → "atinLma" + "aaaa" = "atinLmaaaaa"

### Example 2
**Input:** `sentence = "The quick brown fox jumped over the lazy dog"`
**Output:** `"heTmaa uickqmaaa rownbmaaaa oxfmaaaaa umpedjmaaaaaa overmaaaaaaa hetmaaaaaaaa azylmaaaaaaaaa ogdmaaaaaaaaaa"`
**Explanation:** Each word is transformed according to Goat Latin rules

### Example 3
**Input:** `sentence = "Each word consists of lowercase and uppercase letters only"`
**Output:** `"Eachmaa ordwmaaa onsistscmaaaa ofmaaaaa owercaselmaaaaaa andmaaaaaaa uppercasemaaaaaaaa etterslmaaaaaaaaa onlymaaaaaaaaaa"`
**Explanation:** Vowel words get "ma" appended, consonant words get first letter moved to end

### Example 4
**Input:** `sentence = "apple"`
**Output:** `"applema"`
**Explanation:** Single word starting with vowel, first word gets one 'a' added

---

## Optimal Solution

### Implementation

```python
def toGoatLatin(sentence: str) -> str:
    """
    Convert sentence to Goat Latin by applying transformation rules.

    Time: O(n), Space: O(n) where n is length of sentence
    """
    vowels = set('aeiouAEIOU')
    words = sentence.split()
    result = []

    for i, word in enumerate(words):
        # Apply Goat Latin rules
        if word[0] in vowels:
            # Vowel: append "ma"
            goat_word = word + "ma"
        else:
            # Consonant: move first letter to end, append "ma"
            goat_word = word[1:] + word[0] + "ma"

        # Add 'a' based on word index (1-indexed)
        goat_word += 'a' * (i + 1)
        result.append(goat_word)

    return ' '.join(result)
```

### Alternative Implementation (More Concise)

```python
def toGoatLatin(sentence: str) -> str:
    """
    One-liner approach using list comprehension.

    Time: O(n), Space: O(n)
    """
    vowels = set('aeiouAEIOU')
    words = sentence.split()

    return ' '.join(
        (word if word[0] in vowels else word[1:] + word[0]) + 'ma' + 'a' * (i + 1)
        for i, word in enumerate(words)
    )
```

### Complexity Analysis

**Time: O(n) - where n is the length of the sentence. Space: O(n) - for storing the result**

**Why This is Optimal:**
- Single pass through the sentence
- Efficient string operations using join() instead of repeated concatenation
- Set lookup for vowels is O(1)
- Each word is processed exactly once
- Space complexity is optimal since we need to store the output

---

## Categories & Tags

**Primary Topics:** String

**Difficulty Level:** EASY

---

## Real-World Applications

Understanding this algorithmic pattern has direct real-world applications:

1. **Natural Language Processing:** Text transformation pipelines in spaCy, NLTK for tokenization and word manipulation
2. **Internationalization (i18n):** Translation systems like Google Translate applying language-specific transformation rules
3. **Code Obfuscation:** Variable and function name transformers in JavaScript minifiers (Terser, UglifyJS)
4. **Privacy Tools:** Text anonymization in tools like Microsoft Presidio for PII removal and transformation
5. **Educational Software:** Language learning apps (Duolingo, Babbel) implementing phonetic transformations

**Industry Impact:**
String transformation algorithms are fundamental to text processing systems. They appear in compilers (identifier renaming), code formatters (Prettier, Black), text-to-speech systems (AWS Polly, Google Cloud TTS), and data masking tools used in GDPR compliance software.

---

## Cybersecurity Applications

This problem demonstrates algorithmic concepts crucial for security engineering:

1. **Malware Deobfuscation:** Reversing string obfuscation techniques in malware analysis (IDA Pro, Ghidra, radare2)
2. **Code Injection Detection:** Identifying obfuscated SQL injection and XSS payloads in WAF logs (ModSecurity, Cloudflare)
3. **Password Policy Enforcement:** Text transformation rules for password complexity validators in IAM systems (Okta, Auth0)
4. **Data Masking:** PII redaction and transformation in DLP tools (Symantec DLP, Forcepoint)
5. **Malicious URL Detection:** Analyzing URL obfuscation patterns in phishing detection systems (VirusTotal, URLScan)
6. **Log Sanitization:** Removing or transforming sensitive data in SIEM tools (Splunk, ELK Stack)

**Security Engineering Value:**
String manipulation is fundamental to security tools that analyze, transform, and sanitize text data. Understanding these patterns helps security engineers build robust parsing logic for threat detection, develop encoding/decoding utilities for forensic analysis, and implement data protection mechanisms that comply with privacy regulations.

**Common Security Contexts:**
- **Threat Detection:** Pattern matching and anomaly detection in security logs
- **Performance Security:** Preventing algorithmic complexity attacks (e.g., hash collision DoS)
- **Secure Code Review:** Identifying potential vulnerabilities in algorithm implementations
- **Security Tooling:** Building efficient security scanners and analysis tools
- **Incident Response:** Fast data processing during security investigations

---

## Learning Resources

**Recommended Study Path:**
1. Master the fundamental data structure concepts
2. Practice similar problems with the same pattern
3. Implement the solution from scratch without reference
4. Analyze time/space complexity of alternative approaches
5. Consider edge cases and error handling

**Interview Preparation:**
- This problem has 32.0% frequency in technical interviews
- Expected to solve in 20-45 minutes during coding interviews
- Be prepared to discuss trade-offs and alternative approaches
- Practice explaining your thought process clearly

**Common Pitfalls:**
- Off-by-one errors in array/string indexing
- Not handling edge cases (empty input, single element, etc.)
- Incorrect complexity analysis
- Over-complicating the solution

**Optimization Tips:**
- Consider early termination conditions
- Minimize unnecessary data structure operations
- Use built-in language features efficiently
- Profile for performance on large inputs

---

*Generated for educational purposes. Problem source: [LeetCode](https://leetcode.com/problems/goat-latin)*
