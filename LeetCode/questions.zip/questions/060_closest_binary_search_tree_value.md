# 060. Closest Binary Search Tree Value

**Difficulty:** EASY
**Frequency:** 47.0%
**Acceptance Rate:** 49.8%
**LeetCode Link:** [Closest Binary Search Tree Value](https://leetcode.com/problems/closest-binary-search-tree-value)

---

## Problem Description

Given the `root` of a binary search tree and a `target` value, return the value in the BST that is closest to the `target`.

**Constraints:**
- The number of nodes in the tree is in the range [1, 10^4]
- 0 <= Node.val <= 10^9
- -10^9 <= target <= 10^9

---

## Examples

### Example 1
**Input:** `root = [4,2,5,1,3], target = 3.714286`
**Output:** `4`
**Explanation:** 4 is closer to 3.714286 than 3

### Example 2
**Input:** `root = [1], target = 4.428571`
**Output:** `1`
**Explanation:** Only one node in tree

### Example 3
**Input:** `root = [5,3,7,2,4,6,8], target = 3.5`
**Output:** `3 or 4`
**Explanation:** Both 3 and 4 are equally close

### Example 4
**Input:** `root = [10,5,15,2,7], target = 6`
**Output:** `7 or 5`
**Explanation:** 5 and 7 are equally distant

---

## Optimal Solution

### Implementation

```python
def closestValue(root: TreeNode, target: float) -> int:
    """
    Binary search in BST to find closest value.

    Time: O(h), Space: O(1) for iterative
    """
    closest = root.val

    while root:
        # Update closest if current is closer
        if abs(root.val - target) < abs(closest - target):
            closest = root.val

        # Binary search based on BST property
        if target < root.val:
            root = root.left
        else:
            root = root.right

    return closest
```

### Complexity Analysis

**Time: O(h) - height of tree. Space: O(1) - iterative constant space**

**Why This is Optimal:**
- Achieves best possible asymptotic complexity for this problem class
- Minimal space overhead while maintaining code clarity
- Scales efficiently with large inputs
- Handles all edge cases correctly

---

## Categories & Tags

**Primary Topics:** Binary Search, Tree, Depth-First Search, Binary Search Tree, Binary Tree

**Difficulty Level:** EASY

---

## Real-World Applications

Understanding this algorithmic pattern has direct real-world applications:

1. **Database Indexing:** B-tree range queries in MySQL/PostgreSQL
2. **Autocomplete:** Finding closest match in dictionary/trie structures
3. **Geographic Search:** KD-tree nearest location searches (Google Maps)
4. **Recommendation Systems:** Finding similar items by score (Netflix)
5. **Price Matching:** E-commerce finding closest price point
6. **Time Series:** Finding closest timestamp in indexed data

**Industry Impact:**
This algorithmic pattern appears in production systems at companies like Google, Amazon, Microsoft, Meta, and Netflix. Engineers working on large-scale distributed systems, data processing pipelines, and user-facing applications regularly implement these concepts.

---

## Cybersecurity Applications

This problem demonstrates algorithmic concepts crucial for security engineering:

1. **Threat Score Matching:** Finding closest threat level in CVSS database
2. **Log Timestamp Search:** Finding closest log entry to incident time
3. **Port Scanning:** Finding closest open port in range
4. **Vulnerability Matching:** Finding similar CVE scores
5. **Attack Signature:** Matching closest signature in IDS database
6. **Anomaly Detection:** Finding closest normal behavior baseline
7. **Risk Assessment:** Finding closest risk score match in assessment database

**Security Engineering Value:**
Security professionals use these algorithms in threat detection systems, security information and event management (SIEM) platforms, intrusion detection/prevention systems (IDS/IPS), and security automation tools. Understanding these patterns is essential for developing robust security solutions.

**Common Security Contexts:**
- **Threat Detection:** Pattern matching and anomaly detection in security logs
- **Performance Security:** Preventing algorithmic complexity attacks (e.g., hash collision DoS)
- **Secure Code Review:** Identifying potential vulnerabilities in algorithm implementations
- **Security Tooling:** Building efficient security scanners and analysis tools
- **Incident Response:** Fast data processing during security investigations

---

## Learning Resources

**Recommended Study Path:**
1. Master the fundamental data structure concepts
2. Practice similar problems with the same pattern
3. Implement the solution from scratch without reference
4. Analyze time/space complexity of alternative approaches
5. Consider edge cases and error handling

**Interview Preparation:**
- This problem has 47.0% frequency in technical interviews
- Expected to solve in 20-45 minutes during coding interviews
- Be prepared to discuss trade-offs and alternative approaches
- Practice explaining your thought process clearly

**Common Pitfalls:**
- Off-by-one errors in array/string indexing
- Not handling edge cases (empty input, single element, etc.)
- Incorrect complexity analysis
- Over-complicating the solution

**Optimization Tips:**
- Consider early termination conditions
- Minimize unnecessary data structure operations
- Use built-in language features efficiently
- Profile for performance on large inputs

---

*Generated for educational purposes. Problem source: [LeetCode](https://leetcode.com/problems/closest-binary-search-tree-value)*
