# 096. Longest Palindromic Substring

**Difficulty:** MEDIUM
**Frequency:** 32.0%
**Acceptance Rate:** 35.8%
**LeetCode Link:** [Longest Palindromic Substring](https://leetcode.com/problems/longest-palindromic-substring)

---

## Problem Description

Given a string `s`, return the longest palindromic substring in `s`.

**Constraints:**
- 1 <= s.length <= 1000
- s consist of only digits and English letters

---

## Examples

### Example 1
**Input:** `s = "babad"`
**Output:** `"bab" or "aba"`
**Explanation:** Both are valid longest palindromes

### Example 2
**Input:** `s = "cbbd"`
**Output:** `"bb"`
**Explanation:** Only palindrome of length > 1

### Example 3
**Input:** `s = "a"`
**Output:** `"a"`
**Explanation:** Single character is palindrome

### Example 4
**Input:** `s = "racecar"`
**Output:** `"racecar"`
**Explanation:** Entire string is palindrome

---

## Optimal Solution

### Implementation

```python
def longestPalindrome(s: str) -> str:
    """
    Expand around center for all possible centers.

    Time: O(n²), Space: O(1)
    """
    if not s:
        return ""

    def expand_around_center(left, right):
        while left >= 0 and right < len(s) and s[left] == s[right]:
            left -= 1
            right += 1
        return right - left - 1

    start = 0
    max_len = 0

    for i in range(len(s)):
        # Odd length palindromes
        len1 = expand_around_center(i, i)
        # Even length palindromes
        len2 = expand_around_center(i, i + 1)

        current_max = max(len1, len2)
        if current_max > max_len:
            max_len = current_max
            start = i - (current_max - 1) // 2

    return s[start:start + max_len]
```

### Complexity Analysis

**Time: O(n²) - expand from each center. Space: O(1) - constant**

**Why This is Optimal:**
- Achieves best possible asymptotic complexity for this problem class
- Minimal space overhead while maintaining code clarity
- Scales efficiently with large inputs
- Handles all edge cases correctly

---

## Categories & Tags

**Primary Topics:** Two Pointers, String, Dynamic Programming

**Difficulty Level:** MEDIUM

---

## Real-World Applications

Understanding this algorithmic pattern has direct real-world applications:

1. **DNA Analysis:** Finding palindromic restriction enzyme sites (BLAST)
2. **Text Processing:** Document similarity analysis
3. **Pattern Matching:** Search engine query optimization
4. **Data Compression:** Finding repeated symmetric patterns
5. **String Algorithms:** Text editor pattern recognition
6. **Bioinformatics:** Protein sequence palindrome analysis

**Industry Impact:**
This algorithmic pattern appears in production systems at companies like Google, Amazon, Microsoft, Meta, and Netflix. Engineers working on large-scale distributed systems, data processing pipelines, and user-facing applications regularly implement these concepts.

---

## Cybersecurity Applications

This problem demonstrates algorithmic concepts crucial for security engineering:

1. **Malware Detection:** Finding palindromic shellcode patterns
2. **Protocol Analysis:** Detecting symmetric packet patterns
3. **Obfuscation Detection:** Identifying palindromic encoding in malware
4. **Cryptanalysis:** Finding weak patterns in encrypted data
5. **Signature Matching:** Detecting palindromic attack signatures
6. **Anomaly Detection:** Finding unusual symmetric patterns in logs
7. **Steganography:** Detecting hidden palindromic markers

**Security Engineering Value:**
Security professionals use these algorithms in threat detection systems, security information and event management (SIEM) platforms, intrusion detection/prevention systems (IDS/IPS), and security automation tools. Understanding these patterns is essential for developing robust security solutions.

**Common Security Contexts:**
- **Threat Detection:** Pattern matching and anomaly detection in security logs
- **Performance Security:** Preventing algorithmic complexity attacks (e.g., hash collision DoS)
- **Secure Code Review:** Identifying potential vulnerabilities in algorithm implementations
- **Security Tooling:** Building efficient security scanners and analysis tools
- **Incident Response:** Fast data processing during security investigations

---

## Learning Resources

**Recommended Study Path:**
1. Master the fundamental data structure concepts
2. Practice similar problems with the same pattern
3. Implement the solution from scratch without reference
4. Analyze time/space complexity of alternative approaches
5. Consider edge cases and error handling

**Interview Preparation:**
- This problem has 32.0% frequency in technical interviews
- Expected to solve in 20-45 minutes during coding interviews
- Be prepared to discuss trade-offs and alternative approaches
- Practice explaining your thought process clearly

**Common Pitfalls:**
- Off-by-one errors in array/string indexing
- Not handling edge cases (empty input, single element, etc.)
- Incorrect complexity analysis
- Over-complicating the solution

**Optimization Tips:**
- Consider early termination conditions
- Minimize unnecessary data structure operations
- Use built-in language features efficiently
- Profile for performance on large inputs

---

*Generated for educational purposes. Problem source: [LeetCode](https://leetcode.com/problems/longest-palindromic-substring)*
