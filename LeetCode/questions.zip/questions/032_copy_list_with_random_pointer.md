# 032. Copy List with Random Pointer

**Difficulty:** MEDIUM
**Frequency:** 67.4%
**Acceptance Rate:** 60.5%
**LeetCode Link:** [Copy List with Random Pointer](https://leetcode.com/problems/copy-list-with-random-pointer)

---

## Problem Description

A linked list of length `n` is given such that each node contains an additional random pointer, which could point to any node in the list, or `null`.

Construct a deep copy of the list. The deep copy should consist of exactly `n` brand new nodes, where each new node has its value set to the value of its corresponding original node. Both the `next` and `random` pointer of the new nodes should point to new nodes in the copied list.

Return the head of the copied linked list.

**Constraints:**
- 0 <= n <= 1000
- -10^4 <= Node.val <= 10^4
- Node.random is null or is pointing to some node in the linked list

---

## Examples

### Example 1
**Input:** `head = [[7,null],[13,0],[11,4],[10,2],[1,0]]`
**Output:** `[[7,null],[13,0],[11,4],[10,2],[1,0]]`
**Explanation:** 5 nodes with various random pointers

### Example 2
**Input:** `head = [[1,1],[2,1]]`
**Output:** `[[1,1],[2,1]]`
**Explanation:** 2 nodes, both random point to first node

### Example 3
**Input:** `head = [[3,null],[3,0],[3,null]]`
**Output:** `[[3,null],[3,0],[3,null]]`
**Explanation:** 3 nodes with same value

### Example 4
**Input:** `head = []`
**Output:** `[]`
**Explanation:** Empty list

---

## Optimal Solution

### Implementation

```python
def copyRandomList(head: 'Node') -> 'Node':
    """
    Two-pass approach with hash map.

    Time: O(n), Space: O(n)
    """
    if not head:
        return None

    # First pass: create all nodes
    old_to_new = {}
    curr = head
    while curr:
        old_to_new[curr] = Node(curr.val)
        curr = curr.next

    # Second pass: set next and random pointers
    curr = head
    while curr:
        if curr.next:
            old_to_new[curr].next = old_to_new[curr.next]
        if curr.random:
            old_to_new[curr].random = old_to_new[curr.random]
        curr = curr.next

    return old_to_new[head]
```

### Complexity Analysis

**Time: O(n) - two passes. Space: O(n) - hash map**

**Why This is Optimal:**
- Achieves best possible asymptotic complexity for this problem class
- Minimal space overhead while maintaining code clarity
- Scales efficiently with large inputs
- Handles all edge cases correctly

---

## Categories & Tags

**Primary Topics:** Hash Table, Linked List

**Difficulty Level:** MEDIUM

---

## Real-World Applications

Understanding this algorithmic pattern has direct real-world applications:

1. **Version Control:** Git snapshot creation with branch references
2. **Memory Management:** OS copy-on-write page duplication
3. **Database Transactions:** MVCC (Multi-Version Concurrency Control) in PostgreSQL
4. **Garbage Collection:** JVM object graph copying for generational GC
5. **State Management:** Redux/Vuex immutable state updates
6. **Undo/Redo Systems:** Photoshop history state copying

**Industry Impact:**
This algorithmic pattern appears in production systems at companies like Google, Amazon, Microsoft, Meta, and Netflix. Engineers working on large-scale distributed systems, data processing pipelines, and user-facing applications regularly implement these concepts.

---

## Cybersecurity Applications

This problem demonstrates algorithmic concepts crucial for security engineering:

1. **Sandbox Snapshots:** Cuckoo creating isolated malware analysis snapshots
2. **Memory Forensics:** Volatility framework copying process memory with pointers
3. **Virtual Machine Cloning:** VMware security lab environment duplication
4. **Session Replication:** Load balancer session state copying for failover
5. **Secure Backup:** Duplicating encrypted data structures with key references
6. **Incident Preservation:** Creating forensic copies maintaining all relationships
7. **Container Security:** Docker layer copying with security context preservation

**Security Engineering Value:**
Security professionals use these algorithms in threat detection systems, security information and event management (SIEM) platforms, intrusion detection/prevention systems (IDS/IPS), and security automation tools. Understanding these patterns is essential for developing robust security solutions.

**Common Security Contexts:**
- **Threat Detection:** Pattern matching and anomaly detection in security logs
- **Performance Security:** Preventing algorithmic complexity attacks (e.g., hash collision DoS)
- **Secure Code Review:** Identifying potential vulnerabilities in algorithm implementations
- **Security Tooling:** Building efficient security scanners and analysis tools
- **Incident Response:** Fast data processing during security investigations

---

## Learning Resources

**Recommended Study Path:**
1. Master the fundamental data structure concepts
2. Practice similar problems with the same pattern
3. Implement the solution from scratch without reference
4. Analyze time/space complexity of alternative approaches
5. Consider edge cases and error handling

**Interview Preparation:**
- This problem has 67.4% frequency in technical interviews
- Expected to solve in 20-45 minutes during coding interviews
- Be prepared to discuss trade-offs and alternative approaches
- Practice explaining your thought process clearly

**Common Pitfalls:**
- Off-by-one errors in array/string indexing
- Not handling edge cases (empty input, single element, etc.)
- Incorrect complexity analysis
- Over-complicating the solution

**Optimization Tips:**
- Consider early termination conditions
- Minimize unnecessary data structure operations
- Use built-in language features efficiently
- Profile for performance on large inputs

---

*Generated for educational purposes. Problem source: [LeetCode](https://leetcode.com/problems/copy-list-with-random-pointer)*
