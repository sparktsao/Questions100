# 041. Kth Missing Positive Number

**Difficulty:** EASY
**Frequency:** 59.4%
**Acceptance Rate:** 62.3%
**LeetCode Link:** [Kth Missing Positive Number](https://leetcode.com/problems/kth-missing-positive-number)

---

## Problem Description

Given an array `arr` of positive integers sorted in a strictly increasing order, and an integer `k`.

Return the kth positive integer that is missing from this array.

**Constraints:**
- 1 <= arr.length <= 1000
- 1 <= arr[i] <= 1000
- 1 <= k <= 1000
- arr[i] < arr[j] for 1 <= i < j <= arr.length

---

## Examples

### Example 1
**Input:** `arr = [2,3,4,7,11], k = 5`
**Output:** `9`
**Explanation:** The missing positive integers are [1,5,6,8,9,10,12,13,...]. The 5th missing positive integer is 9.

### Example 2
**Input:** `arr = [1,2,3,4], k = 2`
**Output:** `6`
**Explanation:** The missing positive integers are [5,6,7,...]. The 2nd missing positive integer is 6.

### Example 3
**Input:** `arr = [5,6,7,8,9], k = 9`
**Output:** `14`
**Explanation:** The missing positive integers are [1,2,3,4,10,11,12,13,14,...]. The 9th missing positive integer is 14.

### Example 4
**Input:** `arr = [1,10,21,22,25], k = 12`
**Output:** `14`
**Explanation:** Missing numbers include [2,3,4,5,6,7,8,9,11,12,13,14,...]. The 12th missing number is 14.

---

## Optimal Solution

### Implementation

```python
def findKthPositive(arr: List[int], k: int) -> int:
    """
    Binary search to find kth missing positive number.

    Time: O(log n), Space: O(1)
    """
    left, right = 0, len(arr) - 1

    while left <= right:
        mid = left + (right - left) // 2
        # Number of missing integers before arr[mid]
        missing = arr[mid] - (mid + 1)

        if missing < k:
            left = mid + 1
        else:
            right = mid - 1

    # At the end, left is the insertion point
    # k missing numbers = left + k
    return left + k
```

### Alternative Linear Solution

```python
def findKthPositive(arr: List[int], k: int) -> int:
    """
    Linear scan approach for comparison.

    Time: O(n), Space: O(1)
    """
    # Count missing numbers
    for num in arr:
        if num <= k:
            k += 1
        else:
            break

    return k
```

### Complexity Analysis

**Time: O(log n) - binary search. Space: O(1) - constant**

**Why This is Optimal:**
- Binary search achieves logarithmic time complexity
- Key insight: arr[mid] - (mid + 1) gives count of missing numbers before index mid
- No extra space needed beyond variables
- Handles all edge cases efficiently

---

## Categories & Tags

**Primary Topics:** Array, Binary Search

**Difficulty Level:** EASY

---

## Real-World Applications

Understanding this algorithmic pattern has direct real-world applications:

1. **Database Systems:** Finding missing sequence numbers in PostgreSQL auto-increment IDs, MySQL gap analysis for transaction logs
2. **Network Monitoring:** Detecting missing packet sequence numbers in TCP/IP streams, identifying dropped frames in video streaming (Netflix, YouTube)
3. **Distributed Systems:** Finding missing log entries in Apache Kafka partitions, detecting gaps in distributed transaction IDs
4. **Data Quality:** Identifying missing records in ETL pipelines (Apache Airflow, AWS Glue), detecting gaps in time-series data (InfluxDB, TimescaleDB)
5. **File Systems:** Detecting missing blocks in HDFS, identifying gaps in backup sequences

**Industry Impact:**
This pattern is crucial for data integrity verification in distributed systems. Companies like Google, Amazon, and Microsoft use similar algorithms to detect missing records in their massive data processing pipelines, ensuring data completeness and consistency across distributed databases.

---

## Cybersecurity Applications

This problem demonstrates algorithmic concepts crucial for security engineering:

1. **Log Analysis:** Detecting missing log entries in SIEM systems (Splunk, ELK Stack) to identify potential log tampering or deletion by attackers
2. **Intrusion Detection:** Identifying gaps in network packet sequences to detect packet injection or man-in-the-middle attacks (Snort, Suricata)
3. **Audit Compliance:** Finding missing audit trail entries in SOC 2/ISO 27001 compliance systems, detecting unauthorized deletion of security events
4. **Blockchain Validation:** Verifying complete block sequences in cryptocurrency nodes to prevent fork attacks
5. **Forensic Analysis:** Detecting deleted or missing file system entries during digital forensics investigations (Autopsy, FTK)
6. **Session Management:** Identifying missing session IDs to detect session hijacking or replay attacks

**Security Engineering Value:**
Gap detection algorithms are essential for maintaining audit trails and detecting malicious activity. Missing sequence numbers often indicate tampering, data exfiltration covering tracks, or system compromise. Security teams use these patterns to build anomaly detection systems that identify when attackers attempt to hide their activities.

**Common Security Contexts:**
- **Threat Detection:** Pattern matching and anomaly detection in security logs
- **Performance Security:** Preventing algorithmic complexity attacks (e.g., hash collision DoS)
- **Secure Code Review:** Identifying potential vulnerabilities in algorithm implementations
- **Security Tooling:** Building efficient security scanners and analysis tools
- **Incident Response:** Fast data processing during security investigations

---

## Learning Resources

**Recommended Study Path:**
1. Master binary search on implicit arrays and virtual sequences
2. Practice similar problems: Missing Element in Sorted Array, Find the Smallest Divisor
3. Implement the solution from scratch without reference
4. Analyze time/space complexity of alternative approaches
5. Consider edge cases and error handling

**Interview Preparation:**
- This problem has 59.4% frequency in technical interviews
- Expected to solve in 15-25 minutes during coding interviews
- Be prepared to discuss both linear and binary search approaches
- Practice explaining the key insight about calculating missing count

**Common Pitfalls:**
- Off-by-one errors when calculating missing count: arr[mid] - (mid + 1)
- Not handling edge cases where k is larger than all elements
- Incorrect binary search boundary conditions
- Over-complicating with unnecessary data structures

**Optimization Tips:**
- Recognize this as binary search on answer space
- Use the formula: missing_before_index = arr[index] - (index + 1)
- Early termination when arr[0] > k
- Consider integer overflow in other languages

---

*Generated for educational purposes. Problem source: [LeetCode](https://leetcode.com/problems/kth-missing-positive-number)*
