# 020. Valid Parentheses

**Difficulty:** EASY
**Frequency:** 74.9%
**Acceptance Rate:** 42.3%
**LeetCode Link:** [Valid Parentheses](https://leetcode.com/problems/valid-parentheses)

---

## Problem Description

Given a string `s` containing just the characters '(', ')', '{', '}', '[' and ']', determine if the input string is valid.

An input string is valid if:
1. Open brackets must be closed by the same type of brackets
2. Open brackets must be closed in the correct order
3. Every close bracket has a corresponding open bracket of the same type

**Constraints:**
- 1 <= s.length <= 10^4
- s consists of parentheses only '()[]{}'

---

## Examples

### Example 1
**Input:** `s = "()"`
**Output:** `true`
**Explanation:** Simple matching pair

### Example 2
**Input:** `s = "()[]{}"`
**Output:** `true`
**Explanation:** Multiple types of brackets, all matched correctly

### Example 3
**Input:** `s = "(]"`
**Output:** `false`
**Explanation:** Mismatched bracket types

### Example 4
**Input:** `s = "([)]"`
**Output:** `false`
**Explanation:** Incorrect nesting order

### Example 5
**Input:** `s = "{[]}"`
**Output:** `true`
**Explanation:** Properly nested brackets

---

## Optimal Solution

### Implementation

```python
def isValid(s: str) -> bool:
    """
    Check if parentheses are valid using stack.

    Time: O(n), Space: O(n)
    """
    stack = []
    mapping = {')': '(', '}': '{', ']': '['}

    for char in s:
        if char in mapping:
            top = stack.pop() if stack else '#'
            if mapping[char] != top:
                return False
        else:
            stack.append(char)

    return not stack
```

### Complexity Analysis

**Time: O(n) - single pass. Space: O(n) - stack storage**

**Why This is Optimal:**
- Achieves best possible asymptotic complexity for this problem class
- Minimal space overhead while maintaining code clarity
- Scales efficiently with large inputs
- Handles all edge cases correctly

---

## Categories & Tags

**Primary Topics:** String, Stack

**Difficulty Level:** EASY

---

## Real-World Applications

Understanding this algorithmic pattern has direct real-world applications:

1. **Code Editors:** Bracket matching in VS Code, IntelliJ IDEA, Sublime Text
2. **Compilers:** Syntax validation in GCC, Clang, Javac during parsing phase
3. **JSON/XML Parsers:** Validating nested structures in data formats
4. **LaTeX Processors:** Checking mathematical expression validity in document preparation
5. **HTML/CSS Validators:** W3C validators checking tag nesting in web documents

**Industry Impact:**
This algorithmic pattern appears in production systems at companies like Google, Amazon, Microsoft, Meta, and Netflix. Engineers working on large-scale distributed systems, data processing pipelines, and user-facing applications regularly implement these concepts.

---

## Cybersecurity Applications

This problem demonstrates algorithmic concepts crucial for security engineering:

1. **SQL Injection Detection:** Validating parentheses in SQL queries to detect injection (ModSecurity WAF)
2. **XSS Prevention:** Checking script tag balance in user input (OWASP ZAP)
3. **Code Injection:** Validating expression syntax to prevent eval() attacks
4. **Buffer Overflow Detection:** Stack frame analysis for return address corruption (GDB, WinDbg)
5. **Malware Deobfuscation:** Parsing obfuscated code with complex nesting (ANY.RUN, Joe Sandbox)
6. **Protocol Validation:** Checking message format in custom protocols (Wireshark dissectors)

**Security Engineering Value:**
Security professionals use these algorithms in threat detection systems, security information and event management (SIEM) platforms, intrusion detection/prevention systems (IDS/IPS), and security automation tools. Understanding these patterns is essential for developing robust security solutions.

**Common Security Contexts:**
- **Threat Detection:** Pattern matching and anomaly detection in security logs
- **Performance Security:** Preventing algorithmic complexity attacks (e.g., hash collision DoS)
- **Secure Code Review:** Identifying potential vulnerabilities in algorithm implementations
- **Security Tooling:** Building efficient security scanners and analysis tools
- **Incident Response:** Fast data processing during security investigations

---

## Learning Resources

**Recommended Study Path:**
1. Master the fundamental data structure concepts
2. Practice similar problems with the same pattern
3. Implement the solution from scratch without reference
4. Analyze time/space complexity of alternative approaches
5. Consider edge cases and error handling

**Interview Preparation:**
- This problem has 74.9% frequency in technical interviews
- Expected to solve in 20-45 minutes during coding interviews
- Be prepared to discuss trade-offs and alternative approaches
- Practice explaining your thought process clearly

**Common Pitfalls:**
- Off-by-one errors in array/string indexing
- Not handling edge cases (empty input, single element, etc.)
- Incorrect complexity analysis
- Over-complicating the solution

**Optimization Tips:**
- Consider early termination conditions
- Minimize unnecessary data structure operations
- Use built-in language features efficiently
- Profile for performance on large inputs

---

*Generated for educational purposes. Problem source: [LeetCode](https://leetcode.com/problems/valid-parentheses)*
