# 093. Decode String

**Difficulty:** MEDIUM
**Frequency:** 32.0%
**Acceptance Rate:** 61.2%
**LeetCode Link:** [Decode String](https://leetcode.com/problems/decode-string)

---

## Problem Description

Given an encoded string, return its decoded string.

The encoding rule is: `k[encoded_string]`, where the `encoded_string` inside the square brackets is being repeated exactly `k` times. Note that `k` is guaranteed to be a positive integer.

You may assume that the input string is always valid; there are no extra white spaces, square brackets are well-formed, etc. Furthermore, you may assume that the original data does not contain any digits and that digits are only for those repeat numbers, `k`. For example, there will not be input like `3a` or `2[4]`.

The test cases are generated so that the length of the output will never exceed 10^5.

**Constraints:**
- 1 <= s.length <= 30
- s consists of lowercase English letters, digits, and square brackets '[]'
- s is guaranteed to be a valid input
- All the integers in s are in the range [1, 300]

---

## Examples

### Example 1
**Input:** `s = "3[a]2[bc]"`
**Output:** `"aaabcbc"`
**Explanation:** "a" is repeated 3 times, "bc" is repeated 2 times

### Example 2
**Input:** `s = "3[a2[c]]"`
**Output:** `"accaccacc"`
**Explanation:** "c" is repeated 2 times to get "cc", then "acc" is repeated 3 times

### Example 3
**Input:** `s = "2[abc]3[cd]ef"`
**Output:** `"abcabccdcdcdef"`
**Explanation:** Sequential encoded patterns with trailing characters

### Example 4
**Input:** `s = "abc3[cd]xyz"`
**Output:** `"abccdcdcdxyz"`
**Explanation:** Mix of regular and encoded characters

---

## Optimal Solution

### Implementation

```python
def decodeString(s: str) -> str:
    """
    Decode string using stack for nested patterns.

    Time: O(maxK * n) where maxK is max repetition count
    Space: O(n) for stack
    """
    stack = []
    current_string = ""
    current_num = 0

    for char in s:
        if char.isdigit():
            # Build multi-digit number
            current_num = current_num * 10 + int(char)

        elif char == '[':
            # Push current state to stack
            stack.append((current_string, current_num))
            # Reset for new context
            current_string = ""
            current_num = 0

        elif char == ']':
            # Pop previous context
            prev_string, num = stack.pop()
            # Decode: repeat current string num times
            current_string = prev_string + current_string * num

        else:
            # Regular character
            current_string += char

    return current_string
```

### Alternative Recursive Implementation

```python
def decodeString(s: str) -> str:
    """
    Recursive approach for decoding.

    Time: O(maxK * n), Space: O(n) for recursion
    """
    def helper(index):
        result = ""
        num = 0

        while index < len(s):
            char = s[index]

            if char.isdigit():
                num = num * 10 + int(char)

            elif char == '[':
                # Recursively decode substring
                decoded, index = helper(index + 1)
                result += decoded * num
                num = 0

            elif char == ']':
                # Return to previous level
                return result, index

            else:
                # Regular character
                result += char

            index += 1

        return result, index

    decoded, _ = helper(0)
    return decoded
```

### Complexity Analysis

**Time: O(maxK * n) - in worst case, repeat entire string maxK times. Space: O(n) - stack storage**

**Why This is Optimal:**
- Stack naturally handles nested bracket structures
- Single pass through input string
- Handles multi-digit numbers correctly
- No need to parse or preprocess string
- Efficiently builds result without repeated copying

---

## Categories & Tags

**Primary Topics:** String, Stack, Recursion

**Difficulty Level:** MEDIUM

---

## Real-World Applications

Understanding this algorithmic pattern has direct real-world applications:

1. **Compression Algorithms:** Run-length encoding in PNG and GIF image formats
2. **Template Engines:** Jinja2 and Handlebars expanding templated strings with repetition directives
3. **Data Serialization:** Protocol Buffers and Thrift decoding repeated fields in binary formats
4. **Code Minification:** JavaScript bundlers (Webpack, Rollup) expanding compressed variable names
5. **DNA Sequence Analysis:** Bioinformatics tools expanding tandem repeat notation in genetic data

**Industry Impact:**
This algorithmic pattern appears in production systems at compression libraries (zlib, brotli), configuration management tools (Ansible, Terraform), and bioinformatics platforms (BLAST, Illumina). Engineers working on parsers, compilers, and data processing regularly implement these concepts.

---

## Cybersecurity Applications

This problem demonstrates algorithmic concepts crucial for security engineering:

1. **Malware Deobfuscation:** Unpacking encoded strings in malicious code analyzed by IDA Pro and Ghidra
2. **Payload Decoding:** WAF systems (ModSecurity) decoding nested URL encoding and hex encoding in attacks
3. **Log Parsing:** SIEM platforms expanding compressed log formats with repetition patterns
4. **Exploit Analysis:** Decoding shellcode with run-length encoding in vulnerability research
5. **Protocol Analysis:** Wireshark dissecting nested protocol layers with length-prefixed fields
6. **Sandbox Evasion Detection:** Analyzing obfuscated JavaScript in phishing emails (VirusTotal)

**Security Engineering Value:**
Security professionals use stack-based parsing in malware analysis tools to decode obfuscated strings, in intrusion detection systems to normalize payloads for signature matching, and in forensic tools to reconstruct compressed attack data.

**Common Security Contexts:**
- **Threat Detection:** Decoding obfuscated attack payloads for signature matching
- **Performance Security:** Preventing stack overflow attacks through bounded recursion
- **Secure Code Review:** Validating parsers against malformed nested structures
- **Security Tooling:** Building robust decoders for multi-layer encoding schemes
- **Incident Response:** Reverse engineering encoded C2 communications

---

## Learning Resources

**Recommended Study Path:**
1. Master stack data structure and LIFO operations
2. Understand bracket matching and nesting validation
3. Practice similar problems: Valid Parentheses (20), Basic Calculator (224)
4. Learn recursive descent parsing
5. Study string manipulation and building efficiently

**Interview Preparation:**
- This problem has 32.0% frequency in technical interviews
- Expected to solve in 20-30 minutes during coding interviews
- Be prepared to explain stack vs recursive approaches
- Practice handling edge cases and multi-digit numbers

**Common Pitfalls:**
- Not handling multi-digit numbers (e.g., "100[a]")
- Incorrect stack state management
- String concatenation inefficiency in some languages
- Missing edge cases (empty brackets, no encoding)
- Stack overflow with deeply nested patterns

**Optimization Tips:**
- Use StringBuilder in Java for efficient string building
- Track position in recursive solution to avoid substring copying
- Validate input to prevent stack overflow attacks
- Consider iterative solution for better space complexity
- Handle edge cases: no brackets, nested empty brackets

---

*Generated for educational purposes. Problem source: [LeetCode](https://leetcode.com/problems/decode-string)*
