# 055. Subsets

**Difficulty:** MEDIUM
**Frequency:** 47.0%
**Acceptance Rate:** 80.9%
**LeetCode Link:** [Subsets](https://leetcode.com/problems/subsets)

---

## Problem Description

Given an integer array `nums` of unique elements, return all possible subsets (the power set).

The solution set must not contain duplicate subsets. Return the solution in any order.

**Constraints:**
- 1 <= nums.length <= 10
- -10 <= nums[i] <= 10
- All the numbers of nums are unique

---

## Examples

### Example 1
**Input:** `nums = [1,2,3]`
**Output:** `[[],[1],[2],[1,2],[3],[1,3],[2,3],[1,2,3]]`
**Explanation:** All possible subsets of [1,2,3]

### Example 2
**Input:** `nums = [0]`
**Output:** `[[],[0]]`
**Explanation:** Single element has two subsets: empty set and the element itself

### Example 3
**Input:** `nums = [1,2]`
**Output:** `[[],[1],[2],[1,2]]`
**Explanation:** Two elements produce 2^2 = 4 subsets

### Example 4
**Input:** `nums = [9,0,3,5,7]`
**Output:** `All 2^5 = 32 possible subsets`
**Explanation:** Each element can be included or excluded independently

---

## Optimal Solution

### Implementation (Backtracking)

```python
def subsets(nums: List[int]) -> List[List[int]]:
    """
    Generate all subsets using backtracking.

    Time: O(2^n * n), Space: O(2^n * n)
    """
    result = []

    def backtrack(start: int, current: List[int]) -> None:
        """Build subsets by choosing to include or exclude each element."""
        # Add current subset to result
        result.append(current[:])  # Make a copy

        # Try adding each remaining element
        for i in range(start, len(nums)):
            current.append(nums[i])     # Include nums[i]
            backtrack(i + 1, current)   # Recurse with next elements
            current.pop()               # Backtrack (exclude nums[i])

    backtrack(0, [])
    return result
```

### Alternative Implementation (Iterative)

```python
def subsets(nums: List[int]) -> List[List[int]]:
    """
    Iterative approach: start with empty set, add each element to existing subsets.

    Time: O(2^n * n), Space: O(2^n * n)
    """
    result = [[]]  # Start with empty subset

    for num in nums:
        # For each existing subset, create a new subset by adding current number
        result += [curr + [num] for curr in result]

    return result
```

### Alternative Implementation (Bit Manipulation)

```python
def subsets(nums: List[int]) -> List[List[int]]:
    """
    Use bit manipulation: each subset corresponds to a binary number.

    Time: O(2^n * n), Space: O(2^n * n)
    """
    n = len(nums)
    result = []

    # There are 2^n possible subsets
    for i in range(1 << n):  # 2^n iterations
        subset = []
        for j in range(n):
            # Check if jth bit is set in i
            if i & (1 << j):
                subset.append(nums[j])
        result.append(subset)

    return result
```

### Complexity Analysis

**All approaches:**
- **Time:** O(2^n * n)
  - 2^n subsets to generate
  - Each subset takes O(n) time to copy/build
- **Space:** O(2^n * n)
  - Storing all subsets (output space)
  - Each subset can have up to n elements

**Why This is Optimal:**
- Cannot do better than O(2^n) since there are exactly 2^n subsets
- The factor of n comes from copying/building each subset
- This is an output-sensitive problem where the output size dominates

**Comparison of Approaches:**
- **Backtracking:** Most intuitive, mirrors the recursive nature of the problem
- **Iterative:** Simple and elegant, builds subsets incrementally
- **Bit Manipulation:** Clever use of binary representation, good for understanding the math

---

## Categories & Tags

**Primary Topics:** Array, Backtracking, Bit Manipulation

**Difficulty Level:** MEDIUM

---

## Real-World Applications

Understanding this algorithmic pattern has direct real-world applications:

1. **Feature Selection:** Machine learning pipelines selecting optimal feature combinations in scikit-learn, TensorFlow
2. **Test Coverage:** Generating test case combinations for combinatorial testing in JUnit, pytest
3. **Configuration Management:** Generating all possible system configurations in Kubernetes, Docker Compose
4. **Recommendation Systems:** Finding item combinations for bundle recommendations in Amazon, Netflix
5. **Chemical Informatics:** Generating molecular substructures in drug discovery (RDKit, OpenBabel)
6. **Network Security:** Enumerating attack paths in penetration testing tools (Metasploit, Burp Suite)

**Industry Impact:**
Subset generation is fundamental to combinatorial optimization, testing, and search problems. Companies use these algorithms in automated testing frameworks, feature engineering pipelines, and configuration validation tools.

---

## Cybersecurity Applications

This problem demonstrates algorithmic concepts crucial for security engineering:

1. **Privilege Escalation Analysis:** Enumerating permission combinations in IAM systems (AWS IAM, Azure AD)
2. **Attack Surface Mapping:** Identifying all possible attack vectors in threat modeling (STRIDE, DREAD)
3. **Vulnerability Scanning:** Generating payload combinations for fuzzing tools (AFL, LibFuzzer)
4. **Security Testing:** Combinatorial testing of security controls in penetration testing
5. **Incident Response:** Analyzing all possible compromise scenarios in forensic analysis
6. **Access Control:** Generating role-permission combinations in RBAC systems (Keycloak, Okta)

**Security Engineering Value:**
Understanding subset generation helps security engineers enumerate all possible security states, test coverage for security controls, and identify edge cases in access control systems. This is critical for thorough security testing and threat analysis.

**Common Security Contexts:**
- **Threat Detection:** Enumerating all possible attack patterns for signature generation
- **Performance Security:** Testing system behavior under all configuration combinations
- **Secure Code Review:** Identifying all code paths that need security validation
- **Security Tooling:** Building comprehensive fuzzers and security test generators
- **Incident Response:** Analyzing all possible breach scenarios during investigations

---

## Learning Resources

**Recommended Study Path:**
1. Master basic recursion and backtracking concepts
2. Understand the mathematical concept of power sets (2^n subsets)
3. Practice all three implementation approaches
4. Study the relationship to binary counting (bit manipulation)
5. Compare subset generation with permutation and combination problems

**Interview Preparation:**
- This problem has 47.0% frequency in technical interviews
- Expected to solve in 20-30 minutes during coding interviews
- Be prepared to implement at least two different approaches
- Practice explaining the 2^n time complexity
- Common follow-up: Subsets II with duplicates, Combination Sum

**Common Pitfalls:**
- Forgetting to copy the current subset when adding to result (reference issues)
- Not understanding why time complexity is O(2^n * n) not just O(2^n)
- Confusing subsets with permutations (order doesn't matter in subsets)
- Incorrect bit manipulation logic (off-by-one errors)
- Not handling the empty subset correctly

**Optimization Tips:**
- Backtracking is generally most readable and maintainable
- Iterative approach is more space-efficient (no recursion stack)
- Bit manipulation is elegant but less intuitive for most developers
- Consider sorting input if subsets need to be in specific order
- For large inputs, use generators to avoid storing all subsets in memory

---

*Generated for educational purposes. Problem source: [LeetCode](https://leetcode.com/problems/subsets)*
