# 071. Managers with at Least 5 Direct Reports

**Difficulty:** MEDIUM
**Frequency:** 40.7%
**Acceptance Rate:** 48.9%
**LeetCode Link:** [Managers with at Least 5 Direct Reports](https://leetcode.com/problems/managers-with-at-least-5-direct-reports)

---

## Problem Description

SQL Schema:
```sql
Table: Employee
+-------------+---------+
| Column Name | Type    |
+-------------+---------+
| id          | int     |
| name        | varchar |
| department  | varchar |
| managerId   | int     |
+-------------+---------+
```

Write an SQL query to find managers with at least five direct reports.

Return the result table in any order.

**Constraints:**
- Each row indicates id, name, department, and manager's id
- If managerId is null, employee has no manager
- No employee will be their own manager

---

## Examples

### Example 1
**Input:** `Employee table:\n+-----+-------+------------+-----------+\n| id  | name  | department | managerId |\n+-----+-------+------------+-----------+\n| 101 | John  | A          | None      |\n| 102 | Dan   | A          | 101       |\n| 103 | James | A          | 101       |\n| 104 | Amy   | A          | 101       |\n| 105 | Anne  | A          | 101       |\n| 106 | Ron   | B          | 101       |`
**Output:** `+------+\n| name |\n+------+\n| John |\n+------+`
**Explanation:** John has 5 direct reports

### Example 2
**Input:** `3 managers with 4, 5, and 6 reports respectively`
**Output:** `Managers with 5 and 6 reports`
**Explanation:** Only those with >= 5 reports

### Example 3
**Input:** `All employees report to same manager`
**Output:** `That single manager`
**Explanation:** Flat organization structure

---

## Optimal Solution

### Implementation

```python
SELECT e1.name
FROM Employee e1
JOIN Employee e2 ON e1.id = e2.managerId
GROUP BY e1.id, e1.name
HAVING COUNT(e2.id) >= 5;

-- Alternative using subquery:
SELECT name
FROM Employee
WHERE id IN (
    SELECT managerId
    FROM Employee
    WHERE managerId IS NOT NULL
    GROUP BY managerId
    HAVING COUNT(*) >= 5
);
```

### Complexity Analysis

**Time: O(n²) worst case for join. Space: O(n) - grouping**

**Why This is Optimal:**
- Achieves best possible asymptotic complexity for this problem class
- Minimal space overhead while maintaining code clarity
- Scales efficiently with large inputs
- Handles all edge cases correctly

---

## Categories & Tags

**Primary Topics:** Database

**Difficulty Level:** MEDIUM

---

## Real-World Applications

Understanding this algorithmic pattern has direct real-world applications:

1. **HR Systems:** Workday/SAP identifying management structure issues
2. **Organizational Analysis:** Finding span of control violations
3. **Resource Planning:** Identifying overloaded managers
4. **Performance Management:** Tracking manager-to-employee ratios
5. **Workforce Analytics:** LinkedIn Talent Insights organizational metrics
6. **Business Intelligence:** Tableau dashboards for org structure

**Industry Impact:**
This algorithmic pattern appears in production systems at companies like Google, Amazon, Microsoft, Meta, and Netflix. Engineers working on large-scale distributed systems, data processing pipelines, and user-facing applications regularly implement these concepts.

---

## Cybersecurity Applications

This problem demonstrates algorithmic concepts crucial for security engineering:

1. **Access Control Audit:** Finding users with excessive direct permissions
2. **Privilege Analysis:** Identifying accounts with many direct subordinates (privilege creep)
3. **Role-Based Access:** Finding roles assigned to many users directly
4. **Certificate Management:** Finding CAs that issued too many direct certificates
5. **Network Segmentation:** Finding routers with too many direct connections
6. **Incident Response:** Finding users whose compromise would affect many direct reports
7. **Compliance:** SOX/PCI-DSS separation of duties analysis

**Security Engineering Value:**
Security professionals use these algorithms in threat detection systems, security information and event management (SIEM) platforms, intrusion detection/prevention systems (IDS/IPS), and security automation tools. Understanding these patterns is essential for developing robust security solutions.

**Common Security Contexts:**
- **Threat Detection:** Pattern matching and anomaly detection in security logs
- **Performance Security:** Preventing algorithmic complexity attacks (e.g., hash collision DoS)
- **Secure Code Review:** Identifying potential vulnerabilities in algorithm implementations
- **Security Tooling:** Building efficient security scanners and analysis tools
- **Incident Response:** Fast data processing during security investigations

---

## Learning Resources

**Recommended Study Path:**
1. Master the fundamental data structure concepts
2. Practice similar problems with the same pattern
3. Implement the solution from scratch without reference
4. Analyze time/space complexity of alternative approaches
5. Consider edge cases and error handling

**Interview Preparation:**
- This problem has 40.7% frequency in technical interviews
- Expected to solve in 20-45 minutes during coding interviews
- Be prepared to discuss trade-offs and alternative approaches
- Practice explaining your thought process clearly

**Common Pitfalls:**
- Off-by-one errors in array/string indexing
- Not handling edge cases (empty input, single element, etc.)
- Incorrect complexity analysis
- Over-complicating the solution

**Optimization Tips:**
- Consider early termination conditions
- Minimize unnecessary data structure operations
- Use built-in language features efficiently
- Profile for performance on large inputs

---

*Generated for educational purposes. Problem source: [LeetCode](https://leetcode.com/problems/managers-with-at-least-5-direct-reports)*
