# 054. Add Two Numbers

**Difficulty:** MEDIUM
**Frequency:** 47.0%
**Acceptance Rate:** 46.2%
**LeetCode Link:** [Add Two Numbers](https://leetcode.com/problems/add-two-numbers)

---

## Problem Description

You are given two non-empty linked lists representing two non-negative integers. The digits are stored in reverse order, and each of their nodes contains a single digit. Add the two numbers and return the sum as a linked list.

You may assume the two numbers do not contain any leading zero, except the number 0 itself.

**Constraints:**
- The number of nodes in each linked list is in the range [1, 100]
- 0 <= Node.val <= 9
- It is guaranteed that the list represents a number that does not have leading zeros

---

## Examples

### Example 1
**Input:** `l1 = [2,4,3], l2 = [5,6,4]`
**Output:** `[7,0,8]`
**Explanation:** 342 + 465 = 807. The digits are stored in reverse order.

### Example 2
**Input:** `l1 = [0], l2 = [0]`
**Output:** `[0]`
**Explanation:** 0 + 0 = 0

### Example 3
**Input:** `l1 = [9,9,9,9,9,9,9], l2 = [9,9,9,9]`
**Output:** `[8,9,9,9,0,0,0,1]`
**Explanation:** 9999999 + 9999 = 10009998

### Example 4
**Input:** `l1 = [2,4,3], l2 = [5,6]`
**Output:** `[7,0,4]`
**Explanation:** 342 + 65 = 407. Different length lists handled correctly.

---

## Optimal Solution

### Implementation

```python
class ListNode:
    def __init__(self, val=0, next=None):
        self.val = val
        self.next = next

def addTwoNumbers(l1: Optional[ListNode], l2: Optional[ListNode]) -> Optional[ListNode]:
    """
    Add two numbers represented as linked lists with carry handling.

    Time: O(max(m, n)), Space: O(max(m, n))
    """
    dummy = ListNode(0)
    current = dummy
    carry = 0

    while l1 or l2 or carry:
        # Get values from current nodes (0 if None)
        val1 = l1.val if l1 else 0
        val2 = l2.val if l2 else 0

        # Calculate sum and new carry
        total = val1 + val2 + carry
        carry = total // 10
        digit = total % 10

        # Create new node with the digit
        current.next = ListNode(digit)
        current = current.next

        # Move to next nodes if they exist
        if l1:
            l1 = l1.next
        if l2:
            l2 = l2.next

    return dummy.next
```

### Alternative Implementation (More Concise)

```python
def addTwoNumbers(l1: Optional[ListNode], l2: Optional[ListNode]) -> Optional[ListNode]:
    """
    Cleaner version with similar logic.

    Time: O(max(m, n)), Space: O(max(m, n))
    """
    dummy = current = ListNode(0)
    carry = 0

    while l1 or l2 or carry:
        val = carry
        if l1:
            val += l1.val
            l1 = l1.next
        if l2:
            val += l2.val
            l2 = l2.next

        carry, val = divmod(val, 10)
        current.next = ListNode(val)
        current = current.next

    return dummy.next
```

### Complexity Analysis

**Time:** O(max(m, n)) where m and n are the lengths of the two linked lists
- We iterate through both lists once
- Each node is visited exactly once

**Space:** O(max(m, n)) for the result linked list
- In the worst case (with carry), the result has max(m, n) + 1 nodes
- Not counting the output, space is O(1) as we only use a few variables

**Why This is Optimal:**
- Cannot do better than O(max(m, n)) time since we must process all digits
- Space complexity is optimal as we need to create the output list
- Single pass solution - no need for multiple iterations
- Handles different length lists naturally
- Properly handles carry propagation including final carry

---

## Categories & Tags

**Primary Topics:** Linked List, Math, Recursion

**Difficulty Level:** MEDIUM

---

## Real-World Applications

Understanding this algorithmic pattern has direct real-world applications:

1. **Big Integer Arithmetic:** Java BigInteger, Python's arbitrary precision integers for numbers beyond native types
2. **Financial Systems:** Handling monetary calculations in blockchain (Bitcoin, Ethereum) with arbitrary precision
3. **Cryptography:** RSA encryption using large prime number arithmetic in OpenSSL, BoringSSL
4. **Scientific Computing:** Arbitrary precision libraries (GMP, MPFR) for high-precision calculations
5. **Database Systems:** Decimal type implementations in PostgreSQL, MySQL for exact numeric calculations
6. **Compiler Design:** Constant folding and arithmetic evaluation in GCC, Clang during compilation

**Industry Impact:**
This linked list arithmetic pattern is fundamental to systems requiring precision beyond hardware limits. Companies working with cryptocurrency, scientific simulations, and financial systems rely on similar algorithms for accurate large-number computations.

---

## Cybersecurity Applications

This problem demonstrates algorithmic concepts crucial for security engineering:

1. **Cryptographic Operations:** Large integer modular arithmetic in RSA, Diffie-Hellman key exchange implementations
2. **Hash Functions:** Multi-precision arithmetic in SHA-256, MD5 implementations
3. **Digital Signatures:** ECDSA signature generation and verification requiring big integer math
4. **Certificate Validation:** Serial number comparisons in X.509 certificate chain validation
5. **Blockchain Security:** Transaction ID generation and validation using large number operations
6. **Vulnerability Detection:** Integer overflow detection in static analysis tools (Coverity, SonarQube)

**Security Engineering Value:**
Understanding arbitrary precision arithmetic is essential for implementing cryptographic algorithms correctly. Many security vulnerabilities arise from improper handling of large numbers, integer overflows, or precision loss in security-critical calculations.

**Common Security Contexts:**
- **Threat Detection:** Anomaly detection in numerical patterns within security logs
- **Performance Security:** Preventing timing attacks in cryptographic implementations
- **Secure Code Review:** Identifying integer overflow vulnerabilities in arithmetic operations
- **Security Tooling:** Building cryptographic libraries with correct arbitrary precision math
- **Incident Response:** Analyzing hash collisions and cryptographic failures

---

## Learning Resources

**Recommended Study Path:**
1. Master basic linked list operations (traversal, creation, modification)
2. Understand carry propagation in manual addition
3. Practice handling edge cases: different lengths, carry at end, zeros
4. Study the relationship to big integer implementations
5. Compare iterative vs recursive solutions

**Interview Preparation:**
- This problem has 47.0% frequency in technical interviews
- Expected to solve in 20-30 minutes during coding interviews
- Be prepared to explain carry handling clearly
- Practice drawing the solution step-by-step
- Common follow-up: what if digits were in normal order (not reversed)?

**Common Pitfalls:**
- Forgetting to handle the final carry (creating an extra node)
- Not handling lists of different lengths correctly
- Creating nodes with values > 9 (forgetting to use modulo)
- Memory leaks in languages requiring manual memory management
- Not initializing carry to 0

**Optimization Tips:**
- Use dummy head node to simplify edge cases
- Single pass is sufficient - no need to reverse or preprocess
- divmod() function can simplify carry and digit calculation
- Consider the follow-up: normal order requires reversing first
- In-place modification of l1 can save space (if allowed)

---

*Generated for educational purposes. Problem source: [LeetCode](https://leetcode.com/problems/add-two-numbers)*
