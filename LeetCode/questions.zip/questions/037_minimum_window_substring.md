# 037. Minimum Window Substring

**Difficulty:** HARD
**Frequency:** 62.4%
**Acceptance Rate:** 45.4%
**LeetCode Link:** [Minimum Window Substring](https://leetcode.com/problems/minimum-window-substring)

---

## Problem Description

Given two strings `s` and `t` of lengths `m` and `n` respectively, return the minimum window substring of `s` such that every character in `t` (including duplicates) is included in the window. If there is no such substring, return the empty string "".

The testcases will be generated such that the answer is unique.

**Constraints:**
- m == s.length
- n == t.length
- 1 <= m, n <= 10^5
- s and t consist of uppercase and lowercase English letters

---

## Examples

### Example 1
**Input:** `s = "ADOBECODEBANC", t = "ABC"`
**Output:** `"BANC"`
**Explanation:** Minimum window containing all characters A, B, C

### Example 2
**Input:** `s = "a", t = "a"`
**Output:** `"a"`
**Explanation:** Single character match

### Example 3
**Input:** `s = "a", t = "aa"`
**Output:** `""`
**Explanation:** Impossible to find substring with 2 a's when s has only 1

### Example 4
**Input:** `s = "ADOBECODBANC", t = "ABCC"`
**Output:** `"CODBANC"`
**Explanation:** Must include duplicate C's from t

---

## Optimal Solution

### Implementation

```python
def minWindow(s: str, t: str) -> str:
    """
    Find minimum window substring using sliding window.

    Time: O(m+n), Space: O(k) where k is unique chars in t
    """
    if not s or not t:
        return ""

    # Count chars in t
    target = Counter(t)
    required = len(target)
    formed = 0
    window_counts = {}

    # Left, right pointers
    l, r = 0, 0
    # (window length, left, right)
    ans = float('inf'), 0, 0

    while r < len(s):
        # Expand window
        char = s[r]
        window_counts[char] = window_counts.get(char, 0) + 1

        if char in target and window_counts[char] == target[char]:
            formed += 1

        # Contract window
        while l <= r and formed == required:
            # Update result
            if r - l + 1 < ans[0]:
                ans = (r - l + 1, l, r)

            # Remove from left
            char = s[l]
            window_counts[char] -= 1
            if char in target and window_counts[char] < target[char]:
                formed -= 1
            l += 1

        r += 1

    return "" if ans[0] == float('inf') else s[ans[1]:ans[2]+1]
```

### Complexity Analysis

**Time: O(m+n) - each character visited at most twice. Space: O(k) - unique characters**

**Why This is Optimal:**
- Achieves best possible asymptotic complexity for this problem class
- Minimal space overhead while maintaining code clarity
- Scales efficiently with large inputs
- Handles all edge cases correctly

---

## Categories & Tags

**Primary Topics:** Hash Table, String, Sliding Window

**Difficulty Level:** HARD

---

## Real-World Applications

Understanding this algorithmic pattern has direct real-world applications:

1. **Text Editors:** Sublime Text, VS Code implementing 'find all' with constraints
2. **Bioinformatics:** DNA sequence matching in BLAST, finding protein motifs
3. **Log Analysis:** Splunk, ELK finding log patterns containing all required fields
4. **Data Mining:** Finding minimal records containing all required attributes
5. **Search Engines:** Google search finding minimal relevant text snippets

**Industry Impact:**
This algorithmic pattern appears in production systems at companies like Google, Amazon, Microsoft, Meta, and Netflix. Engineers working on large-scale distributed systems, data processing pipelines, and user-facing applications regularly implement these concepts.

---

## Cybersecurity Applications

This problem demonstrates algorithmic concepts crucial for security engineering:

1. **Malware Signature Detection:** Finding minimal code segments containing all signature bytes (YARA)
2. **Network Packet Analysis:** Wireshark finding minimal packet sequences with all attack indicators
3. **Log Correlation:** SIEM systems finding minimal time windows containing all attack stages
4. **Intrusion Detection:** Snort/Suricata matching minimal traffic patterns with all IOCs
5. **Forensic Analysis:** Autopsy/FTK finding minimal disk sectors containing evidence fragments
6. **APT Detection:** Finding minimal activity timeline containing all TTPs (MITRE ATT&CK)

**Security Engineering Value:**
Security professionals use these algorithms in threat detection systems, security information and event management (SIEM) platforms, intrusion detection/prevention systems (IDS/IPS), and security automation tools. Understanding these patterns is essential for developing robust security solutions.

**Common Security Contexts:**
- **Threat Detection:** Pattern matching and anomaly detection in security logs
- **Performance Security:** Preventing algorithmic complexity attacks (e.g., hash collision DoS)
- **Secure Code Review:** Identifying potential vulnerabilities in algorithm implementations
- **Security Tooling:** Building efficient security scanners and analysis tools
- **Incident Response:** Fast data processing during security investigations

---

## Learning Resources

**Recommended Study Path:**
1. Master the fundamental data structure concepts
2. Practice similar problems with the same pattern
3. Implement the solution from scratch without reference
4. Analyze time/space complexity of alternative approaches
5. Consider edge cases and error handling

**Interview Preparation:**
- This problem has 62.4% frequency in technical interviews
- Expected to solve in 20-45 minutes during coding interviews
- Be prepared to discuss trade-offs and alternative approaches
- Practice explaining your thought process clearly

**Common Pitfalls:**
- Off-by-one errors in array/string indexing
- Not handling edge cases (empty input, single element, etc.)
- Incorrect complexity analysis
- Over-complicating the solution

**Optimization Tips:**
- Consider early termination conditions
- Minimize unnecessary data structure operations
- Use built-in language features efficiently
- Profile for performance on large inputs

---

*Generated for educational purposes. Problem source: [LeetCode](https://leetcode.com/problems/minimum-window-substring)*
