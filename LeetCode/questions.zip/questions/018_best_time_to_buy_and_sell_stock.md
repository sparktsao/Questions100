# 018. Best Time to Buy and Sell Stock

**Difficulty:** EASY
**Frequency:** 76.4%
**Acceptance Rate:** 55.3%
**LeetCode Link:** [Best Time to Buy and Sell Stock](https://leetcode.com/problems/best-time-to-buy-and-sell-stock)

---

## Problem Description

You are given an array `prices` where `prices[i]` is the price of a given stock on the `i`th day.

You want to maximize your profit by choosing a single day to buy one stock and choosing a different day in the future to sell that stock.

Return the maximum profit you can achieve from this transaction. If you cannot achieve any profit, return 0.

**Constraints:**
- 1 <= prices.length <= 10^5
- 0 <= prices[i] <= 10^4

---

## Examples

### Example 1
**Input:** `prices = [7,1,5,3,6,4]`
**Output:** `5`
**Explanation:** Buy on day 2 (price=1), sell on day 5 (price=6), profit=5

### Example 2
**Input:** `prices = [7,6,4,3,1]`
**Output:** `0`
**Explanation:** No profitable transaction possible (prices only decrease)

### Example 3
**Input:** `prices = [2,4,1]`
**Output:** `2`
**Explanation:** Buy at 2, sell at 4, profit=2

### Example 4
**Input:** `prices = [3,2,6,5,0,3]`
**Output:** `4`
**Explanation:** Buy at 2, sell at 6, profit=4

---

## Optimal Solution

### Implementation

```python
def maxProfit(prices: List[int]) -> int:
    """
    Find maximum profit with single buy/sell.

    Time: O(n), Space: O(1)
    """
    min_price = float('inf')
    max_profit = 0

    for price in prices:
        # Track minimum price seen so far
        min_price = min(min_price, price)
        # Calculate profit if selling today
        profit = price - min_price
        # Update maximum profit
        max_profit = max(max_profit, profit)

    return max_profit
```

### Complexity Analysis

**Time: O(n) - single pass. Space: O(1) - constant**

**Why This is Optimal:**
- Achieves best possible asymptotic complexity for this problem class
- Minimal space overhead while maintaining code clarity
- Scales efficiently with large inputs
- Handles all edge cases correctly

---

## Categories & Tags

**Primary Topics:** Array, Dynamic Programming

**Difficulty Level:** EASY

---

## Real-World Applications

Understanding this algorithmic pattern has direct real-world applications:

1. **Trading Platforms:** Robinhood, E*TRADE calculating optimal entry/exit points
2. **Cryptocurrency Exchanges:** Coinbase, Binance analyzing price movements
3. **Financial Analytics:** Bloomberg Terminal, Reuters Eikon backtesting strategies
4. **Algorithmic Trading:** QuantConnect, Alpaca implementing momentum strategies
5. **Portfolio Management:** Vanguard, Fidelity optimizing buy/sell decisions

**Industry Impact:**
This algorithmic pattern appears in production systems at companies like Google, Amazon, Microsoft, Meta, and Netflix. Engineers working on large-scale distributed systems, data processing pipelines, and user-facing applications regularly implement these concepts.

---

## Cybersecurity Applications

This problem demonstrates algorithmic concepts crucial for security engineering:

1. **Threat Intelligence Pricing:** ThreatConnect tracking IOC value over time
2. **Bug Bounty Economics:** HackerOne analyzing payout timing optimization
3. **Dark Web Market Analysis:** Tracking cryptocurrency transaction timing patterns
4. **Ransomware Payment Tracking:** Chainalysis monitoring Bitcoin price impacts on payments
5. **Security Tool ROI:** Calculating optimal procurement timing for security licenses
6. **Vulnerability Market:** Zerodium tracking exploit price fluctuations

**Security Engineering Value:**
Security professionals use these algorithms in threat detection systems, security information and event management (SIEM) platforms, intrusion detection/prevention systems (IDS/IPS), and security automation tools. Understanding these patterns is essential for developing robust security solutions.

**Common Security Contexts:**
- **Threat Detection:** Pattern matching and anomaly detection in security logs
- **Performance Security:** Preventing algorithmic complexity attacks (e.g., hash collision DoS)
- **Secure Code Review:** Identifying potential vulnerabilities in algorithm implementations
- **Security Tooling:** Building efficient security scanners and analysis tools
- **Incident Response:** Fast data processing during security investigations

---

## Learning Resources

**Recommended Study Path:**
1. Master the fundamental data structure concepts
2. Practice similar problems with the same pattern
3. Implement the solution from scratch without reference
4. Analyze time/space complexity of alternative approaches
5. Consider edge cases and error handling

**Interview Preparation:**
- This problem has 76.4% frequency in technical interviews
- Expected to solve in 20-45 minutes during coding interviews
- Be prepared to discuss trade-offs and alternative approaches
- Practice explaining your thought process clearly

**Common Pitfalls:**
- Off-by-one errors in array/string indexing
- Not handling edge cases (empty input, single element, etc.)
- Incorrect complexity analysis
- Over-complicating the solution

**Optimization Tips:**
- Consider early termination conditions
- Minimize unnecessary data structure operations
- Use built-in language features efficiently
- Profile for performance on large inputs

---

*Generated for educational purposes. Problem source: [LeetCode](https://leetcode.com/problems/best-time-to-buy-and-sell-stock)*
