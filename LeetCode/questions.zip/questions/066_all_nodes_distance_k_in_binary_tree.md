# 066. All Nodes Distance K in Binary Tree

**Difficulty:** MEDIUM
**Frequency:** 47.0%
**Acceptance Rate:** 66.4%
**LeetCode Link:** [All Nodes Distance K in Binary Tree](https://leetcode.com/problems/all-nodes-distance-k-in-binary-tree)

---

## Problem Description

Given the `root` of a binary tree, the value of a target node `target`, and an integer `k`, return an array of the values of all nodes that have a distance `k` from the target node.

You can return the answer in any order.

**Constraints:**
- The number of nodes in the tree is in the range [1, 500]
- 0 <= Node.val <= 500
- All the values Node.val are unique
- target is the value of one of the nodes in the tree
- 0 <= k <= 1000

---

## Examples

### Example 1
**Input:** `root = [3,5,1,6,2,0,8,null,null,7,4], target = 5, k = 2`
**Output:** `[7,4,1]`
**Explanation:** Nodes at distance 2 from node 5

### Example 2
**Input:** `root = [1], target = 1, k = 3`
**Output:** `[]`
**Explanation:** No nodes at distance 3 from root

### Example 3
**Input:** `root = [0,1,2,null,3], target = 3, k = 1`
**Output:** `[1]`
**Explanation:** Node 1 is parent, distance 1 from 3

### Example 4
**Input:** `root = [0,1,2,3,null,null,null,4], target = 1, k = 2`
**Output:** `[0,4]`
**Explanation:** Both parent and grandchild at distance 2

---

## Optimal Solution

### Implementation

```python
def distanceK(root: TreeNode, target: TreeNode, k: int) -> List[int]:
    """
    Build parent pointers, then BFS from target.

    Time: O(n), Space: O(n)
    """
    from collections import deque, defaultdict

    # Build parent mapping
    parent = {}
    def build_parent(node, par=None):
        if not node:
            return
        parent[node] = par
        build_parent(node.left, node)
        build_parent(node.right, node)

    build_parent(root)

    # BFS from target
    queue = deque([(target, 0)])
    visited = {target}
    result = []

    while queue:
        node, dist = queue.popleft()

        if dist == k:
            result.append(node.val)
            continue

        # Check all neighbors: left, right, parent
        for neighbor in [node.left, node.right, parent[node]]:
            if neighbor and neighbor not in visited:
                visited.add(neighbor)
                queue.append((neighbor, dist + 1))

    return result
```

### Complexity Analysis

**Time: O(n) - visit all nodes. Space: O(n) - parent map + queue**

**Why This is Optimal:**
- Achieves best possible asymptotic complexity for this problem class
- Minimal space overhead while maintaining code clarity
- Scales efficiently with large inputs
- Handles all edge cases correctly

---

## Categories & Tags

**Primary Topics:** Hash Table, Tree, Depth-First Search, Breadth-First Search, Binary Tree

**Difficulty Level:** MEDIUM

---

## Real-World Applications

Understanding this algorithmic pattern has direct real-world applications:

1. **Social Networks:** Finding friends at exact distance (LinkedIn 2nd degree)
2. **Network Routing:** Finding all nodes K hops away (BGP routing)
3. **Graph Databases:** Neo4j distance-based queries
4. **Recommendation Systems:** Finding items K steps away in interest graph
5. **Org Charts:** Finding employees K levels away from manager
6. **Supply Chain:** Tracking dependencies K steps in production chain

**Industry Impact:**
This algorithmic pattern appears in production systems at companies like Google, Amazon, Microsoft, Meta, and Netflix. Engineers working on large-scale distributed systems, data processing pipelines, and user-facing applications regularly implement these concepts.

---

## Cybersecurity Applications

This problem demonstrates algorithmic concepts crucial for security engineering:

1. **Lateral Movement:** Finding systems K hops from compromised host
2. **Attack Path Analysis:** BloodHound finding privilege escalation K steps away
3. **Network Segmentation:** Finding all systems K hops from DMZ
4. **Malware Propagation:** Predicting infection spread K hops away
5. **Trust Boundaries:** Finding security zones K levels from perimeter
6. **Incident Scope:** Determining affected systems K connections from breach
7. **Threat Hunting:** Finding potentially compromised assets K degrees from IOC

**Security Engineering Value:**
Security professionals use these algorithms in threat detection systems, security information and event management (SIEM) platforms, intrusion detection/prevention systems (IDS/IPS), and security automation tools. Understanding these patterns is essential for developing robust security solutions.

**Common Security Contexts:**
- **Threat Detection:** Pattern matching and anomaly detection in security logs
- **Performance Security:** Preventing algorithmic complexity attacks (e.g., hash collision DoS)
- **Secure Code Review:** Identifying potential vulnerabilities in algorithm implementations
- **Security Tooling:** Building efficient security scanners and analysis tools
- **Incident Response:** Fast data processing during security investigations

---

## Learning Resources

**Recommended Study Path:**
1. Master the fundamental data structure concepts
2. Practice similar problems with the same pattern
3. Implement the solution from scratch without reference
4. Analyze time/space complexity of alternative approaches
5. Consider edge cases and error handling

**Interview Preparation:**
- This problem has 47.0% frequency in technical interviews
- Expected to solve in 20-45 minutes during coding interviews
- Be prepared to discuss trade-offs and alternative approaches
- Practice explaining your thought process clearly

**Common Pitfalls:**
- Off-by-one errors in array/string indexing
- Not handling edge cases (empty input, single element, etc.)
- Incorrect complexity analysis
- Over-complicating the solution

**Optimization Tips:**
- Consider early termination conditions
- Minimize unnecessary data structure operations
- Use built-in language features efficiently
- Profile for performance on large inputs

---

*Generated for educational purposes. Problem source: [LeetCode](https://leetcode.com/problems/all-nodes-distance-k-in-binary-tree)*
