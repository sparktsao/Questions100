# 057. Palindromic Substrings

**Difficulty:** MEDIUM
**Frequency:** 47.0%
**Acceptance Rate:** 71.7%
**LeetCode Link:** [Palindromic Substrings](https://leetcode.com/problems/palindromic-substrings)

---

## Problem Description

Given a string `s`, return the number of palindromic substrings in it.

A string is a palindrome when it reads the same backward as forward.

A substring is a contiguous sequence of characters within the string.

**Constraints:**
- 1 <= s.length <= 1000
- s consists of lowercase English letters

---

## Examples

### Example 1
**Input:** `s = "abc"`
**Output:** `3`
**Explanation:** Three palindromic substrings: "a", "b", "c"

### Example 2
**Input:** `s = "aaa"`
**Output:** `6`
**Explanation:** Six palindromic substrings: "a", "a", "a", "aa", "aa", "aaa"

### Example 3
**Input:** `s = "racecar"`
**Output:** `10`
**Explanation:** r, a, c, e, c, a, r, cec, aceca, racecar

### Example 4
**Input:** `s = "noon"`
**Output:** `6`
**Explanation:** n, o, o, n, oo, noon

---

## Optimal Solution

### Implementation

```python
def countSubstrings(s: str) -> int:
    """
    Expand around center for all possible centers.

    Time: O(n²), Space: O(1)
    """
    def expand_around_center(left, right):
        count = 0
        while left >= 0 and right < len(s) and s[left] == s[right]:
            count += 1
            left -= 1
            right += 1
        return count

    total = 0

    for i in range(len(s)):
        # Odd length palindromes (single center)
        total += expand_around_center(i, i)

        # Even length palindromes (two centers)
        total += expand_around_center(i, i + 1)

    return total
```

### Complexity Analysis

**Time: O(n²) - expand from each center. Space: O(1) - constant**

**Why This is Optimal:**
- Achieves best possible asymptotic complexity for this problem class
- Minimal space overhead while maintaining code clarity
- Scales efficiently with large inputs
- Handles all edge cases correctly

---

## Categories & Tags

**Primary Topics:** Two Pointers, String, Dynamic Programming

**Difficulty Level:** MEDIUM

---

## Real-World Applications

Understanding this algorithmic pattern has direct real-world applications:

1. **DNA Sequencing:** Finding palindromic restriction sites in genomics (BLAST)
2. **Text Analysis:** Linguistic pattern detection in natural language processing
3. **Data Compression:** Finding repeated symmetric patterns for compression
4. **Pattern Matching:** Search engine substring analysis
5. **String Algorithms:** Text editor pattern highlighting
6. **Bioinformatics:** Protein structure palindromic sequence analysis

**Industry Impact:**
This algorithmic pattern appears in production systems at companies like Google, Amazon, Microsoft, Meta, and Netflix. Engineers working on large-scale distributed systems, data processing pipelines, and user-facing applications regularly implement these concepts.

---

## Cybersecurity Applications

This problem demonstrates algorithmic concepts crucial for security engineering:

1. **Malware Detection:** Finding palindromic patterns in shellcode (polymorphic malware)
2. **Protocol Analysis:** Detecting symmetric patterns in network packets
3. **Cryptanalysis:** Identifying weak encryption patterns
4. **Obfuscation Detection:** Finding palindromic code obfuscation
5. **Anomaly Detection:** Detecting unusual symmetric patterns in logs
6. **Steganography:** Finding hidden palindromic markers in data
7. **Signature Evasion:** Detecting malware using palindromic encoding tricks

**Security Engineering Value:**
Security professionals use these algorithms in threat detection systems, security information and event management (SIEM) platforms, intrusion detection/prevention systems (IDS/IPS), and security automation tools. Understanding these patterns is essential for developing robust security solutions.

**Common Security Contexts:**
- **Threat Detection:** Pattern matching and anomaly detection in security logs
- **Performance Security:** Preventing algorithmic complexity attacks (e.g., hash collision DoS)
- **Secure Code Review:** Identifying potential vulnerabilities in algorithm implementations
- **Security Tooling:** Building efficient security scanners and analysis tools
- **Incident Response:** Fast data processing during security investigations

---

## Learning Resources

**Recommended Study Path:**
1. Master the fundamental data structure concepts
2. Practice similar problems with the same pattern
3. Implement the solution from scratch without reference
4. Analyze time/space complexity of alternative approaches
5. Consider edge cases and error handling

**Interview Preparation:**
- This problem has 47.0% frequency in technical interviews
- Expected to solve in 20-45 minutes during coding interviews
- Be prepared to discuss trade-offs and alternative approaches
- Practice explaining your thought process clearly

**Common Pitfalls:**
- Off-by-one errors in array/string indexing
- Not handling edge cases (empty input, single element, etc.)
- Incorrect complexity analysis
- Over-complicating the solution

**Optimization Tips:**
- Consider early termination conditions
- Minimize unnecessary data structure operations
- Use built-in language features efficiently
- Profile for performance on large inputs

---

*Generated for educational purposes. Problem source: [LeetCode](https://leetcode.com/problems/palindromic-substrings)*
