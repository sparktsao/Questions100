# 097. Text Justification

**Difficulty:** HARD
**Frequency:** 32.0%
**Acceptance Rate:** 48.1%
**LeetCode Link:** [Text Justification](https://leetcode.com/problems/text-justification)

---

## Problem Description

Given an array of strings `words` and a width `maxWidth`, format the text such that each line has exactly `maxWidth` characters and is fully (left and right) justified.

You should pack your words in a greedy approach; that is, pack as many words as you can in each line. Pad extra spaces `' '` when necessary so that each line has exactly `maxWidth` characters.

Extra spaces between words should be distributed as evenly as possible. If the number of spaces on a line does not divide evenly between words, the empty slots on the left will be assigned more spaces than the slots on the right.

For the last line of text, it should be left-justified, and no extra space is inserted between words.

**Note:**
- A word is defined as a character sequence consisting of non-space characters only.
- Each word's length is guaranteed to be greater than 0 and not exceed maxWidth.
- The input array words contains at least one word.

**Constraints:**
- 1 <= words.length <= 300
- 1 <= words[i].length <= 20
- words[i] consists of only English letters and symbols
- 1 <= maxWidth <= 100
- words[i].length <= maxWidth

---

## Examples

### Example 1
**Input:** `words = ["This", "is", "an", "example", "of", "text", "justification."], maxWidth = 16`
**Output:**
```
[
  "This    is    an",
  "example  of text",
  "justification.  "
]
```
**Explanation:** The first line contains "This", "is", and "an" with 2 extra spaces distributed evenly. The second line has one word with only 1 space, so extra space goes to the left slot. The last line is left-justified.

### Example 2
**Input:** `words = ["What","must","be","acknowledgment","shall","be"], maxWidth = 16`
**Output:**
```
[
  "What   must   be",
  "acknowledgment  ",
  "shall be        "
]
```
**Explanation:** Note that the last line is "shall be    " instead of "shall be", because the last line must be left-justified instead of fully-justified. Also note that the second line is also left-justified because it contains only one word.

### Example 3
**Input:** `words = ["Science","is","what","we","understand","well","enough","to","explain","to","a","computer.","Art","is","everything","else","we","do"], maxWidth = 20`
**Output:**
```
[
  "Science  is  what we",
  "understand      well",
  "enough to explain to",
  "a  computer.  Art is",
  "everything  else  we",
  "do                  "
]
```
**Explanation:** Multiple lines with different space distributions, last line is left-justified

### Example 4
**Input:** `words = ["a"], maxWidth = 1`
**Output:** `["a"]`
**Explanation:** Single word that fits exactly in maxWidth

---

## Optimal Solution

### Implementation

```python
def fullJustify(words: List[str], maxWidth: int) -> List[str]:
    """
    Text justification using greedy packing and space distribution.

    Time: O(n), Space: O(n) where n is total characters in all words
    """
    result = []
    i = 0

    while i < len(words):
        # Determine how many words fit in current line
        line_length = len(words[i])
        j = i + 1

        # Greedily pack words (each word needs at least 1 space after it)
        while j < len(words) and line_length + 1 + len(words[j]) <= maxWidth:
            line_length += 1 + len(words[j])
            j += 1

        # Build the justified line
        num_words = j - i
        num_spaces = maxWidth - line_length + (num_words - 1)

        # Check if this is the last line or line has only one word
        if j == len(words) or num_words == 1:
            # Left-justify
            line = ' '.join(words[i:j])
            line += ' ' * (maxWidth - len(line))
        else:
            # Fully justify - distribute spaces evenly
            gaps = num_words - 1
            spaces_per_gap = num_spaces // gaps
            extra_spaces = num_spaces % gaps

            line = ''
            for k in range(num_words - 1):
                line += words[i + k]
                line += ' ' * (spaces_per_gap + (1 if k < extra_spaces else 0))
            line += words[j - 1]

        result.append(line)
        i = j

    return result
```

### Complexity Analysis

**Time: O(n) - single pass through all words. Space: O(n) - output storage**

**Why This is Optimal:**
- Achieves best possible asymptotic complexity - must process each word at least once
- Greedy packing ensures optimal line utilization
- Space distribution algorithm runs in constant time per line
- Handles all edge cases: single word lines, last line, even/uneven space distribution
- No redundant computations or backtracking needed

---

## Categories & Tags

**Primary Topics:** Array, String, Simulation

**Difficulty Level:** HARD

---

## Real-World Applications

Understanding this algorithmic pattern has direct real-world applications:

1. **Text Editors:** Microsoft Word line justification, Google Docs paragraph formatting, LaTeX document typesetting
2. **PDF Generators:** Adobe PDF text layout engines, browser PDF rendering (Chrome, Firefox)
3. **Terminal Applications:** Linux `fmt` command, `groff` text formatter, man page rendering
4. **News Publishing:** New York Times digital layout systems, Medium article formatting
5. **E-Readers:** Kindle text justification, Apple Books paragraph rendering, Kobo reader text flow
6. **Web Browsers:** CSS text-align: justify implementation in rendering engines (Blink, Gecko, WebKit)

**Industry Impact:**
This algorithmic pattern appears in production systems at companies like Adobe, Google, Microsoft, and Amazon. Engineers working on document processing systems, publishing platforms, and text rendering engines regularly implement these concepts. The algorithm is fundamental to typesetting systems used in professional publishing.

---

## Cybersecurity Applications

This problem demonstrates algorithmic concepts crucial for security engineering:

1. **Log File Analysis:** Formatting security logs in SIEM tools (Splunk, ELK Stack) for readability
2. **Report Generation:** Automated security report formatting in tools like Nessus, OpenVAS
3. **Terminal Output:** Security tool output formatting (Metasploit, nmap, Wireshark CLI)
4. **Data Exfiltration Detection:** Analyzing text formatting patterns in steganography detection
5. **Input Validation:** Detecting malicious payloads hidden in formatted text inputs
6. **Forensic Tools:** Text layout preservation in digital forensics (Autopsy, FTK)

**Security Engineering Value:**
Security professionals use text formatting algorithms in audit log processing, security dashboard rendering, and forensic report generation. Understanding these patterns is essential for developing readable security tools, parsing complex log formats, and detecting anomalies in text-based data streams.

**Common Security Contexts:**
- **Threat Detection:** Formatting threat intelligence feeds for analyst consumption
- **Performance Security:** Preventing DoS attacks via excessive text processing
- **Secure Code Review:** Identifying buffer overflow risks in text formatting code
- **Security Tooling:** Building CLI security tools with professional output formatting
- **Incident Response:** Generating formatted incident reports from raw log data

---

## Learning Resources

**Recommended Study Path:**
1. Master string manipulation and space calculation techniques
2. Practice greedy algorithms and packing problems
3. Implement the solution from scratch without reference
4. Analyze edge cases: single word, last line, exact fit scenarios
5. Consider alternative approaches and their trade-offs

**Interview Preparation:**
- This problem has 32.0% frequency in technical interviews
- Expected to solve in 30-45 minutes during coding interviews
- Be prepared to discuss space distribution algorithm and edge cases
- Practice explaining greedy packing strategy clearly

**Common Pitfalls:**
- Not handling last line differently (left-justify vs full-justify)
- Incorrect space distribution when spaces don't divide evenly
- Off-by-one errors when calculating spaces needed
- Not handling single-word lines correctly
- Forgetting to pad last line to maxWidth

**Optimization Tips:**
- Pre-calculate line capacity before building strings
- Use list join instead of repeated string concatenation
- Handle special cases (last line, single word) early
- Cache space calculations to avoid redundant arithmetic
- Consider using string builder pattern for efficiency

---

*Generated for educational purposes. Problem source: [LeetCode](https://leetcode.com/problems/text-justification)*
