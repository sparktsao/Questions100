# 044. Squares of a Sorted Array

**Difficulty:** EASY
**Frequency:** 59.4%
**Acceptance Rate:** 73.2%
**LeetCode Link:** [Squares of a Sorted Array](https://leetcode.com/problems/squares-of-a-sorted-array)

---

## Problem Description

Given an integer array `nums` sorted in non-decreasing order, return an array of the squares of each number sorted in non-decreasing order.

**Constraints:**
- 1 <= nums.length <= 10^4
- -10^4 <= nums[i] <= 10^4
- nums is sorted in non-decreasing order

**Follow up:** Squaring each element and sorting the new array is very trivial, could you find an O(n) solution using a different approach?

---

## Examples

### Example 1
**Input:** `nums = [-4,-1,0,3,10]`
**Output:** `[0,1,9,16,100]`
**Explanation:** After squaring, the array becomes [16,1,0,9,100]. After sorting, it becomes [0,1,9,16,100].

### Example 2
**Input:** `nums = [-7,-3,2,3,11]`
**Output:** `[4,9,9,49,121]`
**Explanation:** After squaring: [49,9,4,9,121], after sorting: [4,9,9,49,121]

### Example 3
**Input:** `nums = [-5,-3,-2,-1]`
**Output:** `[1,4,9,25]`
**Explanation:** All negative numbers, squares in reverse order

### Example 4
**Input:** `nums = [1,2,3,4,5]`
**Output:** `[1,4,9,16,25]`
**Explanation:** All positive numbers, squares maintain order

---

## Optimal Solution

### Implementation

```python
def sortedSquares(nums: List[int]) -> List[int]:
    """
    Two-pointer approach to merge squared values from both ends.

    Time: O(n), Space: O(n) for output array
    """
    n = len(nums)
    result = [0] * n
    left, right = 0, n - 1
    pos = n - 1  # Fill result from right to left

    while left <= right:
        left_square = nums[left] ** 2
        right_square = nums[right] ** 2

        if left_square > right_square:
            result[pos] = left_square
            left += 1
        else:
            result[pos] = right_square
            right -= 1

        pos -= 1

    return result
```

### Brute Force Solution (For Comparison)

```python
def sortedSquares(nums: List[int]) -> List[int]:
    """
    Naive approach: square and sort.

    Time: O(n log n), Space: O(n)
    """
    return sorted(num ** 2 for num in nums)
```

### Alternative Implementation

```python
def sortedSquares(nums: List[int]) -> List[int]:
    """
    Find split point and merge like merge sort.

    Time: O(n), Space: O(n)
    """
    # Find the split point between negative and positive
    n = len(nums)
    split = 0

    while split < n and nums[split] < 0:
        split += 1

    # Merge two sorted arrays
    result = []
    left, right = split - 1, split

    while left >= 0 and right < n:
        left_sq = nums[left] ** 2
        right_sq = nums[right] ** 2

        if left_sq < right_sq:
            result.append(left_sq)
            left -= 1
        else:
            result.append(right_sq)
            right += 1

    # Append remaining elements
    while left >= 0:
        result.append(nums[left] ** 2)
        left -= 1

    while right < n:
        result.append(nums[right] ** 2)
        right += 1

    return result
```

### Complexity Analysis

**Time: O(n) - single pass with two pointers. Space: O(n) - output array**

**Why This is Optimal:**
- Achieves O(n) time by exploiting sorted property
- Key insight: largest squares are at either end of array
- No sorting needed, just merge from both ends
- Space is optimal since we must return output array

---

## Categories & Tags

**Primary Topics:** Array, Two Pointers, Sorting

**Difficulty Level:** EASY

---

## Real-World Applications

Understanding this algorithmic pattern has direct real-world applications:

1. **Data Analytics:** Processing sorted sensor data with positive/negative deviations in IoT systems (AWS IoT, Google Cloud IoT)
2. **Financial Systems:** Calculating variance/volatility from sorted price changes in trading platforms (Bloomberg Terminal, E*TRADE)
3. **Image Processing:** Computing pixel intensity differences in computer vision pipelines (OpenCV, TensorFlow)
4. **Scientific Computing:** Merging sorted experimental results in NumPy/Pandas data analysis workflows
5. **Signal Processing:** Combining frequency domain transformations in audio processing (FFmpeg, MATLAB)

**Industry Impact:**
The two-pointer merge technique is fundamental to many data processing algorithms. Understanding how to merge sorted sequences efficiently is crucial for optimizing data pipelines, especially in scenarios where maintaining sorted order is important for downstream processing.

---

## Cybersecurity Applications

This problem demonstrates algorithmic concepts crucial for security engineering:

1. **Anomaly Detection:** Merging sorted network traffic metrics to identify outliers in SIEM systems (Splunk, ELK Stack)
2. **Threat Scoring:** Combining sorted risk scores from multiple security tools for unified threat assessment
3. **Log Correlation:** Efficiently merging sorted security event streams from different sources for timeline analysis
4. **Performance Analysis:** Analyzing sorted response times to detect timing attacks or performance degradation
5. **Rate Limiting:** Tracking sorted request frequencies to identify potential DDoS attacks or abuse patterns
6. **Vulnerability Scoring:** Combining CVSS scores from multiple vulnerability scanners (Nessus, Qualys) in sorted order

**Security Engineering Value:**
Two-pointer merging is essential for correlating security events from multiple sources while maintaining temporal order. During incident response, analysts need to merge logs from firewalls, IDS, and application servers in time order to reconstruct attack timelines efficiently.

**Common Security Contexts:**
- **Threat Detection:** Pattern matching and anomaly detection in security logs
- **Performance Security:** Preventing algorithmic complexity attacks (e.g., hash collision DoS)
- **Secure Code Review:** Identifying potential vulnerabilities in algorithm implementations
- **Security Tooling:** Building efficient security scanners and analysis tools
- **Incident Response:** Fast data processing during security investigations

---

## Learning Resources

**Recommended Study Path:**
1. Master two-pointer technique on sorted arrays
2. Practice similar problems: Merge Sorted Array, Sort Colors
3. Implement the solution from scratch without reference
4. Analyze why brute force is O(n log n) vs optimal O(n)
5. Consider edge cases: all negative, all positive, zeros

**Interview Preparation:**
- This problem has 59.4% frequency in technical interviews
- Expected to solve in 15-20 minutes during coding interviews
- Be prepared to explain why two-pointer approach works
- Practice explaining the trade-off between different approaches

**Common Pitfalls:**
- Forgetting to fill result array from right to left
- Incorrect pointer movement logic
- Not handling arrays with all negative or all positive numbers
- Off-by-one errors in boundary conditions

**Optimization Tips:**
- Recognize that largest absolute values are at the ends
- Fill result backwards to avoid complex logic
- Consider using abs() for cleaner comparisons
- Test with edge cases: single element, all same values

---

*Generated for educational purposes. Problem source: [LeetCode](https://leetcode.com/problems/squares-of-a-sorted-array)*
