# 051. Binary Search Tree Iterator

**Difficulty:** MEDIUM
**Frequency:** 51.9%
**Acceptance Rate:** 74.9%
**LeetCode Link:** [Binary Search Tree Iterator](https://leetcode.com/problems/binary-search-tree-iterator)

---

## Problem Description

Implement the `BSTIterator` class that represents an iterator over the in-order traversal of a binary search tree (BST):

- `BSTIterator(TreeNode root)` Initializes an object of the BSTIterator class. The root of the BST is given as part of the constructor. The pointer should be initialized to a non-existent number smaller than any element in the BST.
- `boolean hasNext()` Returns true if there exists a number in the traversal to the right of the pointer, otherwise returns false.
- `int next()` Moves the pointer to the right, then returns the number at the pointer.

Notice that by initializing the pointer to a non-existent smallest number, the first call to `next()` will return the smallest element in the BST.

You may assume that `next()` calls will always be valid. That is, there will be at least a next number in the in-order traversal when `next()` is called.

**Constraints:**
- The number of nodes in the tree is in the range [1, 10^5]
- 0 <= Node.val <= 10^6
- At most 10^5 calls will be made to hasNext, and next

**Follow up:**
- Could you implement next() and hasNext() to run in average O(1) time and use O(h) memory, where h is the height of the tree?

---

## Examples

### Example 1
**Input:**
```
["BSTIterator", "next", "next", "hasNext", "next", "hasNext", "next", "hasNext", "next", "hasNext"]
[[[7, 3, 15, null, null, 9, 20]], [], [], [], [], [], [], [], [], []]
```
**Output:**
```
[null, 3, 7, true, 9, true, 15, true, 20, false]
```
**Explanation:**
```
BSTIterator bSTIterator = new BSTIterator([7, 3, 15, null, null, 9, 20]);
bSTIterator.next();    // return 3
bSTIterator.next();    // return 7
bSTIterator.hasNext(); // return True
bSTIterator.next();    // return 9
bSTIterator.hasNext(); // return True
bSTIterator.next();    // return 15
bSTIterator.hasNext(); // return True
bSTIterator.next();    // return 20
bSTIterator.hasNext(); // return False
```

### Example 2
**Input:**
```
["BSTIterator", "hasNext", "next"]
[[[1]], [], []]
```
**Output:**
```
[null, true, 1]
```
**Explanation:** Single node tree, hasNext() returns true, next() returns 1

### Example 3
**Input:**
```
["BSTIterator", "next", "next", "next"]
[[[5, 3, 7, 2, 4, 6, 8]], [], [], []]
```
**Output:**
```
[null, 2, 3, 4]
```
**Explanation:** In-order traversal returns elements in sorted order: 2, 3, 4, 5, 6, 7, 8

---

## Optimal Solution

### Implementation

```python
class BSTIterator:
    """
    BST Iterator using controlled in-order traversal with stack.

    Time: O(1) average for next/hasNext, Space: O(h) where h is tree height
    """

    def __init__(self, root: Optional[TreeNode]):
        """Initialize iterator with leftmost path."""
        self.stack = []
        self._push_left(root)

    def _push_left(self, node: Optional[TreeNode]) -> None:
        """Push all left children onto stack."""
        while node:
            self.stack.append(node)
            node = node.left

    def next(self) -> int:
        """
        Returns next smallest number in BST.

        Time: O(1) average - amortized analysis
        """
        # Pop the next node (leftmost unvisited)
        node = self.stack.pop()

        # If it has a right child, push all left children of right subtree
        if node.right:
            self._push_left(node.right)

        return node.val

    def hasNext(self) -> bool:
        """
        Returns whether we have a next smallest number.

        Time: O(1)
        """
        return len(self.stack) > 0
```

### Alternative Implementation (Pre-compute All Values)

```python
class BSTIterator:
    """
    Pre-compute all values using in-order traversal.

    Time: O(1) for next/hasNext, Space: O(n) for storing all nodes
    """

    def __init__(self, root: Optional[TreeNode]):
        """Perform complete in-order traversal."""
        self.nodes = []
        self.index = -1
        self._inorder(root)

    def _inorder(self, node: Optional[TreeNode]) -> None:
        """In-order traversal to collect all node values."""
        if not node:
            return
        self._inorder(node.left)
        self.nodes.append(node.val)
        self._inorder(node.right)

    def next(self) -> int:
        """Time: O(1)"""
        self.index += 1
        return self.nodes[self.index]

    def hasNext(self) -> bool:
        """Time: O(1)"""
        return self.index + 1 < len(self.nodes)
```

### Complexity Analysis

**Stack-based approach (Optimal):**
- **Time:** O(1) average for both next() and hasNext()
  - Amortized O(1) because each node is pushed and popped exactly once
  - Over n operations, total time is O(n), so average is O(1)
- **Space:** O(h) where h is the height of the tree
  - Stack stores at most h nodes (the height of the tree)
  - Best case O(log n) for balanced tree, worst case O(n) for skewed tree

**Pre-compute approach:**
- **Time:** O(1) for both operations (true constant time)
- **Space:** O(n) to store all node values

**Why Stack-Based is Optimal:**
- Achieves the follow-up requirement: average O(1) time with O(h) space
- More memory efficient than pre-computing all values
- Simulates controlled in-order traversal
- Only computes values as needed (lazy evaluation)

---

## Categories & Tags

**Primary Topics:** Stack, Tree, Design, Binary Search Tree, Binary Tree, Iterator

**Difficulty Level:** MEDIUM

---

## Real-World Applications

Understanding this algorithmic pattern has direct real-world applications:

1. **Database Query Cursors:** PostgreSQL and MySQL result set iterators for memory-efficient query result streaming
2. **File System Traversal:** Directory tree iteration in operating systems (Windows Explorer, macOS Finder)
3. **XML/JSON Parsers:** SAX parsers and streaming JSON readers for processing large documents
4. **AST Traversal:** Compiler design - iterating over abstract syntax trees in GCC, Clang, LLVM
5. **B-Tree Indexes:** Database index scanning in MongoDB, CouchDB for range queries
6. **Expression Evaluation:** Calculator apps evaluating expression trees in order

**Industry Impact:**
This pattern is fundamental to database systems, compilers, and file systems. Major companies like Google (Bigtable), Amazon (DynamoDB), and Microsoft (SQL Server) use similar iterator patterns for efficient data structure traversal with minimal memory overhead.

---

## Cybersecurity Applications

This problem demonstrates algorithmic concepts crucial for security engineering:

1. **Log Analysis:** SIEM systems (Splunk, ELK Stack) streaming through sorted log entries without loading all into memory
2. **Certificate Chain Validation:** Iterating through X.509 certificate hierarchies in TLS/SSL implementations (OpenSSL)
3. **Attack Tree Analysis:** Security modeling tools traversing attack trees to find vulnerability paths
4. **Binary Analysis:** IDA Pro, Ghidra iterating through disassembled instruction trees for malware analysis
5. **Threat Intelligence:** Iterating through sorted IOC (Indicators of Compromise) databases efficiently
6. **Firewall Rules:** Ordered rule evaluation in iptables, pf (packet filter) without loading entire ruleset

**Security Engineering Value:**
Efficient traversal of hierarchical security data (certificate chains, access control lists, rule sets) is critical for real-time threat detection and response. Understanding iterator patterns helps security engineers build scalable analysis tools that can process large security datasets with limited memory.

**Common Security Contexts:**
- **Threat Detection:** Streaming analysis of security events without memory exhaustion
- **Performance Security:** Preventing memory-based DoS attacks through efficient data structure traversal
- **Secure Code Review:** Understanding iterator patterns to identify potential infinite loop vulnerabilities
- **Security Tooling:** Building memory-efficient security scanners for large codebases
- **Incident Response:** Fast traversal of security logs during time-critical investigations

---

## Learning Resources

**Recommended Study Path:**
1. Master BST properties and in-order traversal
2. Understand stack-based iterative tree traversal
3. Practice implementing iterators for different tree traversal orders
4. Study amortized time complexity analysis
5. Compare trade-offs between space and time complexity

**Interview Preparation:**
- This problem has 51.9% frequency in technical interviews
- Expected to solve in 25-35 minutes during coding interviews
- Be prepared to discuss the follow-up: O(1) time with O(h) space
- Practice explaining amortized complexity analysis
- Common follow-up: implement pre-order or post-order iterator

**Common Pitfalls:**
- Forgetting to push right subtree's left children after popping a node
- Not handling null nodes correctly in helper methods
- Confusing space complexity: O(h) for stack vs O(n) for array
- Incorrectly claiming O(1) worst-case time (it's O(1) average/amortized)

**Optimization Tips:**
- Use iterative approach with stack instead of recursive in-order traversal
- Only push nodes onto stack when needed (lazy evaluation)
- Consider Morris traversal for O(1) space but with tree modification
- For read-heavy workloads, pre-computing might be better despite O(n) space

---

*Generated for educational purposes. Problem source: [LeetCode](https://leetcode.com/problems/binary-search-tree-iterator)*
